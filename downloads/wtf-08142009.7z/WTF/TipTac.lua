
TipTac_Config = {
	["showUnitTip"] = true,
	["showRealm"] = "show",
	["colReactText4"] = "|cffffff00",
	["barHeight"] = 12,
	["manaBarColor"] = {
		0.3490196078431372, -- [1]
		0.6235294117647059, -- [2]
		0.8980392156862745, -- [3]
		1, -- [4]
	},
	["anchorPoint"] = "TOPLEFT",
	["colReactBack1"] = {
		0.2, -- [1]
		0.2, -- [2]
		0.2, -- [3]
		1, -- [4]
	},
	["backdropEdgeSize"] = 17,
	["powerBar"] = true,
	["fontFlags"] = "OUTLINE",
	["showAuraCooldown"] = true,
	["colReactBack7"] = {
		0.05, -- [1]
		0.05, -- [2]
		0.05, -- [3]
		1, -- [4]
	},
	["showDebuffs"] = true,
	["powerBarText"] = "auto",
	["colReactText1"] = "|cffc0c0c0",
	["healthBarClassColor"] = true,
	["barFontFlags"] = "OUTLINE",
	["classification_rare"] = "Level %s|cffff66ff Rare",
	["colReactBack2"] = {
		0.3, -- [1]
		0, -- [2]
		0, -- [3]
		1, -- [4]
	},
	["optionsBottom"] = 430.5466397025192,
	["colReactText3"] = "|cffff7f00",
	["hideAllTipsInCombat"] = false,
	["iconSize"] = 20,
	["classification_elite"] = "Level %s|cffffcc00 Elite",
	["anchorFrameTipPoint"] = "TOP",
	["barTexture"] = "Interface\\Addons\\Gladius\\images\\Minimalist",
	["manaBar"] = true,
	["gradientColor"] = {
		0.9921568627450981, -- [1]
		0.9882352941176471, -- [2]
		1, -- [3]
		0.1200000047683716, -- [4]
	},
	["tempInformantFix"] = false,
	["updateFreq"] = 0.05000000074505806,
	["fadeTime"] = 0.5,
	["targetYouText"] = "|cffff0000 <YOU>",
	["showGuildRank"] = true,
	["anchorPointUnit"] = "TOPLEFT",
	["itemQualityBorder"] = true,
	["gradientTip"] = true,
	["top"] = 1123.067195044715,
	["left"] = 1009.040924907323,
	["barFontSize"] = 11,
	["colReactBack5"] = {
		0, -- [1]
		0.3019607843137255, -- [2]
		0.1019607843137255, -- [3]
		1, -- [4]
	},
	["colSameGuild"] = "|cffff9698",
	["healthBarColor"] = {
		0.3, -- [1]
		0.9, -- [2]
		0.3, -- [3]
		1, -- [4]
	},
	["gttScale"] = 1,
	["modifyFonts"] = true,
	["classification_rareelite"] = "Level %s|cffffaaff Rare Elite",
	["hideWorldTips"] = false,
	["optionsLeft"] = 508.0004425644809,
	["overrideFade"] = true,
	["colReactBack3"] = {
		0.3, -- [1]
		0.15, -- [2]
		0, -- [3]
		1, -- [4]
	},
	["preFadeTime"] = 3,
	["pvpName"] = true,
	["showTalents"] = false,
	["reactText"] = false,
	["colReactText2"] = "|cffff0000",
	["fontFace"] = "Fonts\\FRIZQT__.TTF",
	["tipBackdropBG"] = "Interface\\Tooltips\\UI-Tooltip-Background",
	["mouseOffsetX"] = 0,
	["tipColor"] = {
		0, -- [1]
		0, -- [2]
		0, -- [3]
		0.9400000013411045, -- [4]
	},
	["hideDefaultBar"] = true,
	["healthBar"] = true,
	["healthBarText"] = "auto",
	["classification_normal"] = "Level %s",
	["backdropInsets"] = 3.5,
	["auraMaxRows"] = 1,
	["colLevel"] = "|cffffcc00",
	["reactColoredBackdrop"] = true,
	["anchorWorldUnitPoint"] = "CENTER",
	["iconAnchor"] = "TOPLEFT",
	["colReactText6"] = "|cff25c1eb",
	["reactColoredBorder"] = false,
	["showTargetedBy"] = true,
	["selfDebuffsOnly"] = false,
	["anchorTypeUnit"] = "smart",
	["aurasAtBottom"] = true,
	["fontSize"] = 12,
	["anchorWorldTipType"] = "normal",
	["selfBuffsOnly"] = false,
	["showTarget"] = "first",
	["showBuffs"] = false,
	["manaBarText"] = "auto",
	["showStatus"] = true,
	["barFontFace"] = "Fonts\\FRIZQT__.TTF",
	["anchorType"] = "smart",
	["anchorFrameTipType"] = "parent",
	["mouseOffsetY"] = 0,
	["classification_worldboss"] = "Level %s|cffff0000 Boss",
	["colReactText5"] = "|cff00ff00",
	["colRace"] = "|cffddeeaa",
	["tipBackdropEdge"] = "Interface\\Tooltips\\UI-Tooltip-Border",
	["anchorWorldTipPoint"] = "CENTER",
	["colorNameByClass"] = true,
	["talentFormat"] = 2,
	["classColoredBorder"] = true,
	["anchorWorldUnitType"] = "normal",
	["colReactBack4"] = {
		0.3, -- [1]
		0.3, -- [2]
		0, -- [3]
		1, -- [4]
	},
	["auraSize"] = 24,
	["hideUFTipsInCombat"] = false,
	["showIcon"] = true,
	["colReactText7"] = "|cff808080",
	["tipBorderColor"] = {
		0, -- [1]
		0, -- [2]
		0, -- [3]
		1, -- [4]
	},
	["hookTips"] = true,
	["colReactBack6"] = {
		0, -- [1]
		0, -- [2]
		0.5019607843137255, -- [3]
		1, -- [4]
	},
	["anchorFrameUnitPoint"] = "BOTTOMRIGHT",
	["anchorFrameUnitType"] = "parent",
	["nameType"] = "title",
}


SexyMapDB = {
	["namespaces"] = {
		["Ping"] = {
			["profileKeys"] = {
				["Salama - 艾萨拉"] = "Salama - 艾萨拉",
				["Vor - 冰霜之刺"] = "Smers",
				["Dispel - 轻风之语"] = "Dispel - 轻风之语",
				["Smers - 海加尔"] = "Smers",
				["Kor - 撒爾薩里安"] = "海加尔",
				["月影荣耀 - 无尽之海"] = "月影荣耀 - 无尽之海",
				["缠云格格 - 屠魔山谷"] = "缠云格格 - 屠魔山谷",
				["Frostbolt - 海加尔"] = "海加尔",
			},
			["profiles"] = {
				["撒爾薩里安"] = {
				},
				["Dispel - 轻风之语"] = {
				},
				["海加尔"] = {
				},
				["Kor - 撒爾薩里安"] = {
				},
				["月影荣耀 - 无尽之海"] = {
				},
				["PRIEST"] = {
				},
				["Smers"] = {
				},
				["Default"] = {
				},
				["缠云格格 - 屠魔山谷"] = {
				},
				["Vor - 冰霜之刺"] = {
				},
				["Salama - 艾萨拉"] = {
				},
				["Frostbolt - 海加尔"] = {
				},
			},
		},
		["Coordinates"] = {
			["profileKeys"] = {
				["Salama - 艾萨拉"] = "Salama - 艾萨拉",
				["Vor - 冰霜之刺"] = "Smers",
				["Dispel - 轻风之语"] = "Dispel - 轻风之语",
				["Smers - 海加尔"] = "Smers",
				["Kor - 撒爾薩里安"] = "海加尔",
				["月影荣耀 - 无尽之海"] = "月影荣耀 - 无尽之海",
				["缠云格格 - 屠魔山谷"] = "缠云格格 - 屠魔山谷",
				["Frostbolt - 海加尔"] = "海加尔",
			},
			["profiles"] = {
				["撒爾薩里安"] = {
				},
				["Dispel - 轻风之语"] = {
				},
				["海加尔"] = {
					["y"] = 85.6239687558417,
					["x"] = -2.777404743769694,
					["fontColor"] = {
						["a"] = 1,
						["b"] = 1,
						["g"] = 1,
						["r"] = 1,
					},
					["borderColor"] = {
						["a"] = 0.2200000286102295,
						["b"] = 0,
						["g"] = 0,
						["r"] = 0,
					},
					["locked"] = true,
					["backgroundColor"] = {
						["a"] = 0.3600000143051148,
						["b"] = 0,
						["g"] = 0,
						["r"] = 0,
					},
					["fontSize"] = 12,
				},
				["Kor - 撒爾薩里安"] = {
				},
				["月影荣耀 - 无尽之海"] = {
				},
				["PRIEST"] = {
				},
				["Smers"] = {
				},
				["Default"] = {
				},
				["缠云格格 - 屠魔山谷"] = {
				},
				["Vor - 冰霜之刺"] = {
				},
				["Salama - 艾萨拉"] = {
				},
				["Frostbolt - 海加尔"] = {
				},
			},
		},
		["Buttons"] = {
			["profileKeys"] = {
				["Salama - 艾萨拉"] = "Salama - 艾萨拉",
				["Vor - 冰霜之刺"] = "Smers",
				["Dispel - 轻风之语"] = "Dispel - 轻风之语",
				["Smers - 海加尔"] = "Smers",
				["Kor - 撒爾薩里安"] = "海加尔",
				["月影荣耀 - 无尽之海"] = "月影荣耀 - 无尽之海",
				["缠云格格 - 屠魔山谷"] = "缠云格格 - 屠魔山谷",
				["Frostbolt - 海加尔"] = "海加尔",
			},
			["profiles"] = {
				["撒爾薩里安"] = {
				},
				["Dispel - 轻风之语"] = {
				},
				["海加尔"] = {
					["direction"] = {
						["hide"] = "never",
					},
					["close"] = {
						["hide"] = "never",
					},
					["zoom"] = {
						["hide"] = "never",
					},
					["voice"] = {
						["hide"] = "always",
					},
					["FuBarPluginGridFrameMinimapButton"] = {
						["hide"] = "never",
					},
					["mapclock"] = {
						["hide"] = "hover",
					},
					["allowDragging"] = false,
					["mail"] = {
						["hide"] = "always",
					},
					["worldmap"] = {
						["hide"] = "never",
					},
					["pvp"] = {
						["hide"] = "hover",
					},
				},
				["Kor - 撒爾薩里安"] = {
				},
				["月影荣耀 - 无尽之海"] = {
				},
				["PRIEST"] = {
				},
				["Smers"] = {
				},
				["Default"] = {
				},
				["缠云格格 - 屠魔山谷"] = {
				},
				["Vor - 冰霜之刺"] = {
				},
				["Salama - 艾萨拉"] = {
				},
				["Frostbolt - 海加尔"] = {
					["mail"] = {
						["hide"] = "always",
					},
					["zoom"] = {
						["hide"] = "never",
					},
					["allowDragging"] = false,
					["worldmap"] = {
						["hide"] = "never",
					},
				},
			},
		},
		["AutoZoom"] = {
			["profileKeys"] = {
				["Salama - 艾萨拉"] = "Salama - 艾萨拉",
				["Vor - 冰霜之刺"] = "Smers",
				["Dispel - 轻风之语"] = "Dispel - 轻风之语",
				["Smers - 海加尔"] = "Smers",
				["Kor - 撒爾薩里安"] = "海加尔",
				["月影荣耀 - 无尽之海"] = "月影荣耀 - 无尽之海",
				["缠云格格 - 屠魔山谷"] = "缠云格格 - 屠魔山谷",
				["Frostbolt - 海加尔"] = "海加尔",
			},
			["profiles"] = {
				["撒爾薩里安"] = {
				},
				["Dispel - 轻风之语"] = {
				},
				["海加尔"] = {
					["autoZoom"] = 10,
				},
				["Kor - 撒爾薩里安"] = {
				},
				["月影荣耀 - 无尽之海"] = {
				},
				["PRIEST"] = {
				},
				["Smers"] = {
				},
				["Default"] = {
				},
				["缠云格格 - 屠魔山谷"] = {
				},
				["Vor - 冰霜之刺"] = {
				},
				["Salama - 艾萨拉"] = {
				},
				["Frostbolt - 海加尔"] = {
				},
			},
		},
		["Shapes"] = {
			["profileKeys"] = {
				["Salama - 艾萨拉"] = "Salama - 艾萨拉",
				["Vor - 冰霜之刺"] = "Smers",
				["Dispel - 轻风之语"] = "Dispel - 轻风之语",
				["Smers - 海加尔"] = "Smers",
				["Kor - 撒爾薩里安"] = "海加尔",
				["月影荣耀 - 无尽之海"] = "月影荣耀 - 无尽之海",
				["缠云格格 - 屠魔山谷"] = "缠云格格 - 屠魔山谷",
				["Frostbolt - 海加尔"] = "海加尔",
			},
			["profiles"] = {
				["撒爾薩里安"] = {
					["shape"] = "Textures\\MinimapMask",
				},
				["Dispel - 轻风之语"] = {
					["shape"] = "Textures\\MinimapMask",
				},
				["海加尔"] = {
					["shape"] = "Interface\\BUTTONS\\WHITE8X8",
				},
				["Kor - 撒爾薩里安"] = {
					["shape"] = "Textures\\MinimapMask",
				},
				["月影荣耀 - 无尽之海"] = {
					["shape"] = "Textures\\MinimapMask",
				},
				["PRIEST"] = {
					["shape"] = "Textures\\MinimapMask",
				},
				["Smers"] = {
					["shape"] = "Textures\\MinimapMask",
				},
				["Default"] = {
					["shape"] = "Textures\\MinimapMask",
				},
				["缠云格格 - 屠魔山谷"] = {
					["shape"] = "Textures\\MinimapMask",
				},
				["Vor - 冰霜之刺"] = {
					["shape"] = "Textures\\MinimapMask",
				},
				["Salama - 艾萨拉"] = {
					["shape"] = "Textures\\MinimapMask",
				},
				["Frostbolt - 海加尔"] = {
					["shape"] = "Interface\\BUTTONS\\WHITE8X8",
				},
			},
		},
		["Fader"] = {
			["profileKeys"] = {
				["Vor - 冰霜之刺"] = "Smers",
				["Dispel - 轻风之语"] = "Dispel - 轻风之语",
				["Smers - 海加尔"] = "Smers",
				["缠云格格 - 屠魔山谷"] = "缠云格格 - 屠魔山谷",
				["Kor - 撒爾薩里安"] = "海加尔",
				["Frostbolt - 海加尔"] = "海加尔",
			},
			["profiles"] = {
				["撒爾薩里安"] = {
				},
				["Dispel - 轻风之语"] = {
				},
				["海加尔"] = {
				},
				["Kor - 撒爾薩里安"] = {
				},
				["PRIEST"] = {
				},
				["Vor - 冰霜之刺"] = {
				},
				["Default"] = {
				},
				["缠云格格 - 屠魔山谷"] = {
				},
				["Smers"] = {
				},
			},
		},
		["Movers"] = {
			["profileKeys"] = {
				["Salama - 艾萨拉"] = "Salama - 艾萨拉",
				["Vor - 冰霜之刺"] = "Smers",
				["Dispel - 轻风之语"] = "Dispel - 轻风之语",
				["Smers - 海加尔"] = "Smers",
				["Kor - 撒爾薩里安"] = "海加尔",
				["月影荣耀 - 无尽之海"] = "月影荣耀 - 无尽之海",
				["缠云格格 - 屠魔山谷"] = "缠云格格 - 屠魔山谷",
				["Frostbolt - 海加尔"] = "海加尔",
			},
			["profiles"] = {
				["撒爾薩里安"] = {
				},
				["Dispel - 轻风之语"] = {
				},
				["海加尔"] = {
					["scale"] = 0.9000000000000001,
					["framePositions"] = {
						["QuestTimerFrame"] = {
							["y"] = 239.3904268832441,
							["x"] = 1510.000130087135,
						},
						["DurabilityFrame"] = {
							["y"] = 129.2185478028871,
							["x"] = 1371.249674391006,
						},
						["AchievementWatchFrame"] = {
							["y"] = 802.0052218138394,
							["x"] = 1486.944710508813,
						},
						["WorldStateCaptureBar1"] = {
							["y"] = 196.7652100806652,
							["x"] = 1508.499428205201,
						},
						["QuestWatchFrame"] = {
							["y"] = 861.8070855467456,
							["x"] = 1228.513241581421,
						},
					},
					["alpha"] = 1,
				},
				["Kor - 撒爾薩里安"] = {
				},
				["月影荣耀 - 无尽之海"] = {
				},
				["PRIEST"] = {
				},
				["Smers"] = {
					["lock"] = false,
				},
				["Default"] = {
				},
				["缠云格格 - 屠魔山谷"] = {
				},
				["Vor - 冰霜之刺"] = {
				},
				["Salama - 艾萨拉"] = {
				},
				["Frostbolt - 海加尔"] = {
					["lock"] = false,
				},
			},
		},
		["Borders"] = {
			["global"] = {
			},
			["profileKeys"] = {
				["Salama - 艾萨拉"] = "Salama - 艾萨拉",
				["Vor - 冰霜之刺"] = "Smers",
				["Dispel - 轻风之语"] = "Dispel - 轻风之语",
				["Smers - 海加尔"] = "Smers",
				["Kor - 撒爾薩里安"] = "海加尔",
				["月影荣耀 - 无尽之海"] = "月影荣耀 - 无尽之海",
				["缠云格格 - 屠魔山谷"] = "缠云格格 - 屠魔山谷",
				["Frostbolt - 海加尔"] = "海加尔",
			},
			["profiles"] = {
				["撒爾薩里安"] = {
					["applyPreset"] = false,
					["borders"] = {
						{
							["a"] = 1,
							["r"] = 0.3098039215686275,
							["name"] = "Rune 1",
							["b"] = 1,
							["scale"] = 1.4,
							["rotSpeed"] = -16,
							["g"] = 0.4784313725490196,
							["texture"] = "SPELLS\\AURARUNE256.BLP",
						}, -- [1]
						{
							["a"] = 0.3799999952316284,
							["r"] = 0.196078431372549,
							["rotSpeed"] = 4,
							["b"] = 1,
							["scale"] = 2.1,
							["name"] = "Rune 2",
							["g"] = 0.2901960784313725,
							["texture"] = "SPELLS\\AuraRune_A.blp",
						}, -- [2]
						{
							["a"] = 0.3,
							["name"] = "Fade",
							["b"] = 1,
							["scale"] = 1.6,
							["r"] = 0,
							["g"] = 0.2235294117647059,
							["texture"] = "SPELLS\\T_VFX_HERO_CIRCLE.BLP",
						}, -- [3]
					},
				},
				["Dispel - 轻风之语"] = {
					["applyPreset"] = false,
					["borders"] = {
						{
							["a"] = 1,
							["r"] = 0.3098039215686275,
							["name"] = "Rune 1",
							["b"] = 1,
							["scale"] = 1.4,
							["rotSpeed"] = -16,
							["g"] = 0.4784313725490196,
							["texture"] = "SPELLS\\AURARUNE256.BLP",
						}, -- [1]
						{
							["a"] = 0.3799999952316284,
							["r"] = 0.196078431372549,
							["rotSpeed"] = 4,
							["b"] = 1,
							["scale"] = 2.1,
							["name"] = "Rune 2",
							["g"] = 0.2901960784313725,
							["texture"] = "SPELLS\\AuraRune_A.blp",
						}, -- [2]
						{
							["a"] = 0.3,
							["name"] = "Fade",
							["b"] = 1,
							["scale"] = 1.6,
							["r"] = 0,
							["g"] = 0.2235294117647059,
							["texture"] = "SPELLS\\T_VFX_HERO_CIRCLE.BLP",
						}, -- [3]
					},
				},
				["海加尔"] = {
					["applyPreset"] = false,
					["backdrop"] = {
						["show"] = true,
						["settings"] = {
							["edgeSize"] = 17,
						},
						["scale"] = 1.07,
					},
				},
				["Kor - 撒爾薩里安"] = {
					["applyPreset"] = false,
					["borders"] = {
						{
							["a"] = 1,
							["b"] = 1,
							["name"] = "Rune 1",
							["r"] = 0.3098039215686275,
							["scale"] = 1.4,
							["rotSpeed"] = -16,
							["g"] = 0.4784313725490196,
							["texture"] = "SPELLS\\AURARUNE256.BLP",
						}, -- [1]
						{
							["a"] = 0.3799999952316284,
							["b"] = 1,
							["rotSpeed"] = 4,
							["r"] = 0.196078431372549,
							["scale"] = 2.1,
							["name"] = "Rune 2",
							["g"] = 0.2901960784313725,
							["texture"] = "SPELLS\\AuraRune_A.blp",
						}, -- [2]
						{
							["a"] = 0.3,
							["name"] = "Fade",
							["b"] = 1,
							["scale"] = 1.6,
							["r"] = 0,
							["g"] = 0.2235294117647059,
							["texture"] = "SPELLS\\T_VFX_HERO_CIRCLE.BLP",
						}, -- [3]
					},
				},
				["月影荣耀 - 无尽之海"] = {
					["applyPreset"] = false,
					["borders"] = {
						{
							["a"] = 1,
							["r"] = 0.3098039215686275,
							["name"] = "Rune 1",
							["b"] = 1,
							["scale"] = 1.4,
							["rotSpeed"] = -16,
							["g"] = 0.4784313725490196,
							["texture"] = "SPELLS\\AURARUNE256.BLP",
						}, -- [1]
						{
							["a"] = 0.3799999952316284,
							["r"] = 0.196078431372549,
							["rotSpeed"] = 4,
							["b"] = 1,
							["scale"] = 2.1,
							["name"] = "Rune 2",
							["g"] = 0.2901960784313725,
							["texture"] = "SPELLS\\AuraRune_A.blp",
						}, -- [2]
						{
							["a"] = 0.3,
							["name"] = "Fade",
							["b"] = 1,
							["scale"] = 1.6,
							["r"] = 0,
							["g"] = 0.2235294117647059,
							["texture"] = "SPELLS\\T_VFX_HERO_CIRCLE.BLP",
						}, -- [3]
					},
				},
				["PRIEST"] = {
					["applyPreset"] = false,
					["borders"] = {
						{
							["a"] = 1,
							["r"] = 0.3098039215686275,
							["name"] = "Rune 1",
							["b"] = 1,
							["scale"] = 1.4,
							["rotSpeed"] = -16,
							["g"] = 0.4784313725490196,
							["texture"] = "SPELLS\\AURARUNE256.BLP",
						}, -- [1]
						{
							["a"] = 0.3799999952316284,
							["r"] = 0.196078431372549,
							["rotSpeed"] = 4,
							["b"] = 1,
							["scale"] = 2.1,
							["name"] = "Rune 2",
							["g"] = 0.2901960784313725,
							["texture"] = "SPELLS\\AuraRune_A.blp",
						}, -- [2]
						{
							["a"] = 0.3,
							["name"] = "Fade",
							["b"] = 1,
							["scale"] = 1.6,
							["r"] = 0,
							["g"] = 0.2235294117647059,
							["texture"] = "SPELLS\\T_VFX_HERO_CIRCLE.BLP",
						}, -- [3]
					},
				},
				["Smers"] = {
					["applyPreset"] = false,
					["borders"] = {
						{
							["a"] = 1,
							["r"] = 0.3098039215686275,
							["name"] = "Rune 1",
							["b"] = 1,
							["scale"] = 1.4,
							["rotSpeed"] = -16,
							["g"] = 0.4784313725490196,
							["texture"] = "SPELLS\\AURARUNE256.BLP",
						}, -- [1]
						{
							["a"] = 0.3799999952316284,
							["r"] = 0.196078431372549,
							["rotSpeed"] = 4,
							["b"] = 1,
							["scale"] = 2.1,
							["name"] = "Rune 2",
							["g"] = 0.2901960784313725,
							["texture"] = "SPELLS\\AuraRune_A.blp",
						}, -- [2]
						{
							["a"] = 0.3,
							["name"] = "Fade",
							["b"] = 1,
							["scale"] = 1.6,
							["r"] = 0,
							["g"] = 0.2235294117647059,
							["texture"] = "SPELLS\\T_VFX_HERO_CIRCLE.BLP",
						}, -- [3]
					},
				},
				["Default"] = {
					["applyPreset"] = false,
					["borders"] = {
						{
							["a"] = 1,
							["b"] = 1,
							["name"] = "Rune 1",
							["r"] = 0.3098039215686275,
							["scale"] = 1.4,
							["rotSpeed"] = -16,
							["g"] = 0.4784313725490196,
							["texture"] = "SPELLS\\AURARUNE256.BLP",
						}, -- [1]
						{
							["a"] = 0.3799999952316284,
							["b"] = 1,
							["rotSpeed"] = 4,
							["r"] = 0.196078431372549,
							["scale"] = 2.1,
							["name"] = "Rune 2",
							["g"] = 0.2901960784313725,
							["texture"] = "SPELLS\\AuraRune_A.blp",
						}, -- [2]
						{
							["a"] = 0.3,
							["name"] = "Fade",
							["b"] = 1,
							["scale"] = 1.6,
							["r"] = 0,
							["g"] = 0.2235294117647059,
							["texture"] = "SPELLS\\T_VFX_HERO_CIRCLE.BLP",
						}, -- [3]
					},
				},
				["缠云格格 - 屠魔山谷"] = {
					["applyPreset"] = false,
					["borders"] = {
						{
							["a"] = 1,
							["b"] = 1,
							["name"] = "Rune 1",
							["r"] = 0.3098039215686275,
							["scale"] = 1.4,
							["rotSpeed"] = -16,
							["g"] = 0.4784313725490196,
							["texture"] = "SPELLS\\AURARUNE256.BLP",
						}, -- [1]
						{
							["a"] = 0.3799999952316284,
							["b"] = 1,
							["rotSpeed"] = 4,
							["r"] = 0.196078431372549,
							["scale"] = 2.1,
							["name"] = "Rune 2",
							["g"] = 0.2901960784313725,
							["texture"] = "SPELLS\\AuraRune_A.blp",
						}, -- [2]
						{
							["a"] = 0.3,
							["name"] = "Fade",
							["b"] = 1,
							["scale"] = 1.6,
							["r"] = 0,
							["g"] = 0.2235294117647059,
							["texture"] = "SPELLS\\T_VFX_HERO_CIRCLE.BLP",
						}, -- [3]
					},
				},
				["Vor - 冰霜之刺"] = {
					["applyPreset"] = false,
					["borders"] = {
						{
							["a"] = 1,
							["r"] = 0.3098039215686275,
							["name"] = "Rune 1",
							["b"] = 1,
							["scale"] = 1.4,
							["rotSpeed"] = -16,
							["g"] = 0.4784313725490196,
							["texture"] = "SPELLS\\AURARUNE256.BLP",
						}, -- [1]
						{
							["a"] = 0.3799999952316284,
							["r"] = 0.196078431372549,
							["rotSpeed"] = 4,
							["b"] = 1,
							["scale"] = 2.1,
							["name"] = "Rune 2",
							["g"] = 0.2901960784313725,
							["texture"] = "SPELLS\\AuraRune_A.blp",
						}, -- [2]
						{
							["a"] = 0.3,
							["name"] = "Fade",
							["b"] = 1,
							["scale"] = 1.6,
							["r"] = 0,
							["g"] = 0.2235294117647059,
							["texture"] = "SPELLS\\T_VFX_HERO_CIRCLE.BLP",
						}, -- [3]
					},
				},
				["Salama - 艾萨拉"] = {
					["applyPreset"] = false,
					["borders"] = {
						{
							["a"] = 1,
							["b"] = 1,
							["name"] = "Rune 1",
							["r"] = 0.3098039215686275,
							["scale"] = 1.4,
							["rotSpeed"] = -16,
							["g"] = 0.4784313725490196,
							["texture"] = "SPELLS\\AURARUNE256.BLP",
						}, -- [1]
						{
							["a"] = 0.3799999952316284,
							["b"] = 1,
							["rotSpeed"] = 4,
							["r"] = 0.196078431372549,
							["scale"] = 2.1,
							["name"] = "Rune 2",
							["g"] = 0.2901960784313725,
							["texture"] = "SPELLS\\AuraRune_A.blp",
						}, -- [2]
						{
							["a"] = 0.3,
							["name"] = "Fade",
							["b"] = 1,
							["scale"] = 1.6,
							["r"] = 0,
							["g"] = 0.2235294117647059,
							["texture"] = "SPELLS\\T_VFX_HERO_CIRCLE.BLP",
						}, -- [3]
					},
				},
				["Frostbolt - 海加尔"] = {
					["applyPreset"] = false,
					["backdrop"] = {
						["show"] = true,
						["settings"] = {
							["edgeSize"] = 17,
						},
						["scale"] = 1.07,
					},
				},
			},
		},
		["HudMap"] = {
			["profileKeys"] = {
				["Salama - 艾萨拉"] = "Salama - 艾萨拉",
				["Vor - 冰霜之刺"] = "Smers",
				["Dispel - 轻风之语"] = "Dispel - 轻风之语",
				["Smers - 海加尔"] = "Smers",
				["Kor - 撒爾薩里安"] = "海加尔",
				["月影荣耀 - 无尽之海"] = "月影荣耀 - 无尽之海",
				["缠云格格 - 屠魔山谷"] = "缠云格格 - 屠魔山谷",
				["Frostbolt - 海加尔"] = "海加尔",
			},
			["profiles"] = {
				["撒爾薩里安"] = {
				},
				["Dispel - 轻风之语"] = {
					["scale"] = 1.4,
					["setNewScale"] = true,
				},
				["海加尔"] = {
					["setNewScale"] = true,
					["scale"] = 1.4,
					["alpha"] = 0.43,
				},
				["Kor - 撒爾薩里安"] = {
					["scale"] = 1.4,
					["setNewScale"] = true,
				},
				["月影荣耀 - 无尽之海"] = {
				},
				["PRIEST"] = {
				},
				["Smers"] = {
				},
				["Default"] = {
				},
				["缠云格格 - 屠魔山谷"] = {
					["scale"] = 1.4,
					["setNewScale"] = true,
				},
				["Vor - 冰霜之刺"] = {
					["scale"] = 1.4,
					["setNewScale"] = true,
				},
				["Salama - 艾萨拉"] = {
				},
				["Frostbolt - 海加尔"] = {
				},
			},
		},
		["ZoneText"] = {
			["profileKeys"] = {
				["Salama - 艾萨拉"] = "Salama - 艾萨拉",
				["Vor - 冰霜之刺"] = "Smers",
				["Dispel - 轻风之语"] = "Dispel - 轻风之语",
				["Smers - 海加尔"] = "Smers",
				["Kor - 撒爾薩里安"] = "海加尔",
				["月影荣耀 - 无尽之海"] = "月影荣耀 - 无尽之海",
				["缠云格格 - 屠魔山谷"] = "缠云格格 - 屠魔山谷",
				["Frostbolt - 海加尔"] = "海加尔",
			},
			["profiles"] = {
				["撒爾薩里安"] = {
				},
				["Dispel - 轻风之语"] = {
				},
				["海加尔"] = {
					["bgColor"] = {
						["a"] = 0,
					},
					["font"] = "ABF",
					["fontsize"] = 16,
					["borderColor"] = {
						["a"] = 0,
					},
					["xOffset"] = -2,
					["fontColor"] = {
						["a"] = 1,
					},
				},
				["Kor - 撒爾薩里安"] = {
				},
				["月影荣耀 - 无尽之海"] = {
				},
				["PRIEST"] = {
				},
				["Smers"] = {
				},
				["Default"] = {
				},
				["缠云格格 - 屠魔山谷"] = {
				},
				["Vor - 冰霜之刺"] = {
				},
				["Salama - 艾萨拉"] = {
				},
				["Frostbolt - 海加尔"] = {
				},
			},
		},
	},
	["profileKeys"] = {
		["Salama - 艾萨拉"] = "Salama - 艾萨拉",
		["Vor - 冰霜之刺"] = "Smers",
		["Dispel - 轻风之语"] = "Dispel - 轻风之语",
		["Smers - 海加尔"] = "Smers",
		["Kor - 撒爾薩里安"] = "海加尔",
		["月影荣耀 - 无尽之海"] = "月影荣耀 - 无尽之海",
		["缠云格格 - 屠魔山谷"] = "缠云格格 - 屠魔山谷",
		["Frostbolt - 海加尔"] = "海加尔",
	},
	["profiles"] = {
		["撒爾薩里安"] = {
		},
		["Smers"] = {
		},
		["Default"] = {
		},
		["海加尔"] = {
		},
		["Kor - 撒爾薩里安"] = {
		},
		["PRIEST"] = {
		},
		["Vor - 冰霜之刺"] = {
		},
		["Frostbolt - 海加尔"] = {
		},
	},
}

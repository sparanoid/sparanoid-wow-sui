
Omen3DB = {
	["profileKeys"] = {
		["Default"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["PositionH"] = 87.0468317412312,
			["MinimapIcon"] = {
				["hide"] = true,
			},
			["PositionW"] = 206.2502448819541,
			["FuBar"] = {
				["HideMinimapButton"] = false,
			},
			["ShowWith"] = {
				["HideWhenOOC"] = true,
				["Pet"] = false,
			},
			["detachedTooltip"] = {
			},
			["FrameStrata"] = "1-BACKGROUND",
			["VGrip1"] = 97.36381967754949,
			["VGrip2"] = 149.8638296054483,
			["PositionY"] = 365.7289450507023,
			["PositionX"] = 696.3861743154201,
			["Warnings"] = {
				["SinkOptions"] = {
					["sink20OutputSink"] = "ChatFrame",
					["sink20ScrollArea"] = "Say",
				},
			},
			["Locked"] = true,
			["Background"] = {
				["Color"] = {
					["a"] = 0.03000003099441528,
				},
				["BorderTexture"] = "None",
				["Texture"] = "Solid",
			},
			["TitleBar"] = {
				["ShowTitleBar"] = false,
				["BorderTexture"] = "Textured",
				["Texture"] = "Blizzard Dialog Background",
			},
			["Bar"] = {
				["Spacing"] = 1,
				["PetBarColor"] = {
					["a"] = 0.4800000190734863,
					["r"] = 0.7686274509803921,
				},
				["ShowPercent"] = false,
				["Height"] = 15,
				["ShowHeadings"] = false,
				["AlwaysShowSelf"] = false,
				["Texture"] = "Minimalist",
			},
		},
	},
}


MendeleevDB = {
	["profileKeys"] = {
		["Default"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["showStackSize"] = false,
			["showUsedInTree"] = false,
			["showItemLevel"] = true,
			["UsedInTreeIcons"] = false,
			["sets"] = {
				["Consumable.Food"] = false,
				["Tradeskill.Mat.ByProfession"] = true,
				["Misc.Reagent.Class"] = false,
				["Tradeskill.Gather"] = false,
				["Tradeskill.Recipe"] = false,
				["Tradeskill.Crafted"] = false,
				["Tradeskill.Gather.GemsInNodes"] = false,
				["Misc.Container.ItemsInType"] = true,
				["Misc"] = false,
			},
		},
	},
}

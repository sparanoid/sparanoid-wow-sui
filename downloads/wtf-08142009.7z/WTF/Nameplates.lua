
NameplatesDB = {
	["profileKeys"] = {
		["Default"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["bindings"] = true,
			["text"] = {
				["size"] = 7,
			},
			["level"] = {
				["size"] = 6,
			},
			["barTexture"] = "Charcoal",
			["name"] = {
				["border"] = "OUTLINE",
				["size"] = 11,
			},
			["textureName"] = "Charcoal",
		},
	},
}


GridDB = {
	["namespaces"] = {
		["GridStatusHealth"] = {
			["profiles"] = {
				["Default"] = {
					["alert_offline"] = {
						["color"] = {
							["a"] = 0.75,
							["r"] = 0.9921568627450981,
							["b"] = 0.9490196078431372,
						},
					},
					["unit_healthDeficit"] = {
						["color"] = {
							["a"] = 0.75,
						},
					},
					["alert_lowHealth"] = {
						["color"] = {
							["r"] = 0.9764705882352941,
							["g"] = 0.9882352941176471,
						},
					},
					["alert_death"] = {
						["color"] = {
							["a"] = 0.6899999976158142,
							["b"] = 0.5019607843137255,
							["g"] = 0.5019607843137255,
							["r"] = 0.5019607843137255,
						},
					},
				},
			},
		},
		["GridFrame"] = {
			["profiles"] = {
				["Default"] = {
					["cornerSize"] = 6,
					["showTooltip"] = "Always",
					["iconSize"] = 12,
					["texture"] = "Armory",
					["invertBarColor"] = true,
					["font"] = "ABF",
					["statusmap"] = {
						["corner2"] = {
							["buff_PowerWord:Shield"] = true,
							["buff_Renew"] = false,
						},
						["text"] = {
							["unit_name"] = false,
							["unit_healthDeficit"] = false,
							["alert_heals"] = false,
							["buff_Renew"] = false,
						},
						["border"] = {
							["alert_offline"] = false,
							["alert_heals"] = false,
							["buff_Renew"] = false,
							["ready_check"] = false,
							["buff_PowerWord:Shield"] = false,
							["alert_aggro"] = true,
						},
						["icon"] = {
							["debuff_curse"] = false,
							["alert_offline"] = false,
							["buff_Renew"] = false,
							["unit_name"] = false,
							["unit_health"] = false,
							["buff_PowerWord:Shield"] = false,
							["debuff_Ghost"] = false,
							["debuff_poison"] = false,
						},
						["frameAlpha"] = {
							["buff_Renew"] = false,
						},
						["healingBar"] = {
							["buff_Renew"] = false,
						},
						["corner3"] = {
							["debuff_curse"] = false,
							["debuff_poison"] = false,
							["debuff_disease"] = false,
							["buff_PowerWord:Shield"] = false,
							["debuff_magic"] = false,
							["buff_Renew"] = true,
						},
					},
				},
				["char/Kor - 撒爾薩里安"] = {
					["fontSize"] = 8,
					["statusmap"] = {
						["corner2"] = {
						},
						["text2"] = {
							["debuff_Ghost"] = true,
							["alert_feignDeath"] = true,
							["alert_death"] = true,
							["alert_offline"] = true,
						},
						["text"] = {
							["alert_offline"] = true,
							["debuff_Ghost"] = true,
							["unit_healthDeficit"] = true,
							["unit_name"] = true,
							["alert_heals"] = true,
							["alert_death"] = true,
							["alert_feignDeath"] = true,
						},
						["border"] = {
							["player_target"] = true,
							["alert_lowHealth"] = true,
							["alert_lowMana"] = true,
						},
						["corner4"] = {
							["alert_aggro"] = true,
						},
						["healingBar"] = {
							["alert_heals"] = true,
						},
						["corner1"] = {
							["alert_heals"] = true,
						},
						["frameAlpha"] = {
							["alert_range_10"] = true,
							["alert_range_40"] = true,
							["alert_offline"] = true,
							["alert_range_28"] = true,
							["alert_range_30"] = true,
							["alert_death"] = true,
							["alert_range_100"] = true,
						},
						["icon"] = {
							["ready_check"] = true,
							["debuff_poison"] = true,
							["debuff_disease"] = true,
							["debuff_curse"] = true,
							["debuff_magic"] = true,
						},
						["barcolor"] = {
							["debuff_ghost"] = true,
							["alert_offline"] = true,
							["alert_death"] = true,
							["unit_health"] = true,
						},
						["corner3"] = {
							["debuff_curse"] = true,
							["debuff_poison"] = true,
							["debuff_disease"] = true,
							["debuff_magic"] = true,
						},
						["bar"] = {
							["debuff_ghost"] = true,
							["alert_offline"] = true,
							["alert_death"] = true,
							["unit_health"] = true,
						},
					},
					["borderSize"] = 1,
					["iconBorderSize"] = 1,
					["iconSize"] = 14,
					["enableBarColor"] = false,
					["textlength"] = 4,
					["texture"] = "Gradient",
					["enableIconStackText"] = true,
					["frameHeight"] = 26,
					["healingBar_intensity"] = 0.5,
					["enableText2"] = false,
					["showTooltip"] = "OOC",
					["cornerSize"] = 5,
					["textorientation"] = "VERTICAL",
					["font"] = "Friz Quadrata TT",
					["invertBarColor"] = false,
					["debug"] = false,
					["orientation"] = "VERTICAL",
					["enableMouseoverHighlight"] = true,
					["frameWidth"] = 26,
					["enableIconCooldown"] = true,
				},
			},
		},
		["GridRoster"] = {
			["profiles"] = {
				["char/Kor - 撒爾薩里安"] = {
					["party_state"] = "solo",
				},
			},
		},
		["GridStatus"] = {
			["profiles"] = {
				["Default"] = {
					["colors"] = {
						["HUNTER"] = {
							["r"] = 0.67,
							["g"] = 0.83,
							["b"] = 0.45,
						},
						["PALADIN"] = {
							["r"] = 0.96,
							["g"] = 0.55,
							["b"] = 0.73,
						},
						["MAGE"] = {
							["r"] = 0.41,
							["g"] = 0.8,
							["b"] = 0.94,
						},
						["DRUID"] = {
							["r"] = 1,
							["g"] = 0.49,
							["b"] = 0.04,
						},
						["DEATHKNIGHT"] = {
							["r"] = 0.77,
							["g"] = 0.12,
							["b"] = 0.23,
						},
						["SHAMAN"] = {
							["r"] = 0.14,
							["g"] = 0.35,
							["b"] = 1,
						},
						["PRIEST"] = {
							["r"] = 1,
							["g"] = 1,
							["b"] = 1,
						},
						["WARLOCK"] = {
							["r"] = 0.58,
							["g"] = 0.51,
							["b"] = 0.79,
						},
						["ROGUE"] = {
							["r"] = 1,
							["g"] = 0.96,
							["b"] = 0.41,
						},
						["WARRIOR"] = {
							["r"] = 0.78,
							["g"] = 0.61,
							["b"] = 0.43,
						},
					},
				},
			},
		},
		["GridStatusAggro"] = {
			["profiles"] = {
				["Default"] = {
					["alert_aggro"] = {
						["threatcolors"] = {
							{
								["b"] = 0.4666656414046884,
							}, -- [1]
						},
					},
				},
			},
		},
		["GridLayout"] = {
			["profiles"] = {
				["Default"] = {
					["hideTab"] = true,
					["anchorRel"] = "TOPLEFT",
					["BorderB"] = 0.5019607843137255,
					["layouts"] = {
						["raid"] = "By Group 25",
					},
					["BackgroundR"] = 1,
					["ScaleSize"] = 1.65,
					["BorderA"] = 0,
					["BorderR"] = 0.5019607843137255,
					["PosX"] = 287.3326003849773,
					["BackgroundG"] = 1,
					["PosY"] = -187.2195426390682,
					["layout"] = "By Group 5",
					["BackgroundA"] = 0.03000003099441528,
					["BorderG"] = 0.5019607843137255,
					["Padding"] = 0,
					["BackgroundB"] = 1,
				},
				["char/Kor - 撒爾薩里安"] = {
					["hideTab"] = false,
					["BorderB"] = 0.5,
					["layouts"] = {
						["party"] = "By Group 5",
						["solo"] = "By Group 5",
						["arena"] = "By Group 5",
						["heroic_raid"] = "By Group 25",
						["bg"] = "By Group 40",
						["raid"] = "By Group 10",
					},
					["BackgroundR"] = 0.1,
					["ScaleSize"] = 1,
					["FrameLock"] = false,
					["BorderA"] = 1,
					["BorderR"] = 0.5,
					["Spacing"] = 10,
					["anchor"] = "TOPLEFT",
					["clamp"] = true,
					["groupAnchor"] = "TOPLEFT",
					["debug"] = false,
					["layout"] = "By Group 5",
					["PosY"] = -400,
					["PosX"] = 500,
					["BackgroundA"] = 0.65,
					["horizontal"] = false,
					["BorderG"] = 0.5,
					["BackgroundG"] = 0.1,
					["Padding"] = 1,
					["BackgroundB"] = 0.1,
					["borderTexture"] = "Blizzard Tooltip",
				},
			},
		},
		["GridStatusRange"] = {
			["profiles"] = {
				["Default"] = {
					["alert_range_100"] = {
						["enable"] = false,
						["text"] = "100 yards",
						["color"] = {
							["a"] = 0.1090909090909091,
							["r"] = 0,
							["g"] = 0,
							["b"] = 0,
						},
						["priority"] = 90,
						["range"] = false,
						["desc"] = "More than 100 yards away",
					},
					["alert_range_10"] = {
						["enable"] = false,
						["text"] = "10 yards",
						["color"] = {
							["a"] = 0.8181818181818181,
							["r"] = 0.1,
							["g"] = 0.2,
							["b"] = 0.3,
						},
						["priority"] = 81,
						["range"] = false,
						["desc"] = "More than 10 yards away",
					},
					["alert_range_40"] = {
						["enable"] = true,
						["text"] = "40 yards",
						["color"] = {
							["a"] = 0.2727272727272727,
							["r"] = 0.4,
							["g"] = 0.8,
							["b"] = 0.2,
						},
						["priority"] = 84,
						["range"] = false,
						["desc"] = "More than 40 yards away",
					},
					["alert_range_28"] = {
						["enable"] = false,
						["text"] = "28 yards",
						["color"] = {
							["a"] = 0.490909090909091,
							["r"] = 0.28,
							["g"] = 0.5600000000000001,
							["b"] = 0.84,
						},
						["priority"] = 83,
						["range"] = false,
						["desc"] = "More than 28 yards away",
					},
					["alert_range_30"] = {
						["enable"] = false,
						["text"] = "30 yards",
						["color"] = {
							["a"] = 0.4545454545454546,
							["r"] = 0.3,
							["g"] = 0.6,
							["b"] = 0.9,
						},
						["priority"] = 83,
						["range"] = false,
						["desc"] = "More than 30 yards away",
					},
					["alert_range_38"] = {
						["enable"] = false,
						["text"] = "38 yards",
						["color"] = {
							["a"] = 0.3090909090909091,
							["r"] = 0.38,
							["g"] = 0.76,
							["b"] = 0.14,
						},
						["priority"] = 84,
						["range"] = false,
						["desc"] = "More than 38 yards away",
					},
				},
			},
		},
	},
	["profiles"] = {
		["Default"] = {
			["detachedTooltip"] = {
			},
		},
		["char/Kor - 撒爾薩里安"] = {
			["debug"] = false,
		},
	},
}

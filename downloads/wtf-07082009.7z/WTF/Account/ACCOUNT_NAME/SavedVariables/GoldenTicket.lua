
GoldenTicketDB = {
	["hideTextTicket"] = false,
	["minimapIcon"] = {
		["minimapPos"] = 141.6604998497236,
		["radius"] = 80,
		["hide"] = true,
	},
	["hideLabel"] = false,
	["hideText"] = false,
}

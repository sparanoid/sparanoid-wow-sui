
AuldLangSyneGuildListDB = nil

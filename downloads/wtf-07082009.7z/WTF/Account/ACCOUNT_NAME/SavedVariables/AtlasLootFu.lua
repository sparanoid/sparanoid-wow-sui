
AtlasLootFuDB = {
	["disabled"] = {
		["Default"] = true,
	},
	["profiles"] = {
		["Default"] = {
			["detachedTooltip"] = {
				["fontSizePercent"] = 1,
			},
		},
	},
}

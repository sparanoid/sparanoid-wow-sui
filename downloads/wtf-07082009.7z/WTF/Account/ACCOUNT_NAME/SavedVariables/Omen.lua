
Omen3DB = {
	["profileKeys"] = {
		["Dispel - 轻风之语"] = "Dispel - 轻风之语",
		["Smers - 海加尔"] = "Smers - 海加尔",
		["Salama - 艾萨拉"] = "Salama - 艾萨拉",
		["月影荣耀 - 无尽之海"] = "月影荣耀 - 无尽之海",
		["缠云格格 - 屠魔山谷"] = "缠云格格 - 屠魔山谷",
		["Frostbolt - 海加尔"] = "Smers - 海加尔",
	},
	["profiles"] = {
		["Dispel - 轻风之语"] = {
			["PositionX"] = 687.4999897554518,
			["PositionY"] = 674.9999899417163,
		},
		["Smers - 海加尔"] = {
			["PositionW"] = 206.2502448819541,
			["PositionH"] = 87.0468317412312,
			["VGrip2"] = 149.8638296054483,
			["PositionY"] = 365.7289450507023,
			["Locked"] = true,
			["Background"] = {
				["BorderTexture"] = "None",
				["Color"] = {
					["a"] = 0.03000003099441528,
				},
				["Texture"] = "Solid",
			},
			["MinimapIcon"] = {
				["hide"] = true,
			},
			["ShowWith"] = {
				["HideWhenOOC"] = true,
				["Pet"] = false,
			},
			["detachedTooltip"] = {
			},
			["FrameStrata"] = "1-BACKGROUND",
			["VGrip1"] = 97.36381967754949,
			["TitleBar"] = {
				["ShowTitleBar"] = false,
				["BorderTexture"] = "Textured",
				["Texture"] = "Blizzard Dialog Background",
			},
			["Warnings"] = {
				["SinkOptions"] = {
					["sink20OutputSink"] = "ChatFrame",
					["sink20ScrollArea"] = "Say",
				},
			},
			["FuBar"] = {
				["HideMinimapButton"] = false,
			},
			["PositionX"] = 696.3861743154201,
			["Bar"] = {
				["ShowHeadings"] = false,
				["ShowPercent"] = false,
				["PetBarColor"] = {
					["a"] = 0.4800000190734863,
					["r"] = 0.7686274509803921,
				},
				["Texture"] = "Minimalist",
				["Height"] = 15,
				["Spacing"] = 1,
				["AlwaysShowSelf"] = false,
			},
		},
		["Salama - 艾萨拉"] = {
			["PositionX"] = 687.4999897554518,
			["PositionY"] = 674.9999899417163,
		},
		["月影荣耀 - 无尽之海"] = {
			["PositionX"] = 687.4999897554518,
			["PositionY"] = 674.9999899417163,
		},
		["缠云格格 - 屠魔山谷"] = {
			["PositionX"] = 687.4999897554518,
			["PositionY"] = 674.9999899417163,
		},
		["Frostbolt - 海加尔"] = {
			["VGrip2"] = 138.0000416755835,
			["PositionY"] = 237.8906405286396,
			["PositionW"] = 240.0000154972074,
			["Bar"] = {
				["Height"] = 19,
			},
			["Shown"] = true,
			["PositionX"] = 1332.499522380538,
			["VGrip1"] = 102.0000308036922,
			["PositionH"] = 138.250024642795,
		},
	},
}

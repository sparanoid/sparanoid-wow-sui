
GladiusDB = {
	["profileKeys"] = {
		["Dispel - 轻风之语"] = "Dispel - 轻风之语",
		["Smers - 海加尔"] = "Smers - 海加尔",
		["缠云格格 - 屠魔山谷"] = "缠云格格 - 屠魔山谷",
		["Salama - 艾萨拉"] = "Salama - 艾萨拉",
		["Frostbolt - 海加尔"] = "Frostbolt - 海加尔",
	},
	["profiles"] = {
		["Dispel - 轻风之语"] = {
			["y"] = 468.1500313881769,
			["x"] = 76.79989337921533,
		},
		["Smers - 海加尔"] = {
			["rageDefault"] = false,
			["barHeight"] = 15,
			["castBar"] = false,
			["trinketUpAnnounce"] = true,
			["trinketDisplay"] = "smallIcon",
			["y"] = 611.9404068909429,
			["x"] = 168.8003843366955,
			["classIcon"] = false,
			["auraFontSize"] = 20,
			["drinkAnnounce"] = true,
			["padding"] = 2,
			["lowHealthAnnounce"] = true,
			["enemyAnnounce"] = true,
			["manaMax"] = false,
			["rpDefault"] = false,
			["healthFontSize"] = 10,
			["manaBarHeight"] = 14,
			["trinketUsedAnnounce"] = true,
			["manaFontSize"] = 9,
			["barBottomMargin"] = 6,
			["barWidth"] = 160,
		},
		["缠云格格 - 屠魔山谷"] = {
			["y"] = 412.6501311119594,
			["x"] = 50.39999812245372,
		},
		["Salama - 艾萨拉"] = {
			["y"] = 393.150009768083,
			["x"] = 790.4000682115523,
		},
		["Frostbolt - 海加尔"] = {
			["y"] = 375.1499860245737,
			["x"] = 716.79982681275,
			["classIcon"] = false,
		},
	},
}


DurStatusOpt = {
	["showMerchant"] = true,
	["showInChar"] = true,
	["showWarning"] = true,
	["showAverage"] = false,
	["warnLevel"] = 30,
	["showReport"] = true,
	["showWindow"] = false,
}

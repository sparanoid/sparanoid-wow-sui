
TooltipItemIcon_Saved = {
	["options"] = {
		["achievement"] = true,
		["spell"] = true,
		["item"] = true,
	},
	["tooltips"] = {
		["compare"] = true,
	},
	["inside"] = {
		["size"] = 25,
	},
	["exact"] = {
	},
	["version"] = 1.54,
	["template"] = {
	},
	["frame"] = {
		["alpha"] = 1,
		["size"] = 39,
	},
	["background"] = {
		["tintb"] = 0.4,
		["tintg"] = 0.4,
		["alpha"] = 0.9,
		["tintr"] = 0.4,
	},
	["mode"] = "inside",
}

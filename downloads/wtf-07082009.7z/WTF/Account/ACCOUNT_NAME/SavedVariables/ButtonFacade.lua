
ButtonFacadeDB = {
	["namespaces"] = {
		["BlizzardBuffs"] = {
			["profileKeys"] = {
				["Smers - 海加尔"] = "Default",
				["Frostbolt - 海加尔"] = "Default",
			},
			["profiles"] = {
				["Default"] = {
					["skin"] = {
						["Gloss"] = 0,
						["Colors"] = {
							["Gloss"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Checked"] = {
								0, -- [1]
								0.7450980392156863, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Flash"] = {
								1, -- [1]
								0, -- [2]
								0, -- [3]
								1, -- [4]
							},
						},
						["ID"] = "DsmFade",
					},
				},
			},
		},
		["EasyTrinket"] = {
			["profileKeys"] = {
				["Smers - 海加尔"] = "Default",
				["Frostbolt - 海加尔"] = "Default",
			},
			["profiles"] = {
				["Default"] = {
					["Menu buttons"] = {
						["Colors"] = {
							["Gloss"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Checked"] = {
								0, -- [1]
								0.7450980392156863, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Flash"] = {
								1, -- [1]
								0, -- [2]
								0, -- [3]
								1, -- [4]
							},
						},
						["Skin"] = "DsmFade",
					},
					["Main buttons"] = {
						["Colors"] = {
							["Gloss"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Checked"] = {
								0, -- [1]
								0.7450980392156863, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Flash"] = {
								1, -- [1]
								0, -- [2]
								0, -- [3]
								1, -- [4]
							},
						},
						["Skin"] = "DsmFade",
					},
				},
			},
		},
		["ButtonTest"] = {
			["profileKeys"] = {
				["Smers - 海加尔"] = "Default",
				["Frostbolt - 海加尔"] = "Default",
			},
			["profiles"] = {
				["Default"] = {
					["x"] = 309.999976307154,
					["skin"] = {
						["ID"] = "DsmFade",
						["Gloss"] = 0,
					},
					["y"] = -212.8906599746546,
				},
			},
		},
		["BlizzardButtons"] = {
			["profileKeys"] = {
				["Smers - 海加尔"] = "Default",
				["Frostbolt - 海加尔"] = "Default",
			},
			["profiles"] = {
				["Default"] = {
					["enabled"] = true,
					["MultiBarBottomRightButtons"] = {
						["skin"] = {
							["Gloss"] = 0,
							["Colors"] = {
								["Gloss"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["Checked"] = {
									0, -- [1]
									0.7450980392156863, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["Flash"] = {
									1, -- [1]
									0, -- [2]
									0, -- [3]
									1, -- [4]
								},
							},
							["ID"] = "DsmFade",
						},
					},
					["BonusActionButtons"] = {
						["skin"] = {
							["Gloss"] = 0,
							["Colors"] = {
								["Gloss"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["Checked"] = {
									0, -- [1]
									0.7450980392156863, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["Flash"] = {
									1, -- [1]
									0, -- [2]
									0, -- [3]
									1, -- [4]
								},
							},
							["ID"] = "DsmFade",
						},
					},
					["ShapeshiftButtons"] = {
						["skin"] = {
							["Gloss"] = 0,
							["Colors"] = {
								["Gloss"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["Checked"] = {
									0, -- [1]
									0.7450980392156863, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["Flash"] = {
									1, -- [1]
									0, -- [2]
									0, -- [3]
									1, -- [4]
								},
							},
							["ID"] = "DsmFade",
						},
					},
					["MultiBarBottomLeftButtons"] = {
						["skin"] = {
							["Gloss"] = 0,
							["Colors"] = {
								["Gloss"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["Checked"] = {
									0, -- [1]
									0.7450980392156863, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["Flash"] = {
									1, -- [1]
									0, -- [2]
									0, -- [3]
									1, -- [4]
								},
							},
							["ID"] = "DsmFade",
						},
					},
					["ActionButtons"] = {
						["skin"] = {
							["Gloss"] = 0,
							["Colors"] = {
								["Gloss"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["Checked"] = {
									0, -- [1]
									0.7450980392156863, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["Flash"] = {
									1, -- [1]
									0, -- [2]
									0, -- [3]
									1, -- [4]
								},
							},
							["ID"] = "DsmFade",
						},
					},
					["MultiBarLeftButtons"] = {
						["skin"] = {
							["Gloss"] = 0,
							["Colors"] = {
								["Gloss"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["Checked"] = {
									0, -- [1]
									0.7450980392156863, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["Flash"] = {
									1, -- [1]
									0, -- [2]
									0, -- [3]
									1, -- [4]
								},
							},
							["ID"] = "DsmFade",
						},
					},
					["skin"] = {
						["Gloss"] = 0,
						["Colors"] = {
							["Gloss"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Checked"] = {
								0, -- [1]
								0.7450980392156863, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Flash"] = {
								1, -- [1]
								0, -- [2]
								0, -- [3]
								1, -- [4]
							},
						},
						["ID"] = "DsmFade",
					},
					["MultiBarRightButtons"] = {
						["skin"] = {
							["Gloss"] = 0,
							["Colors"] = {
								["Gloss"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["Checked"] = {
									0, -- [1]
									0.7450980392156863, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["Flash"] = {
									1, -- [1]
									0, -- [2]
									0, -- [3]
									1, -- [4]
								},
							},
							["ID"] = "DsmFade",
						},
					},
					["PetActionButtons"] = {
						["skin"] = {
							["Gloss"] = 0,
							["Colors"] = {
								["Gloss"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["Checked"] = {
									0, -- [1]
									0.7450980392156863, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["Flash"] = {
									1, -- [1]
									0, -- [2]
									0, -- [3]
									1, -- [4]
								},
							},
							["ID"] = "DsmFade",
						},
					},
					["PossessButtons"] = {
						["skin"] = {
							["Gloss"] = 0,
							["Colors"] = {
								["Gloss"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["Checked"] = {
									0, -- [1]
									0.7450980392156863, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["Flash"] = {
									1, -- [1]
									0, -- [2]
									0, -- [3]
									1, -- [4]
								},
							},
							["ID"] = "DsmFade",
						},
					},
				},
			},
		},
	},
	["version"] = 7,
	["profileKeys"] = {
		["Smers - 海加尔"] = "Default",
		["Frostbolt - 海加尔"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["mapicon"] = {
				["hide"] = true,
			},
			["skin"] = {
				["ID"] = "DsmFade",
				["Colors"] = {
					["Gloss"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["Checked"] = {
						0, -- [1]
						0.7450980392156863, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["Flash"] = {
						1, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
				},
				["Gloss"] = 0,
			},
		},
	},
}

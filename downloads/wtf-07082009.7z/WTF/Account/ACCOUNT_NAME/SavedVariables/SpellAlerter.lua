
SpellAlerterDB = {
	["profileKeys"] = {
		["缠云格格 - 屠魔山谷"] = "Default",
		["Frostbolt - 海加尔"] = "Default",
		["Dispel - 轻风之语"] = "Default",
		["Smers - 海加尔"] = "Default",
	},
	["global"] = {
		["Minimap"] = {
			["minimapPos"] = 198.3660905242488,
			["hide"] = true,
		},
	},
	["profiles"] = {
		["Default"] = {
			["SpellNames"] = true,
			["FontSize"] = 24,
			["SpellCasts"] = {
				["Holy Light"] = {
					["Color"] = "YELLOW",
				},
				["Healing Wave"] = {
					["Color"] = "YELLOW",
				},
				["Redemption"] = {
					["Color"] = "GREY",
				},
				["Immolate"] = {
					["Color"] = "RED",
				},
				["Polymorph"] = {
					["Color"] = "PINK",
				},
				["Pyroblast"] = {
					["Color"] = "RED",
				},
				["Ancestral Spirit"] = {
					["Color"] = "GREY",
				},
				["Hibernate"] = {
					["Color"] = "PINK",
				},
				["Greater Heal"] = {
					["Color"] = "YELLOW",
				},
				["Flash Heal"] = {
					["Color"] = "YELLOW",
				},
				["Mind Flay"] = {
					["Color"] = "RED",
				},
				["Unstable Affliction"] = {
					["Color"] = "RED",
				},
				["Snake Trap"] = {
					["Color"] = "PINK",
				},
				["Frost Trap"] = {
					["Color"] = "PINK",
				},
				["Haunt"] = {
					["Color"] = "RED",
				},
				["Smite"] = {
					["Color"] = "RED",
				},
				["Flash of Light"] = {
					["Color"] = "YELLOW",
				},
				["Cyclone"] = {
					["Color"] = "PINK",
				},
				["Freezing Trap"] = {
					["Color"] = "PINK",
				},
				["Grounding Totem"] = {
					["Color"] = "GREEN",
				},
				["Fireball"] = {
					["Color"] = "RED",
				},
				["Resurrection"] = {
					["Color"] = "GREY",
				},
				["Regrowth"] = {
					["Color"] = "YELLOW",
				},
				["Tranquility"] = {
					["Color"] = "YELLOW",
				},
				["Fire Nova Totem"] = {
					["Color"] = "GREEN",
				},
				["Frostbolt"] = {
					["Color"] = "RED",
				},
				["Binding Heal"] = {
					["Color"] = "YELLOW",
				},
				["Summon Felguard"] = {
					["Color"] = "GREY",
				},
				["Mind Blast"] = {
					["Color"] = "RED",
				},
				["Entangling Roots"] = {
					["Color"] = "PINK",
				},
				["Mana Burn"] = {
					["Color"] = "RED",
				},
				["Soul Fire"] = {
					["Color"] = "RED",
				},
				["Revive Pet"] = {
					["Color"] = "GREY",
				},
				["Summon Succubus"] = {
					["Color"] = "GREY",
				},
				["Revive"] = {
					["Color"] = "GREY",
				},
				["Fear"] = {
					["Color"] = "PINK",
				},
				["Hex"] = {
					["Color"] = "PINK",
				},
				["Holy Fire"] = {
					["Color"] = "RED",
				},
				["Howl of Terror"] = {
					["Color"] = "PINK",
				},
				["Shadow Bolt"] = {
					["Color"] = "RED",
				},
				["Lava Burst"] = {
					["Color"] = "RED",
				},
				["Healing Touch"] = {
					["Color"] = "YELLOW",
				},
				["Lightning Bolt"] = {
					["Color"] = "RED",
				},
				["Summon Voidwalker"] = {
					["Color"] = "GREY",
				},
				["Spell Reflection"] = {
					["Color"] = "PINK",
				},
				["Mind Control"] = {
					["Color"] = "PINK",
				},
				["Chaos Bolt"] = {
					["Color"] = "RED",
				},
				["Lesser Healing Wave"] = {
					["Color"] = "YELLOW",
				},
				["Chain Lightning"] = {
					["Color"] = "RED",
				},
				["Vampiric Touch"] = {
					["Color"] = "RED",
				},
				["Mana Tide Totem"] = {
					["Color"] = "GREEN",
				},
				["Summon Felhunter"] = {
					["Color"] = "GREY",
				},
			},
			["IconSize"] = 24,
			["Positions"] = {
				["SpellAlerterFrameAnchor"] = {
					nil, -- [1]
					nil, -- [2]
					nil, -- [3]
					nil, -- [4]
					150.1563812768999, -- [5]
				},
			},
			["FriendlyDebuffs"] = {
				["Viper Sting"] = {
					["Color"] = "AQUA",
				},
			},
			["Ignores"] = {
				["Howl of Terror"] = "Howl of Terror",
				["Tranquility"] = "Tranquility",
				["Grounding Totem"] = "Grounding Totem",
				["Summon Felhunter"] = "Summon Felhunter",
				["Fire Nova Totem"] = "Fire Nova Totem",
				["Summon Felguard"] = "Summon Felguard",
				["Snake Trap"] = "Snake Trap",
				["Frost Trap"] = "Frost Trap",
				["Mana Tide Totem"] = "Mana Tide Totem",
				["Summon Succubus"] = "Summon Succubus",
				["Spell Reflection"] = "Spell Reflection",
				["Summon Voidwalker"] = "Summon Voidwalker",
				["Freezing Trap"] = "Freezing Trap",
				["Revive Pet"] = "Revive Pet",
			},
			["EnemyBuffs"] = {
				["Nature's Swiftness"] = {
					["Color"] = "PEACH",
				},
				["Power Infusion"] = {
					["Color"] = "PEACH",
				},
				["Hand of Protection"] = {
					["Color"] = "VIOLET",
				},
				["Earth Shield"] = {
					["Color"] = "PEACH",
				},
				["Fel Domination"] = {
					["Color"] = "PEACH",
				},
				["Evocation"] = {
					["Color"] = "PEACH",
				},
				["Hand of Freedom"] = {
					["Color"] = "VIOLET",
				},
				["Innervate"] = {
					["Color"] = "PEACH",
				},
				["Beacon of Light"] = {
					["Color"] = "PEACH",
				},
				["Hand of Sacrifice"] = {
					["Color"] = "VIOLET",
				},
			},
		},
	},
}

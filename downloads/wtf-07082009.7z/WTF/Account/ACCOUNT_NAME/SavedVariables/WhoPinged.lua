
WhoPingedDB = {
	["profileKeys"] = {
		["Dispel - 轻风之语"] = "profile",
		["Smers - 海加尔"] = "profile",
		["Salama - 艾萨拉"] = "profile",
		["月影荣耀 - 无尽之海"] = "profile",
		["缠云格格 - 屠魔山谷"] = "profile",
		["Frostbolt - 海加尔"] = "profile",
	},
	["profiles"] = {
		["profile"] = {
		},
	},
}
PlayerNames = nil

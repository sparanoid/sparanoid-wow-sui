
DBM_VictorySound_Settings = {
	["enabled"] = true,
	["wipeSound"] = true,
	["wipePath"] = "SMWdefeat.mp3",
	["victoryPath"] = "SMBvictory.mp3",
	["victorySound"] = true,
}

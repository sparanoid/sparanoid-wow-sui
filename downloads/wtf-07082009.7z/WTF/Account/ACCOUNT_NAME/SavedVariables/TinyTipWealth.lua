
TinyTipWealthDB = {
	["ShowCoins"] = false,
	["WealthType"] = "328",
	["DisableInCombat"] = false,
	["OnlyInCity"] = false,
	["DisableEnemyFaction"] = false,
}

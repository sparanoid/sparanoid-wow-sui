
DominosDB = {
	["profileKeys"] = {
		["Dispel - 轻风之语"] = "Priest",
		["Smers - 海加尔"] = "Smers",
		["缠云格格 - 屠魔山谷"] = "Rogue",
		["Salama - 艾萨拉"] = "Shaman",
		["Frostbolt - 海加尔"] = "Smers",
	},
	["profiles"] = {
		["Priest"] = {
			["minimapPos"] = 347.700666394207,
			["showMinimap"] = false,
			["classStyle"] = {
				"DsmFade", -- [1]
				0, -- [2]
				false, -- [3]
				{
					["Checked"] = {
						0, -- [1]
						0.7450980392156863, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["Flash"] = {
						1, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
				}, -- [4]
			},
			["showTooltips"] = 1,
			["ab"] = {
				["style"] = {
					"DsmFade", -- [1]
					0, -- [2]
					false, -- [3]
					{
						["Checked"] = {
							0, -- [1]
							0.7450980392156863, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["Flash"] = {
							1, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
					}, -- [4]
				},
			},
			["showMacroText"] = false,
			["frames"] = {
				{
					["point"] = "BOTTOMLEFT",
					["scale"] = 0.75,
					["padW"] = 0,
					["x"] = 849.0000789016474,
					["spacing"] = 0,
					["padH"] = 0,
					["pages"] = {
						["PRIEST"] = {
							["[bar:2]"] = 1,
							["[bar:6]"] = 5,
							["[bar:4]"] = 3,
							["[bar:3]"] = 2,
							["[bar:5]"] = 4,
							["[bonusbar:1]"] = 6,
						},
					},
					["numButtons"] = 12,
					["y"] = 28.12499719671909,
				}, -- [1]
				{
					["point"] = "BOTTOMRIGHT",
					["hidden"] = true,
					["padW"] = 2,
					["x"] = -109.9995405972074,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 195.7032174512265,
				}, -- [2]
				{
					["columns"] = 1,
					["scale"] = 0.8,
					["point"] = "BOTTOMRIGHT",
					["y"] = 509.9998779594916,
					["x"] = 0,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["numButtons"] = 12,
					["fadeAlpha"] = 0,
				}, -- [3]
				{
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.8,
					["fadeAlpha"] = 0,
					["y"] = 509.9998779594916,
					["x"] = -39.99999940395355,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["numButtons"] = 12,
					["columns"] = 1,
				}, -- [4]
				{
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.75,
					["anchor"] = "6TC",
					["padW"] = 0,
					["x"] = -850.6663895050726,
					["numButtons"] = 12,
					["spacing"] = 0,
					["padH"] = 0,
					["y"] = 72.00000178813932,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["fadeAlpha"] = 0,
				}, -- [5]
				{
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.75,
					["padW"] = 0,
					["x"] = -826.6662983099675,
					["y"] = 36.00000089406966,
					["spacing"] = 0,
					["padH"] = 0,
					["numButtons"] = 12,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["anchor"] = "1TC",
				}, -- [6]
				{
					["point"] = "BOTTOMRIGHT",
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["y"] = 39.99999225139629,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["anchor"] = "2TC",
				}, -- [7]
				{
					["point"] = "TOPRIGHT",
					["hidden"] = true,
					["padW"] = 2,
					["x"] = -131.2493876926694,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = -404.2187439766713,
				}, -- [8]
				{
					["point"] = "BOTTOMRIGHT",
					["hidden"] = true,
					["padW"] = 2,
					["x"] = -109.9995405972074,
					["y"] = 275.7032162591336,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["anchor"] = "7TC",
				}, -- [9]
				{
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.9,
					["hidden"] = true,
					["y"] = 350.7813592138684,
					["x"] = -122.2217456830942,
					["padW"] = 2,
					["spacing"] = 2,
					["padH"] = 2,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
					["anchor"] = "9TR",
				}, -- [10]
				["cast"] = {
					["y"] = 155.9999919533731,
					["x"] = -198.1997651129998,
					["showText"] = true,
					["anchor"] = "10TL",
					["hidden"] = true,
					["point"] = "BOTTOMRIGHT",
				},
				["bags"] = {
					["y"] = 155.9999919533731,
					["x"] = 0,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
					["anchor"] = "10TR",
					["numButtons"] = 6,
					["hidden"] = true,
				},
				["menu"] = {
					["y"] = 409.4155059841945,
					["x"] = 25.00000201165673,
					["point"] = "BOTTOMLEFT",
					["spacing"] = 0,
					["scale"] = 0.6,
					["fadeAlpha"] = 0.05,
				},
				["pet"] = {
					["y"] = 81.00000260770317,
					["x"] = -627.4998380616332,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 1,
					["anchor"] = "5TC",
					["showstates"] = "[target=pet,exists,nobonusbar:5]",
				},
				["class"] = {
					["y"] = 137.5781038764402,
					["x"] = -467.4999167397632,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
					["anchor"] = "9TL",
					["hidden"] = true,
					["numButtons"] = 0,
				},
				["vehicle"] = {
					["y"] = 111.0000021606683,
					["x"] = -754.9998361617352,
					["point"] = "BOTTOMRIGHT",
					["anchor"] = "petTC",
					["numButtons"] = 3,
					["showstates"] = "[target=vehicle,exists]",
				},
				["xp"] = {
					["alwaysShowXP"] = false,
					["point"] = "TOPRIGHT",
					["hidden"] = true,
					["width"] = 0.75,
					["y"] = -119.8902875201361,
					["x"] = -189.9999971687796,
					["height"] = 23,
					["alwaysShowText"] = true,
					["texture"] = "Minimalist",
				},
				["roll"] = {
					["y"] = 346.9690271173562,
					["x"] = 0,
					["columns"] = 1,
					["spacing"] = 2,
					["hidden"] = true,
					["numButtons"] = 4,
					["point"] = "BOTTOMLEFT",
				},
			},
			["sticky"] = 1,
			["petStyle"] = {
				"DsmFade", -- [1]
				0, -- [2]
				false, -- [3]
				{
					["Checked"] = {
						0, -- [1]
						0.7450980392156863, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["Flash"] = {
						1, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
				}, -- [4]
			},
			["showBindingText"] = false,
		},
		["Mage"] = {
			["minimapPos"] = 354.4223908648531,
			["ab"] = {
				["style"] = {
					"DsmFade", -- [1]
					0, -- [2]
					false, -- [3]
					{
						["Checked"] = {
							0, -- [1]
							0.7450980392156863, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["Flash"] = {
							1, -- [1]
							0, -- [2]
							0, -- [3]
							0.5, -- [4]
						},
					}, -- [4]
				},
			},
			["showMinimap"] = false,
			["petStyle"] = {
				"DsmFade", -- [1]
				0, -- [2]
				false, -- [3]
				{
					["Checked"] = {
						0, -- [1]
						0.7450980392156863, -- [2]
						1, -- [3]
						1, -- [4]
					},
				}, -- [4]
			},
			["frames"] = {
				{
					["padW"] = 2,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["MAGE"] = {
							["[bar:6]"] = 5,
							["[bar:4]"] = 3,
							["[bar:3]"] = 2,
							["[bar:5]"] = 4,
							["[bar:2]"] = 1,
						},
						["PRIEST"] = {
							["[bonusbar:1]"] = 6,
							["[bar:6]"] = 5,
							["[bar:5]"] = 4,
							["[bar:3]"] = 2,
							["[bar:4]"] = 3,
							["[bar:2]"] = 1,
						},
					},
					["numButtons"] = 12,
					["y"] = 0,
				}, -- [1]
				{
					["point"] = "BOTTOMRIGHT",
					["columns"] = 1,
					["numButtons"] = 12,
					["y"] = 359.999994635582,
					["x"] = -39.99999940395355,
					["padH"] = 2,
					["spacing"] = 4,
					["anchor"] = "3LB",
					["padW"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
					},
					["fadeAlpha"] = 0.2,
				}, -- [2]
				{
					["point"] = "BOTTOMRIGHT",
					["columns"] = 1,
					["padW"] = 2,
					["x"] = 0,
					["numButtons"] = 12,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 359.999994635582,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
					},
					["fadeAlpha"] = 0.2,
				}, -- [3]
				{
					["y"] = 0,
					["x"] = 0,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [4]
				{
					["point"] = "BOTTOMLEFT",
					["padW"] = 2,
					["x"] = 559.9999535083778,
					["y"] = 79.9999892711641,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
					},
					["anchor"] = "6TC",
				}, -- [5]
				{
					["point"] = "BOTTOMLEFT",
					["padW"] = 2,
					["x"] = 559.9998772144336,
					["y"] = 39.99996125698147,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
					},
					["anchor"] = "1TL",
				}, -- [6]
				{
					["point"] = "BOTTOMRIGHT",
					["padW"] = 2,
					["x"] = 0,
					["y"] = 79.99998450279259,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
					},
					["anchor"] = "4TR",
				}, -- [7]
				{
					["point"] = "BOTTOMRIGHT",
					["padW"] = 2,
					["x"] = -62.49999906867743,
					["y"] = 262.4218520161234,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
					},
					["anchor"] = "7TC",
				}, -- [8]
				{
					["point"] = "BOTTOMRIGHT",
					["padW"] = 2,
					["x"] = -62.49999906867743,
					["y"] = 302.4218323465909,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
					},
					["anchor"] = "8TC",
				}, -- [9]
				{
					["point"] = "BOTTOMLEFT",
					["padW"] = 2,
					["fadeAlpha"] = 0.2,
					["x"] = 17.49999973922968,
					["spacing"] = 0,
					["padH"] = 2,
					["numButtons"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
					},
					["y"] = 281.8749576527632,
				}, -- [10]
				["cast"] = {
					["y"] = -352.9219002586319,
					["x"] = -681.7498677708229,
					["showText"] = true,
					["hidden"] = true,
					["point"] = "TOPRIGHT",
				},
				["class"] = {
					["numButtons"] = 1,
					["point"] = "CENTER",
					["spacing"] = 2,
				},
				["menu"] = {
					["y"] = 450.7220391821558,
					["fadeAlpha"] = 0.05,
					["point"] = "BOTTOMLEFT",
					["scale"] = 0.65,
					["x"] = 164.922921584205,
				},
				["pet"] = {
					["y"] = 119.9999982118607,
					["x"] = 622.9999830871823,
					["point"] = "BOTTOMLEFT",
					["spacing"] = 6,
					["anchor"] = "5TC",
					["showstates"] = "[target=pet,exists,nobonusbar:5]",
				},
				["bags"] = {
					["y"] = 159.9999976158142,
					["x"] = 0,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
					["anchor"] = "9TR",
					["numButtons"] = 6,
					["hidden"] = true,
				},
				["vehicle"] = {
					["y"] = -582.6562413177454,
					["x"] = -749.0001566857077,
					["point"] = "TOPRIGHT",
					["numButtons"] = 3,
					["showstates"] = "[target=vehicle,exists]",
				},
				["xp"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "TOP",
					["texture"] = "blizzard",
					["height"] = 14,
					["alwaysShowText"] = true,
					["hidden"] = true,
					["width"] = 0.75,
				},
				["roll"] = {
					["point"] = "LEFT",
					["spacing"] = 2,
					["columns"] = 1,
					["numButtons"] = 4,
					["hidden"] = true,
				},
			},
			["classStyle"] = {
				"DsmFade", -- [1]
				0, -- [2]
				false, -- [3]
				{
					["Checked"] = {
						0, -- [1]
						0.7450980392156863, -- [2]
						1, -- [3]
						1, -- [4]
					},
				}, -- [4]
			},
			["showMacroText"] = false,
		},
		["Rogue"] = {
			["frames"] = {
				{
					["padW"] = 2,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 0,
					["numButtons"] = 12,
					["pages"] = {
						["ROGUE"] = {
							["[form:3]"] = 6,
							["[bonusbar:1]"] = 6,
							["[bar:6]"] = 5,
							["[bar:5]"] = 4,
							["[bar:3]"] = 2,
							["[bar:4]"] = 3,
							["[bar:2]"] = 1,
						},
					},
				}, -- [1]
				{
					["padW"] = 2,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 40,
					["numButtons"] = 12,
					["pages"] = {
						["ROGUE"] = {
						},
					},
				}, -- [2]
				{
					["padW"] = 2,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 80,
					["numButtons"] = 12,
					["pages"] = {
						["ROGUE"] = {
						},
					},
				}, -- [3]
				{
					["padW"] = 2,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 120,
					["numButtons"] = 12,
					["pages"] = {
						["ROGUE"] = {
						},
					},
				}, -- [4]
				{
					["padW"] = 2,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 160,
					["numButtons"] = 12,
					["pages"] = {
						["ROGUE"] = {
						},
					},
				}, -- [5]
				{
					["padW"] = 2,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 200,
					["numButtons"] = 12,
					["pages"] = {
						["ROGUE"] = {
						},
					},
				}, -- [6]
				{
					["padW"] = 2,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 240,
					["numButtons"] = 12,
					["pages"] = {
						["ROGUE"] = {
						},
					},
				}, -- [7]
				{
					["padW"] = 2,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 280,
					["numButtons"] = 12,
					["pages"] = {
						["ROGUE"] = {
						},
					},
				}, -- [8]
				{
					["padW"] = 2,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 320,
					["numButtons"] = 12,
					["pages"] = {
						["ROGUE"] = {
						},
					},
				}, -- [9]
				{
					["padW"] = 2,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 360,
					["numButtons"] = 12,
					["pages"] = {
						["ROGUE"] = {
						},
					},
				}, -- [10]
				["cast"] = {
					["y"] = 30,
					["x"] = 0,
					["showText"] = true,
					["point"] = "CENTER",
				},
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
				},
				["roll"] = {
					["columns"] = 1,
					["numButtons"] = 4,
					["point"] = "LEFT",
					["spacing"] = 2,
				},
				["xp"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "TOP",
					["height"] = 14,
					["texture"] = "blizzard",
					["alwaysShowText"] = true,
					["width"] = 0.75,
				},
				["vehicle"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["numButtons"] = 3,
					["showstates"] = "[target=vehicle,exists]",
				},
				["class"] = {
					["numButtons"] = 1,
					["point"] = "CENTER",
					["spacing"] = 2,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
					["showstates"] = "[target=pet,exists,nobonusbar:5]",
				},
				["bags"] = {
					["numButtons"] = 6,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
				},
			},
			["ab"] = {
				["style"] = {
					nil, -- [1]
					nil, -- [2]
					nil, -- [3]
					{
					}, -- [4]
				},
			},
			["classStyle"] = {
				nil, -- [1]
				nil, -- [2]
				false, -- [3]
				{
				}, -- [4]
			},
			["petStyle"] = {
				nil, -- [1]
				nil, -- [2]
				false, -- [3]
				{
				}, -- [4]
			},
		},
		["Smers"] = {
			["minimapPos"] = 347.700666394207,
			["showMinimap"] = false,
			["showgrid"] = false,
			["classStyle"] = {
				"DsmFade", -- [1]
				0, -- [2]
				false, -- [3]
				{
					["Gloss"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["Checked"] = {
						0, -- [1]
						0.7450980392156863, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["Flash"] = {
						1, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
				}, -- [4]
			},
			["showTooltips"] = 1,
			["ab"] = {
				["style"] = {
					"DsmFade", -- [1]
					0, -- [2]
					false, -- [3]
					{
						["Gloss"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["Checked"] = {
							0, -- [1]
							0.7450980392156863, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["Flash"] = {
							1, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
					}, -- [4]
				},
			},
			["showMacroText"] = false,
			["showBindingText"] = false,
			["sticky"] = 1,
			["petStyle"] = {
				"DsmFade", -- [1]
				0, -- [2]
				false, -- [3]
				{
					["Gloss"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["Checked"] = {
						0, -- [1]
						0.7450980392156863, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["Flash"] = {
						1, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
				}, -- [4]
			},
			["frames"] = {
				{
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.7,
					["padW"] = 0,
					["x"] = -926.8568500280428,
					["spacing"] = 0,
					["padH"] = 0,
					["y"] = 30.13412430682593,
					["pages"] = {
						["MAGE"] = {
							["[bar:6]"] = 5,
							["[bar:4]"] = 3,
							["[bar:3]"] = 2,
							["[bar:5]"] = 4,
							["[bar:2]"] = 1,
						},
						["PRIEST"] = {
							["[bonusbar:1]"] = 6,
							["[bar:6]"] = 5,
							["[bar:5]"] = 4,
							["[bar:3]"] = 2,
							["[bar:4]"] = 3,
							["[bar:2]"] = 1,
						},
					},
					["numButtons"] = 12,
				}, -- [1]
				{
					["point"] = "BOTTOMRIGHT",
					["hidden"] = true,
					["padW"] = 2,
					["x"] = -56.24984657392133,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 131.2501029483959,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [2]
				{
					["columns"] = 1,
					["scale"] = 0.8,
					["fadeAlpha"] = 0,
					["y"] = 509.9998779594916,
					["x"] = 0,
					["numButtons"] = 12,
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
					},
					["point"] = "BOTTOMRIGHT",
				}, -- [3]
				{
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.8,
					["columns"] = 1,
					["y"] = 509.9998779594916,
					["x"] = -39.99999940395355,
					["numButtons"] = 12,
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
					},
					["fadeAlpha"] = 0,
				}, -- [4]
				{
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.7,
					["padW"] = 0,
					["x"] = -368.0716105518573,
					["y"] = 50.2233879234882,
					["spacing"] = 0,
					["padH"] = 0,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
					["anchor"] = "1RB",
				}, -- [5]
				{
					["point"] = "BOTTOMLEFT",
					["scale"] = 0.7,
					["y"] = 50.22339269185972,
					["x"] = 621.642370497549,
					["anchor"] = "1LT",
					["spacing"] = 0,
					["padH"] = 0,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
					["padW"] = 0,
				}, -- [6]
				{
					["point"] = "BOTTOMRIGHT",
					["hidden"] = true,
					["y"] = 39.99999225139629,
					["x"] = 0,
					["anchor"] = "2TC",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [7]
				{
					["point"] = "TOPRIGHT",
					["hidden"] = true,
					["padW"] = 2,
					["x"] = -152.4992347881314,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
					},
					["y"] = -426.4842923509434,
				}, -- [8]
				{
					["point"] = "BOTTOMRIGHT",
					["hidden"] = true,
					["y"] = 275.7032162591336,
					["x"] = -109.9995405972074,
					["anchor"] = "7TC",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [9]
				{
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.9,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = -122.2217456830942,
					["anchor"] = "9TR",
					["spacing"] = 2,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
					},
					["y"] = 350.7813592138684,
				}, -- [10]
				["cast"] = {
					["y"] = 155.9999919533731,
					["x"] = -198.1997651129998,
					["showText"] = true,
					["anchor"] = "10TL",
					["hidden"] = true,
					["point"] = "BOTTOMRIGHT",
				},
				["roll"] = {
					["y"] = 346.9690271173562,
					["x"] = 0,
					["columns"] = 1,
					["spacing"] = 2,
					["point"] = "BOTTOMLEFT",
					["hidden"] = true,
					["numButtons"] = 4,
				},
				["menu"] = {
					["y"] = 41.10967098013057,
					["fadeAlpha"] = 0.05,
					["point"] = "BOTTOMLEFT",
					["spacing"] = 0,
					["scale"] = 0.6,
					["x"] = 34.08316561455778,
				},
				["xp"] = {
					["point"] = "TOPLEFT",
					["hidden"] = true,
					["width"] = 0.23,
					["y"] = -236.7188227665599,
					["x"] = 610.9998993426576,
					["height"] = 7,
					["alwaysShowText"] = true,
					["texture"] = "Flat",
				},
				["vehicle"] = {
					["y"] = 111.0000021606683,
					["showstates"] = "[target=vehicle,exists]",
					["point"] = "BOTTOMRIGHT",
					["anchor"] = "petTC",
					["numButtons"] = 3,
					["x"] = -754.9998361617352,
				},
				["bags"] = {
					["y"] = 155.9999919533731,
					["x"] = 0,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
					["anchor"] = "10TR",
					["numButtons"] = 6,
					["hidden"] = true,
				},
				["pet"] = {
					["y"] = 46.76149775443229,
					["showstates"] = "[target=pet,exists,nobonusbar:5]",
					["point"] = "BOTTOMLEFT",
					["spacing"] = 1,
					["scale"] = 0.99,
					["x"] = 651.8083093790962,
					["anchor"] = "1TR",
				},
				["class"] = {
					["y"] = 137.5781038764402,
					["x"] = -467.4999167397632,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
					["anchor"] = "9TL",
					["hidden"] = true,
					["numButtons"] = 1,
				},
			},
		},
	},
}
DominosVersion = "1.9.4"

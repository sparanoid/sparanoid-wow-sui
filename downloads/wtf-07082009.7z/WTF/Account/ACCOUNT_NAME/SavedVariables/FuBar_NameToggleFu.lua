
FuBar_NameToggleDB = nil

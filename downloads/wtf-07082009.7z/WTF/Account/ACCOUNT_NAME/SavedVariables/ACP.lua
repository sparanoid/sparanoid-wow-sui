
ACP_Data = {
	["sorter"] = "Group By Name",
	["NoRecurse"] = true,
	["NoChildren"] = true,
	["collapsed"] = {
	},
	["ProtectedAddons"] = {
		["ACP"] = true,
	},
}

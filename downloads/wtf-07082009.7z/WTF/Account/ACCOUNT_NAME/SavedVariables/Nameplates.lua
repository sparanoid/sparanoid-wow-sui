
NameplatesDB = {
	["profileKeys"] = {
		["Dispel - 轻风之语"] = "Dispel - 轻风之语",
		["Smers - 海加尔"] = "Smers - 海加尔",
		["Salama - 艾萨拉"] = "Salama - 艾萨拉",
		["月影荣耀 - 无尽之海"] = "月影荣耀 - 无尽之海",
		["缠云格格 - 屠魔山谷"] = "缠云格格 - 屠魔山谷",
		["Frostbolt - 海加尔"] = "Smers - 海加尔",
	},
	["profiles"] = {
		["Smers - 海加尔"] = {
			["bindings"] = true,
			["text"] = {
				["size"] = 7,
			},
			["textureName"] = "Charcoal",
			["name"] = {
				["border"] = "OUTLINE",
				["size"] = 11,
			},
			["level"] = {
				["size"] = 6,
			},
			["barTexture"] = "Charcoal",
		},
		["Dispel - 轻风之语"] = {
		},
		["Frostbolt - 海加尔"] = {
			["barTexture"] = "Smooth",
		},
	},
}

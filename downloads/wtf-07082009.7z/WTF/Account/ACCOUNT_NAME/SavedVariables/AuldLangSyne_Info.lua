
AuldLangSyneInfoDB = nil


GreedBeaconDB = {
	["frame"] = "ChatFrame1",
}


AuldLangSyneNoteDB = nil

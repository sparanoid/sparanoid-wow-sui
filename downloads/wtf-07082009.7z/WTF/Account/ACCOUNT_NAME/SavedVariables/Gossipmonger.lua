
Gossipmonger_Settings = {
	["Filter_Standard"] = true,
	["informOnSkip_log"] = false,
	["delayShowingMirror"] = true,
	["greetingModifierKey"] = 3,
	["Version"] = "0.81",
	["informOnSkip_SCT"] = false,
	["showGossipMirrorOnSkip"] = true,
	["showGossipMirrorOnQuestSelect"] = true,
	["alwaysInformWithName"] = false,
	["skipIsDefault"] = true,
}

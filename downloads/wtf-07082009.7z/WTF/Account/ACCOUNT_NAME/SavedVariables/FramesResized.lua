
FramesResized_SV = {
	["QuestLog_Moveable"] = false,
	["TrainerUI_Moveable"] = false,
	["QuestLog_Resize"] = false,
	["LootFrame_Resize"] = false,
	["RaidInfo_Resize"] = true,
	["TraidSkillUI_Resize"] = true,
	["TraidSkillUI_Moveable"] = false,
	["TrainerUI_Resize"] = true,
}

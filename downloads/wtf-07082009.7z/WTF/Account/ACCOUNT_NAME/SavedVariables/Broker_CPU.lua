
BROKERCPUDB = {
	["memory_ldb"] = false,
	["ldbtextthreshold"] = 1,
	["framerate_ldb"] = true,
	["framerate"] = true,
	["scale"] = 1,
	["detach"] = false,
	["cpukill"] = 15,
	["minimap"] = false,
	["latency_ldb"] = true,
	["memory"] = true,
	["minimapdata"] = {
		["minimapPos"] = 3,
	},
	["tooltipthreshold"] = 1,
	["icons"] = true,
	["dewdrop"] = true,
	["qtip"] = true,
	["latency"] = true,
}


ChatGuardState = {
	["CareParty"] = true,
	["TrustFriend"] = false,
	["Debug"] = false,
	["CareNormal"] = true,
	["Alike"] = 75,
	["Disable"] = false,
	["CareRaid"] = true,
	["Interval"] = 30,
	["Filter"] = {
		"刷荣誉", -- [1]
		"代练", -- [2]
		"工作室", -- [3]
	},
	["CareSay"] = true,
	["RegEx"] = true,
	["CareWhisper"] = false,
	["CareGuild"] = true,
}

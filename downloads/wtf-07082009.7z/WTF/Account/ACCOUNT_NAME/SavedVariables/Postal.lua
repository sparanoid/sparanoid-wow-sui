
Postal3DB = {
	["profileKeys"] = {
		["Frostbolt - 海加尔"] = "Frostbolt - 海加尔",
		["Smers - 海加尔"] = "Smers - 海加尔",
	},
	["global"] = {
		["BlackBook"] = {
			["alts"] = {
				"Frostbolt|海加尔|Horde", -- [1]
				"Smers|海加尔|Horde", -- [2]
			},
		},
	},
	["profiles"] = {
		["Frostbolt - 海加尔"] = {
			["BlackBook"] = {
				["recent"] = {
					"Smers", -- [1]
					"我的彗星", -- [2]
					"嘘灬劫难", -- [3]
				},
				["contacts"] = {
					"Smers", -- [1]
				},
			},
		},
		["Smers - 海加尔"] = {
			["ModuleEnabledState"] = {
				["Select"] = false,
				["Rake"] = false,
			},
			["BlackBook"] = {
				["recent"] = {
					"小小奥法之尘", -- [1]
					"Frostbolt", -- [2]
					"小石头", -- [3]
					"啵啵蜜", -- [4]
					"月光酒", -- [5]
					"包装纸", -- [6]
					"雪雪球球雪球", -- [7]
					"矿工袋", -- [8]
					"小小的笨笨", -- [9]
					"鬼三笨笨", -- [10]
				},
				["contacts"] = {
					"Frostbolt", -- [1]
					"小小奥法之尘", -- [2]
				},
			},
		},
	},
}

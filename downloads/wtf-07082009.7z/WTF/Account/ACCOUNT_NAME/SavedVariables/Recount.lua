
RecountDB = {
	["profileKeys"] = {
		["Dispel - 轻风之语"] = "Dispel - 轻风之语",
		["Smers - 海加尔"] = "Smers - 海加尔",
		["Salama - 艾萨拉"] = "Salama - 艾萨拉",
		["月影荣耀 - 无尽之海"] = "月影荣耀 - 无尽之海",
		["缠云格格 - 屠魔山谷"] = "缠云格格 - 屠魔山谷",
		["Frostbolt - 海加尔"] = "Smers - 海加尔",
	},
	["profiles"] = {
		["Dispel - 轻风之语"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["Position"] = {
					["w"] = 139.9999979138375,
					["h"] = 199.9999970197678,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = 0,
			["CurDataSet"] = "OverallData",
			["GraphWindowX"] = 0,
			["MainWindowVis"] = false,
			["DetailWindowX"] = 0,
		},
		["Smers - 海加尔"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["ShowScrollbar"] = false,
				["Buttons"] = {
					["LeftButton"] = false,
					["ResetButton"] = false,
					["RightButton"] = false,
				},
				["BarText"] = {
					["Percent"] = false,
				},
				["Position"] = {
					["y"] = -168.9999745935205,
					["x"] = -699.0000048428773,
					["w"] = 179.999997317791,
					["h"] = 104.9999984353781,
				},
				["RowSpacing"] = 0,
			},
			["AutoDeleteNewInstance"] = false,
			["MaxFights"] = 25,
			["ConfirmDeleteInstance"] = false,
			["GroupFilters"] = {
				false, -- [1]
			},
			["ZoneFilters"] = {
				["arena"] = false,
				["none"] = false,
				["pvp"] = false,
			},
			["MainWindowHeight"] = 104.8280891056644,
			["DeleteNewInstanceOnly"] = false,
			["ClampToScreen"] = true,
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = -134.9999979883433,
			["ConfirmDeleteGroup"] = false,
			["DeleteJoinRaid"] = false,
			["DetailWindowX"] = 259.9999961256982,
			["DeleteJoinGroup"] = false,
			["AutoDelete"] = false,
			["HideCollect"] = true,
			["MainWindowVis"] = false,
			["BarTextColorSwap"] = false,
			["BarTexture"] = "Minimalist",
			["RealtimeWindows"] = {
				["Realtime_Downstream Traffic_DOWN_TRAFFIC"] = {
					"Downstream Traffic", -- [1]
					"DOWN_TRAFFIC", -- [2]
					"", -- [3]
					373.7500707246352, -- [4]
					-1.171874982537701, -- [5]
					200.000054240226, -- [6]
					232.0000041723251, -- [7]
					false, -- [8]
				},
				["Realtime_Bandwidth Available_AVAILABLE_BANDWIDTH"] = {
					"Bandwidth Available", -- [1]
					"AVAILABLE_BANDWIDTH", -- [2]
					"", -- [3]
					373.1250707339483, -- [4]
					-498.6328241432782, -- [5]
					336.2498805485683, -- [6]
					193.3281297485809, -- [7]
					false, -- [8]
				},
				["Realtime_!RAID_DAMAGE"] = {
					"!RAID", -- [1]
					"DAMAGE", -- [2]
					"Raid DPS", -- [3]
					0, -- [4]
					0, -- [5]
					200.000054240226, -- [6]
					232.0000041723251, -- [7]
					false, -- [8]
				},
				["Realtime_Upstream Traffic_UP_TRAFFIC"] = {
					"Upstream Traffic", -- [1]
					"UP_TRAFFIC", -- [2]
					"", -- [3]
					442.4999934062361, -- [4]
					-416.0157141683144, -- [5]
					200.000054240226, -- [6]
					232.0000041723251, -- [7]
					false, -- [8]
				},
			},
			["FilterDeathType"] = {
				["HEAL"] = false,
			},
			["Font"] = "Friz Quadrata TT",
			["GraphWindowX"] = 0,
			["ConfirmDeleteRaid"] = false,
			["MainWindowWidth"] = 179.999997317791,
			["CurDataSet"] = "LastFightData",
		},
		["Salama - 艾萨拉"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["Position"] = {
					["y"] = -239.0624582907191,
					["x"] = 543.7502589262983,
					["w"] = 254.9999389797458,
					["h"] = 181.2499210052204,
				},
			},
			["DetailWindowX"] = 0,
			["MainWindowHeight"] = 181.2499210052204,
			["CurDataSet"] = "OverallData",
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = 0,
			["MainWindowVis"] = false,
			["MainWindowWidth"] = 254.9999008327737,
			["GraphWindowX"] = 0,
		},
		["月影荣耀 - 无尽之海"] = {
			["MainWindow"] = {
				["Position"] = {
					["w"] = 139.9999979138375,
					["h"] = 199.9999970197678,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["CurDataSet"] = "OverallData",
		},
		["缠云格格 - 屠魔山谷"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["Position"] = {
					["w"] = 139.9999979138375,
					["h"] = 199.9999970197678,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = 0,
			["DetailWindowX"] = 0,
			["MainWindowVis"] = false,
			["CurDataSet"] = "OverallData",
			["GraphWindowX"] = 0,
		},
		["Frostbolt - 海加尔"] = {
			["MainWindowVis"] = false,
			["MainWindow"] = {
				["Position"] = {
					["y"] = -492.7733920101316,
					["x"] = 590.6252582278064,
					["w"] = 233.7499965168536,
					["h"] = 170.7030461623811,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["MainWindowHeight"] = 170.7030843093532,
			["MainWindowWidth"] = 233.7499965168536,
			["CurDataSet"] = "OverallData",
		},
	},
}

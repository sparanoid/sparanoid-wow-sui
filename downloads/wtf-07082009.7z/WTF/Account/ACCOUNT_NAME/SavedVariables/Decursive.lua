
DcrDB = {
	["classes"] = {
		["Priest"] = {
			["CureOrder"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				-14, -- [4]
				[32] = -16,
				[16] = 3,
				[8] = -15,
			},
		},
		["Mage"] = {
			["CureOrder"] = {
				-13, -- [1]
				-12, -- [2]
				nil, -- [3]
				-14, -- [4]
				[32] = 1,
				[16] = -16,
				[8] = -15,
			},
		},
		["Rogue"] = {
			["CureOrder"] = {
				-12, -- [1]
				-11, -- [2]
				nil, -- [3]
				-13, -- [4]
				[32] = -16,
				[16] = -15,
				[8] = -14,
			},
		},
		["Druid"] = {
			["CureOrder"] = {
				-12, -- [1]
				-11, -- [2]
				nil, -- [3]
				-13, -- [4]
				[32] = -16,
				[16] = -15,
				[8] = -14,
			},
		},
	},
	["disabled"] = {
		["Default"] = true,
	},
	["profiles"] = {
		["Default"] = {
			["Print_CustomFrame"] = false,
			["DebuffsFrameElemBorderAlpha"] = 0,
			["Hidden"] = true,
			["DebuffsFrame_y"] = -309.5994513571465,
			["Print_ChatFrame"] = false,
			["DebuffsFrameChrono"] = false,
			["MainBarX"] = 512.0000169542088,
			["NoKeyWarn"] = false,
			["MainBarY"] = -95.99999030431141,
			["Print_Error"] = false,
			["DebuffsFrameShowHelp"] = false,
			["Hide_LiveList"] = true,
			["MiniMapIcon"] = {
				["minimapPos"] = 180.708939223804,
				["radius"] = 80,
			},
			["DebuffsFrameMaxCount"] = 82,
			["DebuffsFrameElemAlpha"] = 0,
			["DebuffsFrame_x"] = 648.8005129396719,
		},
	},
}


gOutfitter_GlobalSettings = {
	["Version"] = 1,
	["SavedScripts"] = {
	},
}

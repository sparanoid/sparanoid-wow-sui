
Broker_RaidSaveConfig = {
	["formattime"] = "Show24",
	["instancedifforder"] = "desc",
	["formatdayw"] = false,
	["showdiff"] = true,
	["formatdate"] = "USAmerican",
	["sortbyinstancediff"] = false,
	["textwhenzero"] = true,
	["instancenameorder"] = "desc",
	["sortbyinstancename"] = true,
	["showreset"] = true,
	["showcooldown"] = true,
	["shorttext"] = false,
	["formatcooldown"] = "Full",
	["showid"] = true,
	["realm"] = {
		["屠魔山谷"] = {
			["char"] = {
				["缠云格格"] = {
					["instance"] = {
					},
					["class"] = "ROGUE",
					["name"] = "缠云格格",
					["numsaved"] = 0,
				},
			},
			["name"] = "屠魔山谷",
		},
		["轻风之语"] = {
			["char"] = {
				["Dispel"] = {
					["instance"] = {
					},
					["class"] = "PRIEST",
					["name"] = "Dispel",
					["numsaved"] = 0,
				},
			},
			["name"] = "轻风之语",
		},
		["艾萨拉"] = {
			["char"] = {
				["Salama"] = {
					["instance"] = {
					},
					["class"] = "SHAMAN",
					["name"] = "Salama",
					["numsaved"] = 0,
				},
			},
			["name"] = "艾萨拉",
		},
		["海加尔"] = {
			["char"] = {
				["Frostbolt"] = {
					["instance"] = {
					},
					["class"] = "MAGE",
					["name"] = "Frostbolt",
					["numsaved"] = 0,
				},
				["Smers"] = {
					["instance"] = {
						{
							["id"] = 9962830,
							["difficulty"] = 1,
							["name"] = "Tempest Keep",
							["expires"] = 1244501841,
						}, -- [1]
						{
							["id"] = 9978942,
							["difficulty"] = 1,
							["name"] = "Magtheridon's Lair",
							["expires"] = 1244501841,
						}, -- [2]
						{
							["id"] = 9984434,
							["difficulty"] = 1,
							["name"] = "Black Temple",
							["expires"] = 1244501841,
						}, -- [3]
						{
							["id"] = 9976561,
							["difficulty"] = 1,
							["name"] = "Gruul's Lair",
							["expires"] = 1244501841,
						}, -- [4]
						{
							["id"] = 9966765,
							["difficulty"] = 1,
							["name"] = "Molten Core",
							["expires"] = 1244501841,
						}, -- [5]
						{
							["id"] = 9964608,
							["difficulty"] = 1,
							["name"] = "Karazhan",
							["expires"] = 1244501841,
						}, -- [6]
					},
					["class"] = "PRIEST",
					["name"] = "Smers",
					["numsaved"] = 6,
				},
			},
			["name"] = "海加尔",
		},
	},
}

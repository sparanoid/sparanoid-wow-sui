
MendeleevDB = {
	["profileKeys"] = {
		["Dispel - 轻风之语"] = "Dispel - 轻风之语",
		["Smers - 海加尔"] = "Smers - 海加尔",
		["Salama - 艾萨拉"] = "Salama - 艾萨拉",
		["月影荣耀 - 无尽之海"] = "月影荣耀 - 无尽之海",
		["缠云格格 - 屠魔山谷"] = "缠云格格 - 屠魔山谷",
		["Frostbolt - 海加尔"] = "Frostbolt - 海加尔",
	},
	["profiles"] = {
		["缠云格格 - 屠魔山谷"] = {
		},
		["Smers - 海加尔"] = {
			["sets"] = {
				["Consumable.Food"] = false,
				["Tradeskill.Mat.ByProfession"] = true,
				["Misc.Reagent.Class"] = false,
				["Tradeskill.Gather"] = false,
				["Tradeskill.Recipe"] = false,
				["Tradeskill.Crafted"] = false,
				["Tradeskill.Gather.GemsInNodes"] = false,
				["Misc.Container.ItemsInType"] = true,
				["Misc"] = false,
			},
			["showUsedInTree"] = false,
			["showItemLevel"] = true,
			["UsedInTreeIcons"] = false,
		},
		["Dispel - 轻风之语"] = {
		},
		["Frostbolt - 海加尔"] = {
			["showItemLevel"] = true,
			["showItemCount"] = true,
			["UsedInTreeIcons"] = false,
			["showUsedInTree"] = false,
		},
	},
}

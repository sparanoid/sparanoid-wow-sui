
_NPCScanOptions = {
	["Version"] = "3.0.9.2",
}

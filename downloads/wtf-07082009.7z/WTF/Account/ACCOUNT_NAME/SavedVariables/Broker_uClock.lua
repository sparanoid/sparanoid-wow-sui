
uClockDB = {
	["profileKeys"] = {
		["缠云格格 - 屠魔山谷"] = "Default",
		["Frostbolt - 海加尔"] = "Default",
		["Dispel - 轻风之语"] = "Default",
		["Smers - 海加尔"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["showRealm"] = true,
			["showLocal"] = false,
		},
	},
}

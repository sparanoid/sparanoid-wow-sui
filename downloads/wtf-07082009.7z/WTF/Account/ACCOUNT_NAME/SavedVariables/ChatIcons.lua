
ChatIconsDB = {
	["items"] = true,
	["autosize"] = false,
	["achievements"] = true,
	["class"] = false,
	["offset"] = -3,
	["spells"] = true,
	["exampleFontSize"] = 14,
	["size"] = 16,
}

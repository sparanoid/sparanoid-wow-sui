
AuldLangSyneSyncDB = nil

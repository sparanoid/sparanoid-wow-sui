
AraTradeskillsDB = {
	["forceCDRemoval"] = false,
	["海加尔"] = {
		["Smers"] = {
			["skill"] = "Tailoring",
			["maxSkills"] = {
				["Cooking"] = 375,
				["Fishing"] = 375,
				["Tailoring"] = 375,
				["First Aid"] = 375,
				["Enchanting"] = 375,
			},
			["show"] = {
				["Tailoring"] = true,
				["Defense"] = false,
				["Fishing"] = false,
				["Daggers"] = false,
				["First Aid"] = true,
				["Cooking"] = true,
				["Staves"] = false,
				["Unarmed"] = false,
				["Wands"] = false,
				["Maces"] = false,
				["Enchanting"] = true,
			},
			[31373] = 1244250997,
			[36686] = 1244623261,
			["shortcuts"] = {
				[27033] = "First Aid",
				[22813] = "Tailoring",
				[42620] = "Enchanting",
				[45765] = "Enchanting",
				[33286] = "Cooking",
				[26745] = "Tailoring",
			},
			["curSkills"] = {
				["Cooking"] = 375,
				["Fishing"] = 375,
				["Tailoring"] = 375,
				["First Aid"] = 375,
				["Enchanting"] = 375,
			},
			[26751] = 1244250997,
			["links"] = {
				["Tailoring"] = "|cffffd000|Htrade:26790:375:375:ED1B0D:t{{{{{{{w{{k{{ko{{{uy{kUs{{{Y{k[uw{sm{C[x{sb{l{{ZtQ=z{Ot=<<<<<<<<<<<<<|h[Tailoring]|h|r",
				["Cooking"] = "|cffffd000|Htrade:33359:375:375:ED1B0D:r{w{{{w{{{y{{{{{{{C<<<<<<<{[|h[Cooking]|h|r",
				["First Aid"] = "|cffffd000|Htrade:27028:375:375:ED1B0D:xG{_yK|h[First Aid]|h|r",
				["Enchanting"] = "|cffffd000|Htrade:28029:375:375:ED1B0D:t{{{{{[z{{ww{{s{{k{kWskLz{Sysp^<ws{?{C<<<<<<d=<<<<|h[Enchanting]|h|r",
			},
		},
		["Frostbolt"] = {
			["show"] = {
				["Defense"] = false,
				["Herbalism"] = false,
				["Daggers"] = false,
				["First Aid"] = true,
				["Smelting"] = true,
				["Cooking"] = true,
				["Staves"] = false,
				["Swords"] = false,
				["Wands"] = false,
				["Fishing"] = false,
				["Unarmed"] = false,
			},
			["shortcuts"] = {
			},
			["maxSkills"] = {
				["Cooking"] = 75,
				["Herbalism"] = 150,
				["Fishing"] = 75,
				["First Aid"] = 150,
				["Smelting"] = 150,
			},
			["curSkills"] = {
				["Cooking"] = 40,
				["Herbalism"] = 81,
				["Fishing"] = 75,
				["First Aid"] = 80,
				["Smelting"] = 58,
			},
			["links"] = {
				["First Aid"] = "|cffffd000|Htrade:3274:80:150:110A070:ZD<<t<|h[First Aid]|h|r",
			},
		},
	},
	["屠魔山谷"] = {
		["缠云格格"] = {
			["shortcuts"] = {
			},
			["show"] = {
			},
			["curSkills"] = {
			},
			["maxSkills"] = {
			},
		},
	},
	["icons"] = {
		[28570] = "Interface\\Icons\\INV_Potion_151",
		[27033] = "Interface\\Icons\\INV_Misc_Bandage_Netherweave_Heavy",
		[28027] = "Interface\\Icons\\INV_Enchant_PrismaticSphere",
		[18401] = "Interface\\Icons\\INV_Fabric_PurpleFire_02",
		[26745] = "Interface\\Icons\\INV_Fabric_Netherweave_Bolt",
		[33286] = "Interface\\Icons\\INV_Misc_Food_86_Basilisk",
		[28028] = "Interface\\Icons\\INV_Enchant_VoidSphere",
		[31373] = "Interface\\Icons\\INV_Fabric_Spellfire",
		[26750] = "Interface\\Icons\\INV_Fabric_Soulcloth_Bolt",
		[36686] = "Interface\\Icons\\INV_Fabric_Felcloth_Ebon",
		[22813] = "Interface\\Icons\\INV_Chest_Chain_14",
		[26751] = "Interface\\Icons\\INV_Fabric_MoonRag_Primal",
		[42620] = "Interface\\Icons\\Spell_Holy_GreaterHeal",
		[45765] = "Interface\\Icons\\INV_Enchant_ShardPrismaticLarge",
	},
	["names"] = {
		[28570] = "Elixir of Major Mageblood",
		[27033] = "Heavy Netherweave Bandage",
		[28027] = "Prismatic Sphere",
		[18401] = "Bolt of Runecloth",
		[26745] = "Bolt of Netherweave",
		[33286] = "Blackened Basilisk",
		[28028] = "Void Sphere",
		[31373] = "Spellcloth",
		[26750] = "Bolt of Soulcloth",
		[36686] = "Shadowcloth",
		[22813] = "Gordok Ogre Suit",
		[26751] = "Primal Mooncloth",
		[42620] = "Enchant Weapon - Greater Agility",
		[45765] = "Void Shatter",
	},
	["primaryOnly"] = false,
	["hideAlts"] = true,
	["colors"] = {
		["foreignCD"] = {
			0.6, -- [1]
			0.5, -- [2]
			0, -- [3]
		},
		["header"] = {
			1, -- [1]
			1, -- [2]
			1, -- [3]
		},
		["ownCD"] = {
			1, -- [1]
			0.82, -- [2]
			0, -- [3]
		},
		["activeName"] = {
			1, -- [1]
			0.82, -- [2]
			0, -- [3]
		},
		["selected"] = {
			0.9, -- [1]
			0.45, -- [2]
			0.1, -- [3]
		},
		["infoName"] = {
			0.6, -- [1]
			0.5, -- [2]
			0, -- [3]
		},
		["highlight"] = {
			1, -- [1]
			0.8, -- [2]
			0, -- [3]
		},
	},
	["轻风之语"] = {
		["Dispel"] = {
			["shortcuts"] = {
			},
			["show"] = {
			},
			["curSkills"] = {
			},
			["maxSkills"] = {
			},
		},
	},
	["displayCDs"] = false,
	["aliases"] = {
	},
	["addReadyCD"] = true,
	["hideSkillNames"] = false,
}


AuldLangSyneFuDB = nil

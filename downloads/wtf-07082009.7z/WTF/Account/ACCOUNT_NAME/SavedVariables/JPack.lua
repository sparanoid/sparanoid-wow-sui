
JPackDB = {
	["asc"] = true,
}
JPackMMIconDB = {
	["minimapPos"] = 312.5488943428111,
	["radius"] = 80,
}


TipTac_Config = {
	["showUnitTip"] = true,
	["showRealm"] = "show",
	["colReactText4"] = "|cffffff00",
	["barHeight"] = 12,
	["manaBarColor"] = {
		0.3490196078431372, -- [1]
		0.6235294117647059, -- [2]
		0.8980392156862745, -- [3]
		1, -- [4]
	},
	["anchorPoint"] = "TOPLEFT",
	["colReactBack1"] = {
		0.2, -- [1]
		0.2, -- [2]
		0.2, -- [3]
		1, -- [4]
	},
	["backdropEdgeSize"] = 17,
	["powerBar"] = true,
	["fontFlags"] = "OUTLINE",
	["showAuraCooldown"] = true,
	["colReactBack7"] = {
		0.05, -- [1]
		0.05, -- [2]
		0.05, -- [3]
		1, -- [4]
	},
	["showDebuffs"] = true,
	["powerBarText"] = "auto",
	["colReactText1"] = "|cffc0c0c0",
	["healthBarClassColor"] = true,
	["barFontFlags"] = "OUTLINE",
	["classification_rare"] = "Level %s|cffff66ff Rare",
	["colReactBack2"] = {
		0.3, -- [1]
		0, -- [2]
		0, -- [3]
		1, -- [4]
	},
	["optionsBottom"] = 430.5466397025192,
	["colReactText3"] = "|cffff7f00",
	["hideAllTipsInCombat"] = false,
	["iconSize"] = 20,
	["nameType"] = "title",
	["anchorFrameUnitType"] = "parent",
	["anchorFrameUnitPoint"] = "BOTTOMRIGHT",
	["manaBar"] = true,
	["gradientColor"] = {
		0.9921568627450981, -- [1]
		0.9882352941176471, -- [2]
		1, -- [3]
		0.1200000047683716, -- [4]
	},
	["tempInformantFix"] = false,
	["updateFreq"] = 0.05000000074505806,
	["fadeTime"] = 0.5,
	["targetYouText"] = "|cffff0000 <YOU>",
	["tipBorderColor"] = {
		0, -- [1]
		0, -- [2]
		0, -- [3]
		1, -- [4]
	},
	["showGuildRank"] = true,
	["itemQualityBorder"] = true,
	["gradientTip"] = true,
	["colReactText7"] = "|cff808080",
	["showIcon"] = true,
	["barFontSize"] = 11,
	["pvpName"] = true,
	["auraSize"] = 24,
	["colReactBack4"] = {
		0.3, -- [1]
		0.3, -- [2]
		0, -- [3]
		1, -- [4]
	},
	["gttScale"] = 1,
	["colReactBack5"] = {
		0, -- [1]
		0.3019607843137255, -- [2]
		0.1019607843137255, -- [3]
		1, -- [4]
	},
	["classColoredBorder"] = true,
	["modifyFonts"] = true,
	["hideWorldTips"] = false,
	["overrideFade"] = true,
	["colReactBack3"] = {
		0.3, -- [1]
		0.15, -- [2]
		0, -- [3]
		1, -- [4]
	},
	["preFadeTime"] = 3,
	["optionsLeft"] = 508.0004425644809,
	["anchorWorldTipPoint"] = "CENTER",
	["reactText"] = false,
	["colReactText2"] = "|cffff0000",
	["tipBackdropEdge"] = "Interface\\Tooltips\\UI-Tooltip-Border",
	["tipBackdropBG"] = "Interface\\Tooltips\\UI-Tooltip-Background",
	["colRace"] = "|cffddeeaa",
	["tipColor"] = {
		0, -- [1]
		0, -- [2]
		0, -- [3]
		0.9400000013411045, -- [4]
	},
	["hideDefaultBar"] = true,
	["mouseOffsetX"] = 0,
	["healthBarText"] = "auto",
	["colReactText5"] = "|cff00ff00",
	["classification_worldboss"] = "Level %s|cffff0000 Boss",
	["classification_normal"] = "Level %s",
	["colLevel"] = "|cffffcc00",
	["mouseOffsetY"] = 0,
	["anchorFrameTipType"] = "parent",
	["anchorType"] = "smart",
	["colReactText6"] = "|cff25c1eb",
	["barFontFace"] = "Fonts\\FRIZQT__.TTF",
	["showStatus"] = true,
	["manaBarText"] = "auto",
	["showBuffs"] = false,
	["showTarget"] = "first",
	["fontSize"] = 12,
	["anchorWorldTipType"] = "normal",
	["selfBuffsOnly"] = false,
	["aurasAtBottom"] = true,
	["anchorTypeUnit"] = "smart",
	["selfDebuffsOnly"] = false,
	["showTargetedBy"] = true,
	["reactColoredBorder"] = false,
	["iconAnchor"] = "TOPLEFT",
	["anchorWorldUnitPoint"] = "CENTER",
	["reactColoredBackdrop"] = true,
	["backdropInsets"] = 3.5,
	["auraMaxRows"] = 1,
	["healthBar"] = true,
	["fontFace"] = "Fonts\\FRIZQT__.TTF",
	["showTalents"] = false,
	["colorNameByClass"] = true,
	["talentFormat"] = 2,
	["colSameGuild"] = "|cffff9698",
	["anchorWorldUnitType"] = "normal",
	["healthBarColor"] = {
		0.3, -- [1]
		0.9, -- [2]
		0.3, -- [3]
		1, -- [4]
	},
	["classification_rareelite"] = "Level %s|cffffaaff Rare Elite",
	["hideUFTipsInCombat"] = false,
	["left"] = 745.4998668208738,
	["top"] = 1142.859022276714,
	["anchorPointUnit"] = "TOPLEFT",
	["hookTips"] = true,
	["colReactBack6"] = {
		0, -- [1]
		0, -- [2]
		0.5019607843137255, -- [3]
		1, -- [4]
	},
	["barTexture"] = "Interface\\Addons\\Gladius\\images\\Minimalist",
	["anchorFrameTipPoint"] = "TOP",
	["classification_elite"] = "Level %s|cffffcc00 Elite",
}

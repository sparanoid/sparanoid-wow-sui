
AuldLangSyneFriendListDB = nil


AtlasLootOptions = nil
AtlasLootDB = {
	["profileKeys"] = {
		["Dispel - 轻风之语"] = "Dispel - 轻风之语",
		["Smers - 海加尔"] = "Smers - 海加尔",
		["Salama - 艾萨拉"] = "Salama - 艾萨拉",
		["月影荣耀 - 无尽之海"] = "月影荣耀 - 无尽之海",
		["缠云格格 - 屠魔山谷"] = "缠云格格 - 屠魔山谷",
		["Frostbolt - 海加尔"] = "Frostbolt - 海加尔",
	},
	["profiles"] = {
		["Dispel - 轻风之语"] = {
			["AtlasLootVersion"] = "50500",
			["AllLinks"] = false,
		},
		["Smers - 海加尔"] = {
			["EquipCompare"] = true,
			["HeroicMode"] = true,
			["AllLinks"] = false,
			["Bigraid"] = true,
			["AtlasLootVersion"] = "50303",
			["HidePanel"] = true,
			["LastBoss"] = "HCMagtheridon",
		},
		["Salama - 艾萨拉"] = {
			["AllLinks"] = false,
			["AtlasLootVersion"] = "50303",
		},
		["月影荣耀 - 无尽之海"] = {
		},
		["缠云格格 - 屠魔山谷"] = {
			["AllLinks"] = false,
			["AtlasLootVersion"] = "50402",
		},
		["Frostbolt - 海加尔"] = {
			["AllLinks"] = false,
			["LastBoss"] = "DeadlyGladiatorWeapons1",
			["AtlasLootVersion"] = "50303",
		},
	},
}

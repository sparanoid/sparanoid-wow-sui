
BaudAuctionConfig = {
	["MatchBid"] = true,
	["LastTime"] = 3,
}


FatalityDB = {
	["enabled"] = true,
}

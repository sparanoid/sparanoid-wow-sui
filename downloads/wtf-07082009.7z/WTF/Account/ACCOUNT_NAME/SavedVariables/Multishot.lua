
MultishotConfig = {
	["raid"] = false,
	["bosskill"] = false,
	["delay"] = 0.8,
	["party"] = false,
}

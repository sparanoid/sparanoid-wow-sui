
NxData = {
	["NXHUDOpts"] = {
		["Version"] = 0.03,
	},
	["NXGOpts"] = {
		["BGShowStats"] = true,
		["MapShowOthersInZ"] = true,
		["MapShowOthersInCities"] = false,
		["GryphonsHide"] = true,
		["QSnd7"] = false,
		["MapMMOwn"] = false,
		["RouteMergeRadius"] = 20,
		["QSnd2"] = false,
		["QMapWatchC7"] = 4286513407,
		["MapMMButShowCarb"] = false,
		["ChatMsgFrm"] = "General",
		["MapShowCTown"] = false,
		["MapShowTitle2"] = false,
		["PunkShowInBG"] = true,
		["MenuCenterV"] = false,
		["QWKeyUseItem"] = "",
		["MapMMButCorner"] = "TopRight",
		["QWFadeAll"] = false,
		["MapIconGatherA"] = 0.7,
		["MapLineThick"] = 0,
		["QWGrowUp"] = false,
		["MapMMDockRight"] = false,
		["PunkMAlertSnd"] = true,
		["FontMSize"] = 13,
		["QWOCompleteColor"] = 2885647871,
		["InfoToG"] = true,
		["InfoLvlUpShow"] = true,
		["QSnd6"] = true,
		["QWAddChanged"] = true,
		["HUDTButCombatColor"] = 4278190106,
		["FontWarehouseI"] = "ABF",
		["MapButRCtrl"] = "None",
		["EmuCartWP"] = true,
		["MapMMDXO"] = 0,
		["QMapWatchAreaAlpha"] = 4294967136,
		["MMButWinMinimize"] = false,
		["PunkIconColor"] = 4286611711,
		["Version"] = 0.102,
		["FontMenu"] = "ABF",
		["TitleOff"] = true,
		["MapMMSquare"] = false,
		["MapShowCExtra"] = true,
		["PunkShowInNorthrend"] = true,
		["MapShowPunks"] = true,
		["QMapWatchC10"] = 2147418367,
		["FontMapLocSize"] = 13,
		["FontWarehouseISize"] = 12,
		["OptsQuickVer"] = 5,
		["HUDTButColor"] = 5,
		["MapShowTrail"] = true,
		["QWCompleteColor"] = 1239547903,
		["CaptureEnable"] = true,
		["MapWOwn"] = true,
		["QBroadcastQChangesNum"] = 1,
		["FontSH"] = 0,
		["QWRemoveComplete"] = false,
		["SkinWinBdColor"] = 3435986943,
		["MapButMCtrl"] = "None",
		["QSnd5"] = false,
		["QWHideRaid"] = false,
		["QAddTooltip"] = true,
		["PunkNewLocalWarnChat"] = true,
		["MapMMHideOnMax"] = false,
		["ComNoGlobal"] = true,
		["QMapWatchAreaGfx"] = "Solid",
		["QSnd3"] = false,
		["FontWatchSize"] = 13,
		["FontInfoSize"] = 12,
		["FontInfoH"] = 0,
		["MapLocTipAnchorRel"] = "None",
		["MapMMAboveIcons"] = false,
		["MapShowToolBar"] = true,
		["MapIconScaleMin"] = -1,
		["MapBut4Alt"] = "Add Note",
		["FontSSize"] = 12,
		["FontMapSize"] = 12,
		["MapMMButSpacing"] = 29,
		["MapShowCCity"] = false,
		["QWHideDoneObj"] = false,
		["MapMaxCenter"] = true,
		["PunkMAlertText"] = true,
		["MapMMButShowWorldMap"] = false,
		["FontWatchH"] = 2,
		["MapTrailCnt"] = 100,
		["MapMaxOverride"] = true,
		["MapMMButShowCalendar"] = true,
		["QAutoTurnIn"] = true,
		["MapButRAlt"] = "None",
		["HUDAYO"] = 0,
		["MapZoneDrawCnt"] = 3,
		["QShowLinkExtra"] = true,
		["MapButLAlt"] = "Add Note",
		["MapMMDockIndoors"] = false,
		["MapShowTitleXY"] = true,
		["QMapWatchC4"] = 4294902015,
		["QSndPlayCompleted"] = true,
		["WarehouseAddTooltip"] = false,
		["HUDASize"] = 44,
		["MapTrailDist"] = 2,
		["QWLargeFont"] = false,
		["IWinEnable"] = true,
		["InfoToF"] = true,
		["MapTrailTime"] = 90,
		["QWAddNew"] = true,
		["MapShowTitleName"] = true,
		["FontQuest"] = "Friz",
		["MapMMDYO"] = 0,
		["ComNoZone"] = true,
		["MapIconPOIAlpha"] = 1,
		["MapMMDockIScale"] = 1,
		["FontMap"] = "ABF",
		["QSnd1"] = false,
		["HUDTBut"] = false,
		["FontWatch"] = "ABF",
		["MapLocTipAnchor"] = "TopLeft",
		["InfoToZ"] = true,
		["QMapWatchC6"] = 4278255615,
		["MapRestoreScaleAfterTrack"] = true,
		["SocialEnable"] = false,
		["MapMMButOwn"] = false,
		["CameraForceMaxDist"] = true,
		["QMapWatchC3"] = 859045887,
		["PunkTWinTitle"] = "Punks:",
		["QMapWatchColorCnt"] = 12,
		["PunkAreaSize"] = 80,
		["QWBGColor"] = 85,
		["TeamTWinEnable"] = true,
		["QPartyShare"] = true,
		["MapPlyrArrowSize"] = 32,
		["MapMMInstanceTogFullSize"] = false,
		["QMapWatchAreaHoverColor"] = 4294967192,
		["MapBut4Ctrl"] = "None",
		["FontMH"] = 0,
		["GuideVendorVMax"] = 60,
		["QLevelsToLoad"] = 80,
		["QBroadcastQChanges"] = true,
		["MapMMMoveCapBars"] = false,
		["MapMMButColumns"] = 1,
		["IWinListCol"] = 0,
		["QMapWatchC8"] = 16744447,
		["MapMMShowOldNameplate"] = true,
		["QMapShowWatchAreas"] = true,
		["QMapQuestGiversLowLevel"] = 80,
		["QMapWatchC1"] = 4278190335,
		["TeamTWinMaxButs"] = 15,
		["MapMMDockOnMax"] = false,
		["MapTopTooltip"] = false,
		["SkinName"] = "ToolBlue",
		["IWinLock"] = true,
		["NXCleaned"] = true,
		["QWShowPerColor"] = false,
		["MapShowPOI"] = false,
		["MapMMIndoorTogFullSize"] = false,
		["QMapWatchC9"] = 2131886079,
		["MapMMIScale"] = 1,
		["MapMaxRestoreHide"] = false,
		["CaptureShare"] = true,
		["HUDAGfx"] = "Gloss",
		["MapMMDockBottom"] = false,
		["WarehouseEnable"] = false,
		["QMapWatchAreaTrackColor"] = 2964369536,
		["MapShowNotes"] = true,
		["FontQuestH"] = 1,
		["QMapWatchC5"] = 16777215,
		["QSnd8"] = false,
		["PunkAreaColor"] = 2974633261,
		["HUDHideInBG"] = true,
		["PunkBGAreaSize"] = 60,
		["PunkMAreaSize"] = 200,
		["FontS"] = "ABF",
		["QWFixedSize"] = true,
		["PunkShowInSafeArea"] = false,
		["PunkNewLocalWarnSnd"] = true,
		["MapShowTitleSpeed"] = true,
		["PunkMAreaColor"] = 409999615,
		["QWOIncompleteColor"] = 4294561279,
		["MapButLCtrl"] = "Goto",
		["MapButR"] = "Menu",
		["FontWarehouseIH"] = 6,
		["RouteRecycle"] = false,
		["MapMMDockSquare"] = false,
		["LoginHideVer"] = true,
		["TitleSoundOn"] = false,
		["HUDShowDir"] = false,
		["FontMapLoc"] = "ABF",
		["QWShowClose"] = false,
		["MapMaxMouseIgnore"] = false,
		["MapButM"] = "Show Player Zone",
		["FontInfo"] = "Friz",
		["MapButMAlt"] = "None",
		["EmuTomTom"] = true,
		["PunkTWinMaxButs"] = 5,
		["QSideBySide"] = true,
		["MenuCenterH"] = false,
		["SkinDef"] = false,
		["HUDHide"] = false,
		["QShowDailyReset"] = true,
		["QMapWatchC11"] = 8388607,
		["PunkBGAreaColor"] = 604572159,
		["MapMMDockAlways"] = false,
		["QMapWatchC2"] = 16711935,
		["QMapWatchC12"] = 4278222847,
		["SkinWinSizedBgColor"] = 522133472,
		["MapDetailSize"] = 6,
		["RouteGatherRadius"] = 60,
		["FontMenuSize"] = 12,
		["ItemRequest"] = false,
		["QSnd4"] = false,
		["MapBut4"] = "Show Selected Zone",
		["FontQuestSize"] = 12,
		["FontM"] = "ABF",
		["MapRouteUse"] = true,
		["QShowId"] = false,
		["SkinWinFixedBgColor"] = 2155905152,
		["QWBlizzModify"] = true,
		["HUDAXO"] = 0,
		["MapShowPalsInCities"] = true,
		["QWIncompleteColor"] = 4288413951,
		["QUseAltLKey"] = false,
		["QMapWatchColorPerQ"] = true,
		["DemoShown"] = true,
		["QWShowDist"] = false,
	},
	["NXTravel"] = {
		["Version"] = 0.1,
		["TaxiTime"] = {
			["Silvermoon City#Tranquillien"] = 65.66999999999825,
			["Hammerfall#Kargath"] = 259.616,
			["Undercity#Kargath"] = 488.4009999999998,
			["Grom'gol#Flame Crest"] = 198.1809999999969,
			["Undercity#Hammerfall"] = 301.1610000000001,
			["Stonard#Kargath"] = 231.4089999999997,
			["Tranquillien#Zul'Aman"] = 51.69499999999971,
			["Grom'gol#Stonard"] = 173.6530000000057,
			["Undercity#Light's Hope Chapel"] = 262.1650000000009,
			["Undercity#Tarren Mill"] = 145.3489999999874,
			["Flame Crest#Kargath"] = 81.77499999999418,
			["The Sepulcher#Undercity"] = 111.9130000000005,
			["Kargath#Flame Crest"] = 68.49399999999969,
			["Undercity#The Sepulcher"] = 106.4800000000032,
			["Grom'gol#Booty Bay"] = 78.57499999999891,
			["Booty Bay#Grom'gol"] = 75.06999999999971,
			["Tarren Mill#The Sepulcher"] = 103.711000000003,
			["Kargath#Booty Bay"] = 298.3539999999994,
			["Stonard#Flame Crest"] = 176.1009999999951,
			["Light's Hope Chapel#Revantusk Village"] = 141.6909999999989,
			["Undercity#Revantusk Village"] = 285.1359999999986,
			["Tarren Mill#Undercity"] = 139.3110000000015,
			["Light's Hope Chapel#Undercity"] = 261.0849999999991,
		},
	},
	["NXGather"] = {
		["Version"] = 0.5,
		["Misc"] = {
		},
		["NXHerb"] = {
			[3008] = {
				[40] = {
					"7a0524^1", -- [1]
					"7db519^2", -- [2]
					"72d58d^1", -- [3]
					"74257f^1", -- [4]
					"6b8512^1", -- [5]
					"680515^1", -- [6]
					"6665cf^1", -- [7]
					"65658a^2", -- [8]
					"64c618^1", -- [9]
				},
			},
		},
		["NXMine"] = {
		},
	},
	["Characters"] = {
		["海加尔.Smers"] = {
			["ArenaPts"] = 1607,
			["WareInv"] = {
				"HeadSlot^|cffa335ee|Hitem:31064:3002:3261:3318:0:0:0:0:70|h[Hood of Absolution]|h|r", -- [1]
				"NeckSlot^|cffa335ee|Hitem:32589:0:0:0:0:0:0:773873522:70|h[Hellfire-Encased Pendant]|h|r", -- [2]
				"ShoulderSlot^|cffa335ee|Hitem:31070:2982:3340:3318:0:0:0:0:70|h[Shoulderpads of Absolution]|h|r", -- [3]
				"BackSlot^|cffa335ee|Hitem:32524:2621:0:0:0:0:0:1741610695:70|h[Shroud of the Highborne]|h|r", -- [4]
				"ChestSlot^|cffa335ee|Hitem:31065:1144:3127:3127:3318:0:0:0:70|h[Shroud of Absolution]|h|r", -- [5]
				"ShirtSlot^|cffffffff|Hitem:3342:0:0:0:0:0:0:1874160162:70|h[Captain Sanders' Shirt]|h|r", -- [6]
				"TabardSlot^|cffa335ee|Hitem:23709:0:0:0:0:0:0:1202750936:70|h[Tabard of Frost]|h|r", -- [7]
				"WristSlot^|cffa335ee|Hitem:34434:2650:3140:0:0:0:0:0:70|h[Bracers of Absolution]|h|r", -- [8]
				"HandsSlot^|cffa335ee|Hitem:31061:2937:3127:0:0:0:0:0:70|h[Handguards of Absolution]|h|r", -- [9]
				"WaistSlot^|cffa335ee|Hitem:34528:0:3127:0:0:0:0:0:70|h[Cord of Absolution]|h|r", -- [10]
				"LegsSlot^|cffa335ee|Hitem:34181:2746:3117:3117:3127:0:0:1245152637:70|h[Leggings of Calamity]|h|r", -- [11]
				"FeetSlot^|cffa335ee|Hitem:34563:2658:3318:0:0:0:0:0:70|h[Treads of Absolution]|h|r", -- [12]
				"Finger0Slot^|cffa335ee|Hitem:29305:2928:0:0:0:0:0:1679807118:70|h[Band of the Eternal Sage]|h|r", -- [13]
				"Finger1Slot^|cffa335ee|Hitem:33497:2928:0:0:0:0:0:1395163172:70|h[Mana Attuned Band]|h|r", -- [14]
				"Trinket0Slot^|cffa335ee|Hitem:33829:0:0:0:0:0:0:1559367253:70|h[Hex Shrunken Head]|h|r", -- [15]
				"Trinket1Slot^|cff0070dd|Hitem:32863:0:0:0:0:0:0:917689470:70|h[Skybreaker Whip]|h|r", -- [16]
				"MainHandSlot^|cffa335ee|Hitem:34009:2669:0:0:0:0:0:1233702055:70|h[Hammer of Judgement]|h|r", -- [17]
				"SecondaryHandSlot^|cffa335ee|Hitem:30872:0:0:0:0:0:0:-1728245216:70|h[Chronicle of Dark Secrets]|h|r", -- [18]
				"RangedSlot^|cffa335ee|Hitem:33192:0:3064:0:0:0:0:0:70|h[Carved Witch Doctor's Stick]|h|r", -- [19]
				"Bag0Slot^|cffa335ee|Hitem:38082:0:0:0:0:0:0:0:70|h[\"Gigantique\" Bag]|h|r", -- [20]
				"Bag1Slot^|cff1eff00|Hitem:21843:0:0:0:0:0:0:921193036:70|h[Imbued Netherweave Bag]|h|r", -- [21]
				"Bag2Slot^|cff0070dd|Hitem:22679:0:0:0:0:0:0:277837994:70|h[Supply Bag]|h|r", -- [22]
				"Bag3Slot^|cff0070dd|Hitem:34067:0:0:0:0:0:0:452031469:70|h[Tattered Hexcloth Sack]|h|r", -- [23]
			},
			["Profs"] = {
				["Cooking"] = {
					["Rank"] = 375,
				},
				["Fishing"] = {
					["Rank"] = 375,
				},
				["Tailoring"] = {
					["Rank"] = 375,
				},
				["First Aid"] = {
					["Rank"] = 375,
				},
				["Enchanting"] = {
					["Rank"] = 375,
				},
			},
			["LXP"] = 489,
			["LHonor"] = 37077,
			["DurLowPercent"] = 100,
			["Opts"] = {
				["MapShowGatherH"] = false,
				["QMapShowQuestGivers3"] = 3,
				["MapShowGatherM"] = false,
			},
			["XPMax"] = 1523800,
			["NXLoggedOnNum"] = 1,
			["E"] = {
				["Info"] = {
					{
						["NXX"] = 16.13217741250992,
						["NXY"] = 39.31713402271271,
						["NXName"] = "Entered",
						["NXTime"] = 1244038603.000083,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [1]
					{
						["NXX"] = 42.85419583320618,
						["NXY"] = 42.55176186561585,
						["NXName"] = "Entered",
						["NXTime"] = 1244039001.000084,
						["T"] = "I",
						["NXMapId"] = 3002,
					}, -- [2]
					{
						["NXX"] = 47.56401777267456,
						["NXY"] = 52.05346345901489,
						["NXName"] = "Entered",
						["NXTime"] = 1244039105.000085,
						["T"] = "I",
						["NXMapId"] = 13052,
					}, -- [3]
					{
						["NXX"] = 47.56401777267456,
						["NXY"] = 52.05346345901489,
						["NXName"] = "Entered",
						["NXTime"] = 1244039264.000086,
						["T"] = "I",
						["NXMapId"] = 3002,
					}, -- [4]
					{
						["NXX"] = 47.57769703865051,
						["NXY"] = 52.08801031112671,
						["NXName"] = "Entered",
						["NXTime"] = 1244039449.000087,
						["T"] = "I",
						["NXMapId"] = 13052,
					}, -- [5]
					{
						["NXX"] = 47.57769703865051,
						["NXY"] = 52.08801031112671,
						["NXName"] = "Entered",
						["NXTime"] = 1244041225.000093,
						["T"] = "I",
						["NXMapId"] = 3006,
					}, -- [6]
					{
						["NXX"] = 52.31810808181763,
						["NXY"] = 52.43063569068909,
						["NXName"] = "Entered",
						["NXTime"] = 1244041529.000094,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [7]
					{
						["NXX"] = 51.09888911247253,
						["NXY"] = 70.01062035560608,
						["NXName"] = "Entered",
						["NXTime"] = 1244041943.000095,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [8]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1244045053.000001,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [9]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1244070843.000001,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [10]
					{
						["NXX"] = 78.34157347679138,
						["NXY"] = 54.3864905834198,
						["NXName"] = "Entered",
						["NXTime"] = 1244071048.000002,
						["T"] = "I",
						["NXMapId"] = 3006,
					}, -- [11]
					{
						["NXX"] = 78.96628379821777,
						["NXY"] = 8.994897454977036,
						["NXName"] = "Entered",
						["NXTime"] = 1244071079.000003,
						["T"] = "I",
						["NXMapId"] = 3007,
					}, -- [12]
					{
						["NXX"] = 34.9696546792984,
						["NXY"] = 17.83740371465683,
						["NXName"] = "Entered",
						["NXTime"] = 1244071095.000004,
						["T"] = "I",
						["NXMapId"] = 3006,
					}, -- [13]
					{
						["NXX"] = 52.0870566368103,
						["NXY"] = 52.94227004051209,
						["NXName"] = "Entered",
						["NXTime"] = 1244071114.000005,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [14]
					{
						["NXX"] = 51.60102248191834,
						["NXY"] = 68.38167309761047,
						["NXName"] = "Entered",
						["NXTime"] = 1244072135.000006,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [15]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1244075628.000001,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [16]
					{
						["NXX"] = 78.29482555389404,
						["NXY"] = 54.29766774177551,
						["NXName"] = "Entered",
						["NXTime"] = 1244075708.000002,
						["T"] = "I",
						["NXMapId"] = 3006,
					}, -- [17]
					{
						["NXX"] = 52.06085443496704,
						["NXY"] = 53.10380458831787,
						["NXName"] = "Entered",
						["NXTime"] = 1244075736.000003,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [18]
					{
						["NXX"] = 55.58099746704102,
						["NXY"] = 64.62957262992859,
						["NXName"] = "Entered",
						["NXTime"] = 1244076454.000004,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [19]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1244078953.000001,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [20]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1244090147.000001,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [21]
					{
						["NXX"] = 78.32273244857788,
						["NXY"] = 54.3211042881012,
						["NXName"] = "Entered",
						["NXTime"] = 1244090321.000002,
						["T"] = "I",
						["NXMapId"] = 3006,
					}, -- [22]
					{
						["NXX"] = 52.03326940536499,
						["NXY"] = 52.87830829620361,
						["NXName"] = "Entered",
						["NXTime"] = 1244090413.000003,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [23]
					{
						["NXX"] = 55.57549595832825,
						["NXY"] = 64.6568775177002,
						["NXName"] = "Entered",
						["NXTime"] = 1244091723.000004,
						["T"] = "I",
						["NXMapId"] = 3008,
					}, -- [24]
					{
						["NXX"] = 50.27192234992981,
						["NXY"] = 33.39802324771881,
						["NXName"] = "Entered",
						["NXTime"] = 1244091777.000005,
						["T"] = "I",
						["NXMapId"] = 13029,
					}, -- [25]
					{
						["NXX"] = 50.27192234992981,
						["NXY"] = 33.39802324771881,
						["NXName"] = "Entered",
						["NXTime"] = 1244092234.000009,
						["T"] = "I",
						["NXMapId"] = 3008,
					}, -- [26]
					{
						["NXX"] = 50.25547742843628,
						["NXY"] = 33.4285706281662,
						["NXName"] = "Entered",
						["NXTime"] = 1244092328.00001,
						["T"] = "I",
						["NXMapId"] = 13029,
					}, -- [27]
					{
						["NXX"] = 50.25547742843628,
						["NXY"] = 33.4285706281662,
						["NXName"] = "Entered",
						["NXTime"] = 1244092669.000014,
						["T"] = "I",
						["NXMapId"] = 3008,
					}, -- [28]
					{
						["NXX"] = 50.25045275688171,
						["NXY"] = 33.23042392730713,
						["NXName"] = "Entered",
						["NXTime"] = 1244092756.000015,
						["T"] = "I",
						["NXMapId"] = 13029,
					}, -- [29]
					{
						["NXX"] = 50.25045275688171,
						["NXY"] = 33.23042392730713,
						["NXName"] = "Entered",
						["NXTime"] = 1244094102.000026,
						["T"] = "I",
						["NXMapId"] = 3006,
					}, -- [30]
					{
						["NXX"] = 52.23358869552612,
						["NXY"] = 52.69377827644348,
						["NXName"] = "Entered",
						["NXTime"] = 1244094154.000027,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [31]
					{
						["NXX"] = 53.99772524833679,
						["NXY"] = 64.27634358406067,
						["NXName"] = "Entered",
						["NXTime"] = 1244094267.000028,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [32]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1244108129.000001,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [33]
					{
						["NXX"] = 78.38026881217957,
						["NXY"] = 54.42929863929749,
						["NXName"] = "Entered",
						["NXTime"] = 1244108227.000002,
						["T"] = "I",
						["NXMapId"] = 3006,
					}, -- [34]
					{
						["NXX"] = 52.06702351570129,
						["NXY"] = 53.26763391494751,
						["NXName"] = "Entered",
						["NXTime"] = 1244108259.000003,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [35]
					{
						["NXX"] = 55.56526184082031,
						["NXY"] = 64.70654010772705,
						["NXName"] = "Entered",
						["NXTime"] = 1244108431.000004,
						["T"] = "I",
						["NXMapId"] = 13013,
					}, -- [36]
					{
						["NXX"] = 55.56526184082031,
						["NXY"] = 64.70654010772705,
						["NXName"] = "Entered",
						["NXTime"] = 1244114405.000008,
						["T"] = "I",
						["NXMapId"] = 3005,
					}, -- [37]
					{
						["NXX"] = 71.05003595352173,
						["NXY"] = 46.70014977455139,
						["NXName"] = "Entered",
						["NXTime"] = 1244114444.000009,
						["T"] = "I",
						["NXMapId"] = 13013,
					}, -- [38]
					{
						["NXX"] = 71.05003595352173,
						["NXY"] = 46.70014977455139,
						["NXName"] = "Entered",
						["NXTime"] = 1244115340.000011,
						["T"] = "I",
						["NXMapId"] = 3005,
					}, -- [39]
					{
						["NXX"] = 71.03421092033386,
						["NXY"] = 46.72152996063232,
						["NXName"] = "Entered",
						["NXTime"] = 1244115375.000012,
						["T"] = "I",
						["NXMapId"] = 13013,
					}, -- [40]
					{
						["NXX"] = 71.03421092033386,
						["NXY"] = 46.72152996063232,
						["NXName"] = "Entered",
						["NXTime"] = 1244115394.000013,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [41]
					{
						["NXX"] = 78.36114168167114,
						["NXY"] = 54.35303449630737,
						["NXName"] = "Entered",
						["NXTime"] = 1244115618.000014,
						["T"] = "I",
						["NXMapId"] = 3006,
					}, -- [42]
					{
						["NXX"] = 52.16349959373474,
						["NXY"] = 52.63871550559998,
						["NXName"] = "Entered",
						["NXTime"] = 1244115645.000015,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [43]
					{
						["NXX"] = 27.00862586498261,
						["NXY"] = 52.78192758560181,
						["NXName"] = "Entered",
						["NXTime"] = 1244126300.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [44]
					{
						["NXX"] = 49.02608692646027,
						["NXY"] = 95.41520476341248,
						["NXName"] = "Entered",
						["NXTime"] = 1244127000.000002,
						["T"] = "I",
						["NXMapId"] = 1008,
					}, -- [45]
					{
						["NXX"] = 45.44684290885925,
						["NXY"] = 12.0285838842392,
						["NXName"] = "Entered",
						["NXTime"] = 1244127049.000003,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [46]
					{
						["NXX"] = 48.93167614936829,
						["NXY"] = 95.2681303024292,
						["NXName"] = "Entered",
						["NXTime"] = 1244127052.000004,
						["T"] = "I",
						["NXMapId"] = 1008,
					}, -- [47]
					{
						["NXX"] = 45.56728899478912,
						["NXY"] = 12.02441453933716,
						["NXName"] = "Entered",
						["NXTime"] = 1244127155.000005,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [48]
					{
						["NXX"] = 48.88850748538971,
						["NXY"] = 95.37386298179627,
						["NXName"] = "Entered",
						["NXTime"] = 1244127232.000006,
						["T"] = "I",
						["NXMapId"] = 1008,
					}, -- [49]
					{
						["NXX"] = 45.62874436378479,
						["NXY"] = 12.02579960227013,
						["NXName"] = "Entered",
						["NXTime"] = 1244127509.000007,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [50]
					{
						["NXX"] = 52.66802906990051,
						["NXY"] = 65.52231311798096,
						["NXName"] = "Entered",
						["NXTime"] = 1244127631.000008,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [51]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1244156824.000001,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [52]
					{
						["NXX"] = 78.26932668685913,
						["NXY"] = 54.44297790527344,
						["NXName"] = "Entered",
						["NXTime"] = 1244156948.000002,
						["T"] = "I",
						["NXMapId"] = 3006,
					}, -- [53]
					{
						["NXX"] = 52.16208100318909,
						["NXY"] = 52.79379487037659,
						["NXName"] = "Entered",
						["NXTime"] = 1244157144.000003,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [54]
					{
						["NXX"] = 51.02438926696777,
						["NXY"] = 70.11940479278565,
						["NXName"] = "Entered",
						["NXTime"] = 1244157896.000004,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [55]
					{
						["NXX"] = 78.32066416740418,
						["NXY"] = 54.40984964370728,
						["NXName"] = "Entered",
						["NXTime"] = 1244159080.000061,
						["T"] = "I",
						["NXMapId"] = 3006,
					}, -- [56]
					{
						["NXX"] = 55.34288883209229,
						["NXY"] = 0.02531586214900017,
						["NXName"] = "Entered",
						["NXTime"] = 1244159156.000062,
						["T"] = "I",
						["NXMapId"] = 3007,
					}, -- [57]
					{
						["NXX"] = 29.31742072105408,
						["NXY"] = 13.71217668056488,
						["NXName"] = "Entered",
						["NXTime"] = 1244159344.000074,
						["T"] = "I",
						["NXMapId"] = 3006,
					}, -- [58]
					{
						["NXX"] = 74.43398833274841,
						["NXY"] = 8.643685281276703,
						["NXName"] = "Entered",
						["NXTime"] = 1244159355.000075,
						["T"] = "I",
						["NXMapId"] = 3007,
					}, -- [59]
					{
						["NXX"] = 34.97333526611328,
						["NXY"] = 17.99402385950089,
						["NXName"] = "Entered",
						["NXTime"] = 1244159375.000076,
						["T"] = "I",
						["NXMapId"] = 3006,
					}, -- [60]
					{
						["NXX"] = 66.28012657165527,
						["NXY"] = 68.67432594299316,
						["NXName"] = "Entered",
						["NXTime"] = 1244159436.000077,
						["T"] = "I",
						["NXMapId"] = 3005,
					}, -- [61]
					{
						["NXX"] = 17.99176633358002,
						["NXY"] = 23.66755902767181,
						["NXName"] = "Entered",
						["NXTime"] = 1244160121.000094,
						["T"] = "I",
						["NXMapId"] = 3007,
					}, -- [62]
					{
						["NXX"] = 37.9317969083786,
						["NXY"] = 27.38383710384369,
						["NXName"] = "Entered",
						["NXTime"] = 1244160219.000095,
						["T"] = "I",
						["NXMapId"] = 3006,
					}, -- [63]
					{
						["NXX"] = 83.94757567775307,
						["NXY"] = 60.66001622410828,
						["NXName"] = "Entered",
						["NXTime"] = 1244160219.000096,
						["T"] = "I",
						["NXMapId"] = 3007,
					}, -- [64]
					{
						["NXX"] = 34.84756648540497,
						["NXY"] = 31.40940368175507,
						["NXName"] = "Entered",
						["NXTime"] = 1244160246.000097,
						["T"] = "I",
						["NXMapId"] = 3006,
					}, -- [65]
					{
						["NXX"] = 51.95398330688477,
						["NXY"] = 52.99239754676819,
						["NXName"] = "Entered",
						["NXTime"] = 1244160269.000098,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [66]
					{
						["NXX"] = 50.95984935760498,
						["NXY"] = 70.14285326004028,
						["NXName"] = "Entered",
						["NXTime"] = 1244161633.000099,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [67]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1244167617.000001,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [68]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1244171243.000001,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [69]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1244174831.000001,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [70]
					{
						["NXX"] = 78.51158380508423,
						["NXY"] = 52.84281373023987,
						["NXName"] = "Entered",
						["NXTime"] = 1244174932.000002,
						["T"] = "I",
						["NXMapId"] = 3006,
					}, -- [71]
					{
						["NXX"] = 17.86954253911972,
						["NXY"] = 48.87209236621857,
						["NXName"] = "Entered",
						["NXTime"] = 1244174934.000003,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [72]
					{
						["NXX"] = 79.69288229942322,
						["NXY"] = 52.67860293388367,
						["NXName"] = "Entered",
						["NXTime"] = 1244174934.000004,
						["T"] = "I",
						["NXMapId"] = 3006,
					}, -- [73]
					{
						["NXX"] = 52.39103436470032,
						["NXY"] = 52.68239378929138,
						["NXName"] = "Entered",
						["NXTime"] = 1244174965.000005,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [74]
					{
						["NXX"] = 50.96364617347717,
						["NXY"] = 69.66274976730347,
						["NXName"] = "Entered",
						["NXTime"] = 1244175181.000006,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [75]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1244182397.000001,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [76]
					{
						["NXX"] = 79.80988621711731,
						["NXY"] = 56.47614598274231,
						["NXName"] = "Entered",
						["NXTime"] = 1244182543.000002,
						["T"] = "I",
						["NXMapId"] = 3006,
					}, -- [77]
					{
						["NXX"] = 52.16749906539917,
						["NXY"] = 52.4017333984375,
						["NXName"] = "Entered",
						["NXTime"] = 1244182625.000003,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [78]
					{
						["NXX"] = 27.11171209812164,
						["NXY"] = 52.68844962120056,
						["NXName"] = "Entered",
						["NXTime"] = 1244182971.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [79]
					{
						["NXX"] = 53.96106839179993,
						["NXY"] = 64.46079015731812,
						["NXName"] = "Entered",
						["NXTime"] = 1244183315.000002,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [80]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1244207343.000001,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [81]
					{
						["NXX"] = 78.37722897529602,
						["NXY"] = 54.34929132461548,
						["NXName"] = "Entered",
						["NXTime"] = 1244207560.000002,
						["T"] = "I",
						["NXMapId"] = 3006,
					}, -- [82]
					{
						["NXX"] = 52.40923762321472,
						["NXY"] = 52.74244546890259,
						["NXName"] = "Entered",
						["NXTime"] = 1244207587.000003,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [83]
					{
						["NXX"] = 26.98034346103668,
						["NXY"] = 52.84597277641296,
						["NXName"] = "Entered",
						["NXTime"] = 1244207853.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [84]
					{
						["NXX"] = 51.08757615089417,
						["NXY"] = 70.34326195716858,
						["NXName"] = "Entered",
						["NXTime"] = 1244207871.000002,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [85]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1244244018.000001,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [86]
					{
						["NXX"] = 78.36174368858337,
						["NXY"] = 54.42461967468262,
						["NXName"] = "Entered",
						["NXTime"] = 1244244181.000002,
						["T"] = "I",
						["NXMapId"] = 3006,
					}, -- [87]
					{
						["NXX"] = 81.05345368385315,
						["NXY"] = 18.22222024202347,
						["NXName"] = "Entered",
						["NXTime"] = 1244244219.000003,
						["T"] = "I",
						["NXMapId"] = 3007,
					}, -- [88]
					{
						["NXX"] = 36.70640885829926,
						["NXY"] = 17.54767298698425,
						["NXName"] = "Entered",
						["NXTime"] = 1244244233.000004,
						["T"] = "I",
						["NXMapId"] = 3006,
					}, -- [89]
					{
						["NXX"] = 52.23310589790344,
						["NXY"] = 52.80831456184387,
						["NXName"] = "Entered",
						["NXTime"] = 1244244255.000005,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [90]
					{
						["NXX"] = 52.82799005508423,
						["NXY"] = 65.80865383148193,
						["NXName"] = "Entered",
						["NXTime"] = 1244244638.000006,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [91]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1244250970.000001,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [92]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1244256083.000001,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [93]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1244257235.000001,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [94]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1244257664.000001,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [95]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1244290997.000001,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [96]
					{
						["NXX"] = 78.31763625144959,
						["NXY"] = 54.34949994087219,
						["NXName"] = "Entered",
						["NXTime"] = 1244291127.000002,
						["T"] = "I",
						["NXMapId"] = 3006,
					}, -- [97]
					{
						["NXX"] = 52.15467810630798,
						["NXY"] = 52.88779735565186,
						["NXName"] = "Entered",
						["NXTime"] = 1244291159.000003,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [98]
					{
						["NXX"] = 51.98692083358765,
						["NXY"] = 66.88175201416016,
						["NXName"] = "Entered",
						["NXTime"] = 1244291991.000004,
						["T"] = "I",
						["NXMapId"] = 3005,
					}, -- [99]
					{
						["NXX"] = 58.24046730995178,
						["NXY"] = 70.78897356987,
						["NXName"] = "Entered",
						["NXTime"] = 1244292082.000005,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [100]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1244302286.000001,
						["T"] = "I",
						["NXMapId"] = 3003,
					}, -- [101]
					{
						["NXX"] = 78.44775915145874,
						["NXY"] = 54.39484715461731,
						["NXName"] = "Entered",
						["NXTime"] = 1244302423.000002,
						["T"] = "I",
						["NXMapId"] = 3006,
					}, -- [102]
					{
						["NXX"] = 51.92344784736633,
						["NXY"] = 52.36380100250244,
						["NXName"] = "Entered",
						["NXTime"] = 1244302455.000003,
						["T"] = "I",
						["NXMapId"] = 2025,
					}, -- [103]
					{
						["NXX"] = 66.11611247062683,
						["NXY"] = 0.02635527052916586,
						["NXName"] = "Entered",
						["NXTime"] = 1244302552.000004,
						["T"] = "I",
						["NXMapId"] = 2024,
					}, -- [104]
					{
						["NXX"] = 61.86322569847107,
						["NXY"] = 65.09290933609009,
						["NXName"] = "Entered",
						["NXTime"] = 1244302575.000005,
						["T"] = "I",
						["NXMapId"] = 2025,
					}, -- [105]
				},
				["Death"] = {
					{
						["NXX"] = 71.0423469543457,
						["NXY"] = 46.73941433429718,
						["NXName"] = "Gathios the Shatterer",
						["NXTime"] = 1243245821.000163,
						["T"] = "D",
						["NXMapId"] = 13013,
					}, -- [1]
					{
						["NXX"] = 71.0423469543457,
						["NXY"] = 46.73941433429718,
						["NXName"] = "High Nethermancer Zerevor",
						["NXTime"] = 1243246767.000164,
						["T"] = "D",
						["NXMapId"] = 13013,
					}, -- [2]
					{
						["NXX"] = 71.0423469543457,
						["NXY"] = 46.73941433429718,
						["NXName"] = "Flame of Azzinoth",
						["NXTime"] = 1243250122.000165,
						["T"] = "D",
						["NXMapId"] = 13013,
					}, -- [3]
					{
						["NXX"] = 71.01191282272339,
						["NXY"] = 46.7083066701889,
						["NXName"] = "Flame of Azzinoth",
						["NXTime"] = 1243250787.000168,
						["T"] = "D",
						["NXMapId"] = 13013,
					}, -- [4]
					{
						["NXX"] = 70.99120020866394,
						["NXY"] = 46.71824872493744,
						["NXName"] = "Illidan Stormrage",
						["NXTime"] = 1243252137.000171,
						["T"] = "D",
						["NXMapId"] = 13013,
					}, -- [5]
					{
						["NXX"] = 71.00983262062073,
						["NXY"] = 46.70031070709229,
						["NXName"] = "Flame of Azzinoth",
						["NXTime"] = 1243252742.000174,
						["T"] = "D",
						["NXMapId"] = 13013,
					}, -- [6]
					{
						["NXX"] = 71.01871371269226,
						["NXY"] = 46.70388102531433,
						["NXName"] = "Illidan Stormrage",
						["NXTime"] = 1243254809.000177,
						["T"] = "D",
						["NXMapId"] = 13013,
					}, -- [7]
					{
						["NXX"] = 70.99021673202515,
						["NXY"] = 46.71021103858948,
						["NXName"] = "Illidan Stormrage",
						["NXTime"] = 1243255198.00018,
						["T"] = "D",
						["NXMapId"] = 13013,
					}, -- [8]
					{
						["NXX"] = 69.36229467391968,
						["NXY"] = 23.55495244264603,
						["NXName"] = "Lair Brute",
						["NXTime"] = 1243317710.000009,
						["T"] = "D",
						["NXMapId"] = 13049,
					}, -- [9]
					{
						["NXX"] = 26.60702764987946,
						["NXY"] = 76.39230489730835,
						["NXName"] = "Booty Bay Bruiser",
						["NXTime"] = 1243319510.000017,
						["T"] = "D",
						["NXMapId"] = 2021,
					}, -- [10]
					{
						["NXX"] = 46.74514532089233,
						["NXY"] = 74.50006604194641,
						["NXName"] = "Arcane Watchman",
						["NXTime"] = 1243327212.000055,
						["T"] = "D",
						["NXMapId"] = 12058,
					}, -- [11]
					{
						["NXX"] = 46.74514532089233,
						["NXY"] = 74.50006604194641,
						["NXName"] = "Greater Fleshbeast",
						["NXTime"] = 1243329699.000069,
						["T"] = "D",
						["NXMapId"] = 12058,
					}, -- [12]
					{
						["NXX"] = 55.56303262710571,
						["NXY"] = 64.71691727638245,
						["NXName"] = "Coilfang Strider",
						["NXTime"] = 1243398454.000022,
						["T"] = "D",
						["NXMapId"] = 13027,
					}, -- [13]
					{
						["NXX"] = 51.95415616035461,
						["NXY"] = 32.6890766620636,
						["NXName"] = "Lady Vashj",
						["NXTime"] = 1243399714.000053,
						["T"] = "D",
						["NXMapId"] = 13027,
					}, -- [14]
					{
						["NXX"] = 50.04068613052368,
						["NXY"] = 73.22648763656616,
						["NXName"] = "无懈苛击-夏维安",
						["NXTime"] = 1243474064.00001,
						["T"] = "D",
						["NXMapId"] = 9004,
					}, -- [15]
					{
						["NXX"] = 52.40943431854248,
						["NXY"] = 57.95149207115173,
						["NXName"] = "哆唆-梅尔加尼",
						["NXTime"] = 1243649820.000018,
						["T"] = "D",
						["NXMapId"] = 9004,
					}, -- [16]
					{
						["NXX"] = 40.82323014736176,
						["NXY"] = 41.80742204189301,
						["NXName"] = "猪泡泡-闪电之刃",
						["NXTime"] = 1243650053.000026,
						["T"] = "D",
						["NXMapId"] = 9004,
					}, -- [17]
					{
						["NXX"] = 46.02775871753693,
						["NXY"] = 57.12782740592957,
						["NXName"] = "幽灵一号-主宰之剑",
						["NXTime"] = 1243650443.000076,
						["T"] = "D",
						["NXMapId"] = 9004,
					}, -- [18]
					{
						["NXX"] = 39.67130780220032,
						["NXY"] = 57.60129690170288,
						["NXName"] = "Ethereal Spellbinder",
						["NXTime"] = 1243694341.000059,
						["T"] = "D",
						["NXMapId"] = 13007,
					}, -- [19]
					{
						["NXX"] = 39.67130780220032,
						["NXY"] = 57.60129690170288,
						["NXName"] = "Ethereal Spellbinder",
						["NXTime"] = 1243694891.000066,
						["T"] = "D",
						["NXMapId"] = 13007,
					}, -- [20]
					{
						["NXX"] = 2021.138721951246,
						["NXY"] = 1191.736172530651,
						["NXName"] = "Blackhand Iron Guard",
						["NXTime"] = 1243778008.00001,
						["T"] = "D",
						["NXMapId"] = 12017,
					}, -- [21]
					{
						["NXX"] = 51.02057456970215,
						["NXY"] = 42.49752759933472,
						["NXName"] = "卖水-轻风之语",
						["NXTime"] = 1243822185.000005,
						["T"] = "D",
						["NXMapId"] = 9003,
					}, -- [22]
					{
						["NXX"] = 46.72618806362152,
						["NXY"] = 47.10816442966461,
						["NXName"] = "Water Elemental",
						["NXTime"] = 1243822409.000011,
						["T"] = "D",
						["NXMapId"] = 9001,
					}, -- [23]
					{
						["NXX"] = 40.77337682247162,
						["NXY"] = 55.95093965530396,
						["NXName"] = "无敌大圣-玛法里奥",
						["NXTime"] = 1243822700.00002,
						["T"] = "D",
						["NXMapId"] = 9001,
					}, -- [24]
					{
						["NXX"] = 61.30906939506531,
						["NXY"] = 31.02642297744751,
						["NXName"] = "Sunblade Magister",
						["NXTime"] = 1243824699.00006,
						["T"] = "D",
						["NXMapId"] = 12120,
					}, -- [25]
					{
						["NXX"] = 50.89383125305176,
						["NXY"] = 86.94649338722229,
						["NXName"] = "不你死就我活-拉文凯斯",
						["NXTime"] = 1243853326.000008,
						["T"] = "D",
						["NXMapId"] = 9002,
					}, -- [26]
					{
						["NXX"] = 57.15592503547669,
						["NXY"] = 77.30537056922913,
						["NXName"] = "若叶飘零-耐普图隆",
						["NXTime"] = 1243853361.000009,
						["T"] = "D",
						["NXMapId"] = 9002,
					}, -- [27]
					{
						["NXX"] = 57.42505192756653,
						["NXY"] = 75.31717419624329,
						["NXName"] = "Wanglm-耐普图隆",
						["NXTime"] = 1243853391.00001,
						["T"] = "D",
						["NXMapId"] = 9002,
					}, -- [28]
					{
						["NXX"] = 45.00845968723297,
						["NXY"] = 68.94698143005371,
						["NXName"] = "若叶飘零-耐普图隆",
						["NXTime"] = 1243853474.000011,
						["T"] = "D",
						["NXMapId"] = 9002,
					}, -- [29]
					{
						["NXX"] = 73.83438348770142,
						["NXY"] = 63.72230648994446,
						["NXName"] = "Kael'thas Sunstrider",
						["NXTime"] = 1243935464.000009,
						["T"] = "D",
						["NXMapId"] = 9000,
					}, -- [30]
					{
						["NXX"] = 73.83438348770142,
						["NXY"] = 63.72230648994446,
						["NXName"] = "Ember of Al'ar",
						["NXTime"] = 1243936956.000013,
						["T"] = "D",
						["NXMapId"] = 9000,
					}, -- [31]
					{
						["NXX"] = 42.83302128314972,
						["NXY"] = 42.61911511421204,
						["NXName"] = "Lucifron",
						["NXTime"] = 1243951081.000247,
						["T"] = "D",
						["NXMapId"] = 12061,
					}, -- [32]
					{
						["NXX"] = 42.83302128314972,
						["NXY"] = 42.61911511421204,
						["NXName"] = "Firelord",
						["NXTime"] = 1243951896.000248,
						["T"] = "D",
						["NXMapId"] = 12061,
					}, -- [33]
					{
						["NXX"] = 42.83302128314972,
						["NXY"] = 42.61911511421204,
						["NXName"] = "Baron Geddon",
						["NXTime"] = 1243952390.000249,
						["T"] = "D",
						["NXMapId"] = 12061,
					}, -- [34]
					{
						["NXX"] = 42.83302128314972,
						["NXY"] = 42.61911511421204,
						["NXName"] = "Ancient Core Hound",
						["NXTime"] = 1243953328.00025,
						["T"] = "D",
						["NXMapId"] = 12061,
					}, -- [35]
					{
						["NXX"] = 44.24953460693359,
						["NXY"] = 45.8107590675354,
						["NXName"] = "公元前的追忆",
						["NXTime"] = 1244013023.000111,
						["T"] = "D",
						["NXMapId"] = 12121,
					}, -- [36]
					{
						["NXX"] = 44.26381587982178,
						["NXY"] = 45.82290649414063,
						["NXName"] = "Kalecgos",
						["NXTime"] = 1244014006.000116,
						["T"] = "D",
						["NXMapId"] = 12121,
					}, -- [37]
					{
						["NXX"] = 44.26381587982178,
						["NXY"] = 45.82290649414063,
						["NXName"] = "雷克萨苍狼",
						["NXTime"] = 1244015551.000117,
						["T"] = "D",
						["NXMapId"] = 12121,
					}, -- [38]
					{
						["NXX"] = 44.20230686664581,
						["NXY"] = 45.77392041683197,
						["NXName"] = "Sunblade Vindicator",
						["NXTime"] = 1244032500.00003,
						["T"] = "D",
						["NXMapId"] = 12121,
					}, -- [39]
					{
						["NXX"] = 82.37344622612,
						["NXY"] = 64.35357332229614,
						["NXName"] = "Amani'shi Tempest",
						["NXTime"] = 1244034295.000042,
						["T"] = "D",
						["NXMapId"] = 12118,
					}, -- [40]
					{
						["NXX"] = 82.38204121589661,
						["NXY"] = 64.55255150794983,
						["NXName"] = "Jan'alai",
						["NXTime"] = 1244035408.000051,
						["T"] = "D",
						["NXMapId"] = 12118,
					}, -- [41]
					{
						["NXX"] = 82.38204121589661,
						["NXY"] = 64.55255150794983,
						["NXName"] = "Amani'shi Handler",
						["NXTime"] = 1244035678.000058,
						["T"] = "D",
						["NXMapId"] = 12118,
					}, -- [42]
					{
						["NXX"] = 82.42205381393433,
						["NXY"] = 64.54684734344482,
						["NXName"] = "Amani'shi Beast Tamer",
						["NXTime"] = 1244036041.000061,
						["T"] = "D",
						["NXMapId"] = 12118,
					}, -- [43]
					{
						["NXX"] = 50.27192234992981,
						["NXY"] = 33.39802324771881,
						["NXName"] = "Coilfang Engineer",
						["NXTime"] = 1244092035.000007,
						["T"] = "D",
						["NXMapId"] = 13029,
					}, -- [44]
					{
						["NXX"] = 50.27192234992981,
						["NXY"] = 33.39802324771881,
						["NXName"] = "Steam Surger",
						["NXTime"] = 1244092221.000008,
						["T"] = "D",
						["NXMapId"] = 13029,
					}, -- [45]
					{
						["NXX"] = 50.25547742843628,
						["NXY"] = 33.4285706281662,
						["NXName"] = "Coilfang Siren",
						["NXTime"] = 1244092663.000013,
						["T"] = "D",
						["NXMapId"] = 13029,
					}, -- [46]
					{
						["NXX"] = 55.56526184082031,
						["NXY"] = 64.70654010772705,
						["NXName"] = "Lady Malande",
						["NXTime"] = 1244110144.000005,
						["T"] = "D",
						["NXMapId"] = 13013,
					}, -- [47]
					{
						["NXX"] = 55.56526184082031,
						["NXY"] = 64.70654010772705,
						["NXName"] = "Gathios the Shatterer",
						["NXTime"] = 1244111171.000006,
						["T"] = "D",
						["NXMapId"] = 13013,
					}, -- [48]
					{
						["NXX"] = 55.56526184082031,
						["NXY"] = 64.70654010772705,
						["NXName"] = "Flame of Azzinoth",
						["NXTime"] = 1244114396.000007,
						["T"] = "D",
						["NXMapId"] = 13013,
					}, -- [49]
					{
						["NXX"] = 71.05003595352173,
						["NXY"] = 46.70014977455139,
						["NXName"] = "Flame of Azzinoth",
						["NXTime"] = 1244115332.00001,
						["T"] = "D",
						["NXMapId"] = 13013,
					}, -- [50]
				},
				["Kill"] = {
					{
						["NXX"] = 37.1229499578476,
						["NXY"] = 77.01703906059265,
						["NXKills"] = 32,
						["NXName"] = "Voidspawn",
						["NXTime"] = 1244158485.000038,
						["T"] = "K",
						["NXMapId"] = 3003,
					}, -- [1]
					{
						["NXX"] = 37.73154616355896,
						["NXY"] = 76.78877711296082,
						["NXKills"] = 33,
						["NXName"] = "Voidspawn",
						["NXTime"] = 1244158498.000039,
						["T"] = "K",
						["NXMapId"] = 3003,
					}, -- [2]
					{
						["NXX"] = 38.42833638191223,
						["NXY"] = 75.41570663452148,
						["NXKills"] = 34,
						["NXName"] = "Voidspawn",
						["NXTime"] = 1244158514.00004,
						["T"] = "K",
						["NXMapId"] = 3003,
					}, -- [3]
					{
						["NXX"] = 38.48026692867279,
						["NXY"] = 75.42926073074341,
						["NXKills"] = 35,
						["NXName"] = "Voidspawn",
						["NXTime"] = 1244158523.000041,
						["T"] = "K",
						["NXMapId"] = 3003,
					}, -- [4]
					{
						["NXX"] = 39.03026878833771,
						["NXY"] = 74.64269399642944,
						["NXKills"] = 36,
						["NXName"] = "Voidspawn",
						["NXTime"] = 1244158537.000042,
						["T"] = "K",
						["NXMapId"] = 3003,
					}, -- [5]
					{
						["NXX"] = 39.68035876750946,
						["NXY"] = 72.9386568069458,
						["NXKills"] = 37,
						["NXName"] = "Voidspawn",
						["NXTime"] = 1244158570.000043,
						["T"] = "K",
						["NXMapId"] = 3003,
					}, -- [6]
					{
						["NXX"] = 40.65880477428436,
						["NXY"] = 73.81111979484558,
						["NXKills"] = 38,
						["NXName"] = "Voidspawn",
						["NXTime"] = 1244158588.000044,
						["T"] = "K",
						["NXMapId"] = 3003,
					}, -- [7]
					{
						["NXX"] = 41.05752408504486,
						["NXY"] = 75.81653594970703,
						["NXKills"] = 39,
						["NXName"] = "Voidspawn",
						["NXTime"] = 1244158606.000045,
						["T"] = "K",
						["NXMapId"] = 3003,
					}, -- [8]
					{
						["NXX"] = 40.50115644931793,
						["NXY"] = 76.94444060325623,
						["NXKills"] = 40,
						["NXName"] = "Voidspawn",
						["NXTime"] = 1244158623.000046,
						["T"] = "K",
						["NXMapId"] = 3003,
					}, -- [9]
					{
						["NXX"] = 39.65162932872772,
						["NXY"] = 78.25903296470642,
						["NXKills"] = 41,
						["NXName"] = "Voidspawn",
						["NXTime"] = 1244158641.000047,
						["T"] = "K",
						["NXMapId"] = 3003,
					}, -- [10]
					{
						["NXX"] = 38.87370228767395,
						["NXY"] = 79.00504469871521,
						["NXKills"] = 42,
						["NXName"] = "Voidspawn",
						["NXTime"] = 1244158656.000048,
						["T"] = "K",
						["NXMapId"] = 3003,
					}, -- [11]
					{
						["NXX"] = 38.29427659511566,
						["NXY"] = 79.34791445732117,
						["NXKills"] = 43,
						["NXName"] = "Voidspawn",
						["NXTime"] = 1244158669.000049,
						["T"] = "K",
						["NXMapId"] = 3003,
					}, -- [12]
					{
						["NXX"] = 37.74183392524719,
						["NXY"] = 79.40192818641663,
						["NXKills"] = 44,
						["NXName"] = "Voidspawn",
						["NXTime"] = 1244158681.00005,
						["T"] = "K",
						["NXMapId"] = 3003,
					}, -- [13]
					{
						["NXX"] = 32.2519987821579,
						["NXY"] = 74.0176260471344,
						["NXKills"] = 45,
						["NXName"] = "Voidspawn",
						["NXTime"] = 1244158712.000051,
						["T"] = "K",
						["NXMapId"] = 3003,
					}, -- [14]
					{
						["NXX"] = 31.4728856086731,
						["NXY"] = 73.88798594474793,
						["NXKills"] = 46,
						["NXName"] = "Voidspawn",
						["NXTime"] = 1244158726.000052,
						["T"] = "K",
						["NXMapId"] = 3003,
					}, -- [15]
					{
						["NXX"] = 31.94895386695862,
						["NXY"] = 71.29666805267334,
						["NXKills"] = 47,
						["NXName"] = "Voidspawn",
						["NXTime"] = 1244158745.000053,
						["T"] = "K",
						["NXMapId"] = 3003,
					}, -- [16]
					{
						["NXX"] = 32.06706047058106,
						["NXY"] = 68.96820664405823,
						["NXKills"] = 48,
						["NXName"] = "Voidspawn",
						["NXTime"] = 1244158765.000054,
						["T"] = "K",
						["NXMapId"] = 3003,
					}, -- [17]
					{
						["NXX"] = 31.93651139736176,
						["NXY"] = 68.99586319923401,
						["NXKills"] = 49,
						["NXName"] = "Voidspawn",
						["NXTime"] = 1244158769.000055,
						["T"] = "K",
						["NXMapId"] = 3003,
					}, -- [18]
					{
						["NXX"] = 31.77442848682404,
						["NXY"] = 69.20230984687805,
						["NXKills"] = 50,
						["NXName"] = "Voidspawn",
						["NXTime"] = 1244158774.000056,
						["T"] = "K",
						["NXMapId"] = 3003,
					}, -- [19]
					{
						["NXX"] = 32.01097548007965,
						["NXY"] = 69.18071508407593,
						["NXKills"] = 51,
						["NXName"] = "Voidspawn",
						["NXTime"] = 1244158777.000057,
						["T"] = "K",
						["NXMapId"] = 3003,
					}, -- [20]
					{
						["NXX"] = 32.12243616580963,
						["NXY"] = 69.02012228965759,
						["NXKills"] = 52,
						["NXName"] = "Voidspawn",
						["NXTime"] = 1244158782.000058,
						["T"] = "K",
						["NXMapId"] = 3003,
					}, -- [21]
					{
						["NXX"] = 48.91292154788971,
						["NXY"] = 39.99840021133423,
						["NXKills"] = 1,
						["NXName"] = "Clefthoof Bull",
						["NXTime"] = 1244158936.000059,
						["T"] = "K",
						["NXMapId"] = 3003,
					}, -- [22]
					{
						["NXX"] = 48.91665279865265,
						["NXY"] = 40.1108980178833,
						["NXKills"] = 1,
						["NXName"] = "Storm Rager",
						["NXTime"] = 1244158945.00006,
						["T"] = "K",
						["NXMapId"] = 3003,
					}, -- [23]
					{
						["NXX"] = 27.0947277545929,
						["NXY"] = 10.51730811595917,
						["NXKills"] = 1,
						["NXName"] = "Gordunni Back-Breaker",
						["NXTime"] = 1244159180.000063,
						["T"] = "K",
						["NXMapId"] = 3007,
					}, -- [24]
					{
						["NXX"] = 27.0947277545929,
						["NXY"] = 10.51730811595917,
						["NXKills"] = 1,
						["NXName"] = "Gordunni Head-Splitter",
						["NXTime"] = 1244159190.000064,
						["T"] = "K",
						["NXMapId"] = 3007,
					}, -- [25]
					{
						["NXX"] = 26.62413418292999,
						["NXY"] = 10.26435494422913,
						["NXKills"] = 1,
						["NXName"] = "Gordunni Elementalist",
						["NXTime"] = 1244159204.000065,
						["T"] = "K",
						["NXMapId"] = 3007,
					}, -- [26]
					{
						["NXX"] = 26.62413418292999,
						["NXY"] = 10.26435494422913,
						["NXKills"] = 2,
						["NXName"] = "Gordunni Elementalist",
						["NXTime"] = 1244159214.000066,
						["T"] = "K",
						["NXMapId"] = 3007,
					}, -- [27]
					{
						["NXX"] = 26.80874764919281,
						["NXY"] = 10.25939732789993,
						["NXKills"] = 3,
						["NXName"] = "Gordunni Elementalist",
						["NXTime"] = 1244159227.000067,
						["T"] = "K",
						["NXMapId"] = 3007,
					}, -- [28]
					{
						["NXX"] = 24.69254732131958,
						["NXY"] = 9.202346950769424,
						["NXKills"] = 2,
						["NXName"] = "Gordunni Back-Breaker",
						["NXTime"] = 1244159260.000068,
						["T"] = "K",
						["NXMapId"] = 3007,
					}, -- [29]
					{
						["NXX"] = 23.8658145070076,
						["NXY"] = 9.264100342988968,
						["NXKills"] = 1,
						["NXName"] = "Gordunni Soulreaper",
						["NXTime"] = 1244159289.000069,
						["T"] = "K",
						["NXMapId"] = 3007,
					}, -- [30]
					{
						["NXX"] = 24.09972846508026,
						["NXY"] = 9.186246991157532,
						["NXKills"] = 1,
						["NXName"] = "Skeleton",
						["NXTime"] = 1244159294.00007,
						["T"] = "K",
						["NXMapId"] = 3007,
					}, -- [31]
					{
						["NXX"] = 24.09972846508026,
						["NXY"] = 9.186246991157532,
						["NXKills"] = 2,
						["NXName"] = "Skeleton",
						["NXTime"] = 1244159294.000071,
						["T"] = "K",
						["NXMapId"] = 3007,
					}, -- [32]
					{
						["NXX"] = 24.09972846508026,
						["NXY"] = 9.186246991157532,
						["NXKills"] = 3,
						["NXName"] = "Skeleton",
						["NXTime"] = 1244159294.000072,
						["T"] = "K",
						["NXMapId"] = 3007,
					}, -- [33]
					{
						["NXX"] = 24.3097797036171,
						["NXY"] = 9.22774076461792,
						["NXKills"] = 2,
						["NXName"] = "Gordunni Head-Splitter",
						["NXTime"] = 1244159306.000073,
						["T"] = "K",
						["NXMapId"] = 3007,
					}, -- [34]
					{
						["NXX"] = 52.98042893409729,
						["NXY"] = 53.12252640724182,
						["NXKills"] = 1,
						["NXName"] = "Enraged Fire Spirit",
						["NXTime"] = 1244159486.000078,
						["T"] = "K",
						["NXMapId"] = 3005,
					}, -- [35]
					{
						["NXX"] = 52.71273255348206,
						["NXY"] = 52.47581005096436,
						["NXKills"] = 2,
						["NXName"] = "Enraged Fire Spirit",
						["NXTime"] = 1244159503.000079,
						["T"] = "K",
						["NXMapId"] = 3005,
					}, -- [36]
					{
						["NXX"] = 52.57651209831238,
						["NXY"] = 52.10145115852356,
						["NXKills"] = 3,
						["NXName"] = "Enraged Fire Spirit",
						["NXTime"] = 1244159514.00008,
						["T"] = "K",
						["NXMapId"] = 3005,
					}, -- [37]
					{
						["NXX"] = 52.36719250679016,
						["NXY"] = 51.95024609565735,
						["NXKills"] = 4,
						["NXName"] = "Enraged Fire Spirit",
						["NXTime"] = 1244159532.000081,
						["T"] = "K",
						["NXMapId"] = 3005,
					}, -- [38]
					{
						["NXX"] = 52.35370397567749,
						["NXY"] = 51.95720195770264,
						["NXKills"] = 1,
						["NXName"] = "Spawn of Uvuros",
						["NXTime"] = 1244159536.000082,
						["T"] = "K",
						["NXMapId"] = 3005,
					}, -- [39]
					{
						["NXX"] = 51.68815851211548,
						["NXY"] = 54.83238101005554,
						["NXKills"] = 5,
						["NXName"] = "Enraged Fire Spirit",
						["NXTime"] = 1244159559.000083,
						["T"] = "K",
						["NXMapId"] = 3005,
					}, -- [40]
					{
						["NXX"] = 51.57831311225891,
						["NXY"] = 54.78105545043945,
						["NXKills"] = 1,
						["NXName"] = "Enraged Earth Spirit",
						["NXTime"] = 1244159571.000084,
						["T"] = "K",
						["NXMapId"] = 3005,
					}, -- [41]
					{
						["NXX"] = 51.57831311225891,
						["NXY"] = 54.78105545043945,
						["NXKills"] = 1,
						["NXName"] = "Enraged Earth Shard",
						["NXTime"] = 1244159578.000085,
						["T"] = "K",
						["NXMapId"] = 3005,
					}, -- [42]
					{
						["NXX"] = 51.09694600105286,
						["NXY"] = 54.57764863967896,
						["NXKills"] = 6,
						["NXName"] = "Enraged Fire Spirit",
						["NXTime"] = 1244159594.000086,
						["T"] = "K",
						["NXMapId"] = 3005,
					}, -- [43]
					{
						["NXX"] = 50.04608035087585,
						["NXY"] = 52.36741900444031,
						["NXKills"] = 7,
						["NXName"] = "Enraged Fire Spirit",
						["NXTime"] = 1244159623.000087,
						["T"] = "K",
						["NXMapId"] = 3005,
					}, -- [44]
					{
						["NXX"] = 49.43913221359253,
						["NXY"] = 52.17022895812988,
						["NXKills"] = 8,
						["NXName"] = "Enraged Fire Spirit",
						["NXTime"] = 1244159808.000088,
						["T"] = "K",
						["NXMapId"] = 3005,
					}, -- [45]
					{
						["NXX"] = 49.43331778049469,
						["NXY"] = 52.18160152435303,
						["NXKills"] = 2,
						["NXName"] = "Enraged Earth Spirit",
						["NXTime"] = 1244159816.000089,
						["T"] = "K",
						["NXMapId"] = 3005,
					}, -- [46]
					{
						["NXX"] = 49.43331778049469,
						["NXY"] = 52.18160152435303,
						["NXKills"] = 2,
						["NXName"] = "Enraged Earth Shard",
						["NXTime"] = 1244159821.00009,
						["T"] = "K",
						["NXMapId"] = 3005,
					}, -- [47]
					{
						["NXX"] = 49.6342271566391,
						["NXY"] = 51.70051455497742,
						["NXKills"] = 9,
						["NXName"] = "Enraged Fire Spirit",
						["NXTime"] = 1244159837.000091,
						["T"] = "K",
						["NXMapId"] = 3005,
					}, -- [48]
					{
						["NXX"] = 49.78543519973755,
						["NXY"] = 50.24707913398743,
						["NXKills"] = 10,
						["NXName"] = "Enraged Fire Spirit",
						["NXTime"] = 1244159855.000092,
						["T"] = "K",
						["NXMapId"] = 3005,
					}, -- [49]
					{
						["NXX"] = 49.20944273471832,
						["NXY"] = 50.2080500125885,
						["NXKills"] = 11,
						["NXName"] = "Enraged Fire Spirit",
						["NXTime"] = 1244159871.000093,
						["T"] = "K",
						["NXMapId"] = 3005,
					}, -- [50]
				},
				["Mine"] = {
				},
				["Herb"] = {
					{
						["NXX"] = 47.72688746452332,
						["NXY"] = 32.18592405319214,
						["NXName"] = "Glowcap",
						["NXTime"] = 1242896738.000043,
						["T"] = "H",
						["NXMapId"] = 3008,
					}, -- [1]
					{
						["NXX"] = 49.14136528968811,
						["NXY"] = 31.90313279628754,
						["NXName"] = "Glowcap",
						["NXTime"] = 1242896752.000044,
						["T"] = "H",
						["NXMapId"] = 3008,
					}, -- [2]
					{
						["NXX"] = 49.16905760765076,
						["NXY"] = 31.90712928771973,
						["NXName"] = "Glowcap",
						["NXTime"] = 1242896762.000045,
						["T"] = "H",
						["NXMapId"] = 3008,
					}, -- [3]
					{
						["NXX"] = 44.91972923278809,
						["NXY"] = 34.75079536437988,
						["NXName"] = "Glowcap",
						["NXTime"] = 1242896800.000047,
						["T"] = "H",
						["NXMapId"] = 3008,
					}, -- [4]
					{
						["NXX"] = 45.42353451251984,
						["NXY"] = 34.39897000789642,
						["NXName"] = "Glowcap",
						["NXTime"] = 1242896816.000049,
						["T"] = "H",
						["NXMapId"] = 3008,
					}, -- [5]
					{
						["NXX"] = 42.05918908119202,
						["NXY"] = 31.72426223754883,
						["NXName"] = "Glowcap",
						["NXTime"] = 1242896847.000051,
						["T"] = "H",
						["NXMapId"] = 3008,
					}, -- [6]
					{
						["NXX"] = 40.67894220352173,
						["NXY"] = 31.81038498878479,
						["NXName"] = "Glowcap",
						["NXTime"] = 1242896867.000052,
						["T"] = "H",
						["NXMapId"] = 3008,
					}, -- [7]
					{
						["NXX"] = 40.0452733039856,
						["NXY"] = 36.35528385639191,
						["NXName"] = "Glowcap",
						["NXTime"] = 1242896948.000058,
						["T"] = "H",
						["NXMapId"] = 3008,
					}, -- [8]
					{
						["NXX"] = 39.72385227680206,
						["NXY"] = 34.63945388793945,
						["NXName"] = "Glowcap",
						["NXTime"] = 1242896981.000061,
						["T"] = "H",
						["NXMapId"] = 3008,
					}, -- [9]
					{
						["NXX"] = 39.56817090511322,
						["NXY"] = 34.70765352249146,
						["NXName"] = "Glowcap",
						["NXTime"] = 1242896989.000062,
						["T"] = "H",
						["NXMapId"] = 3008,
					}, -- [10]
					{
						["NXX"] = 39.41056728363037,
						["NXY"] = 38.13080489635468,
						["NXName"] = "Glowcap",
						["NXTime"] = 1242897029.000065,
						["T"] = "H",
						["NXMapId"] = 3008,
					}, -- [11]
				},
			},
			["Class"] = "Priest",
			["LLevel"] = 70,
			["LArenaPts"] = 1607,
			["TBar"] = {
				["Version"] = 0.1,
				["NxMap1TB"] = {
					["Space"] = 1,
					["AlignR"] = true,
					["AlignB"] = true,
					["Size"] = 18.37994612595363,
				},
			},
			["TimePlayed"] = 15496442,
			["L"] = {
				["Events"] = {
				},
				["Version"] = 0.1,
				["FavI"] = {
				},
				["Social"] = {
				},
				["Quest"] = {
					["ColW"] = "20^310^0^600^200^500",
				},
				["FavF"] = {
				},
			},
			["XP"] = 489,
			["Level"] = 70,
			["Q"] = {
				[11156] = "C1241206844",
				[11180] = "C1241203276",
				[3062] = "C1241279486",
				[5102] = "C1240910693",
				[6161] = "C1241417652",
				[5142] = "C1240993840",
				[5146] = "C1240859514",
				[8255] = "C1240821246",
				[5158] = "C1241424983",
				[8279] = "C1241038158",
				[8287] = "C1241038451",
				[11372] = "C1241022266",
				[11388] = "c0",
				[8351] = "C1241108997",
				[524] = "C1240684694",
				[32] = "C1240659286",
				[3124] = "C1241279506",
				[3126] = "C1241281980",
				[5242] = "C1241430131",
				[264] = "C1240681340",
				[1058] = "C1240754674",
				[1060] = "C1240753345",
				[6301] = "C1240764551",
				[1066] = "C1240774417",
				[1067] = "C1240785592",
				[6321] = "C1240681438",
				[4291] = "C1240830552",
				[11668] = "C1241131375",
				[6381] = "C1240764961",
				[1086] = "C1240818842",
				[8687] = "c0",
				[1089] = "C1240765829",
				[6401] = "C1241921191",
				[8735] = "c0",
				[1096] = "C1241378819",
				[1102] = "C1240761712",
				[1104] = "C1241384091",
				[6461] = "C1240755229",
				[1106] = "C1241388988",
				[1107] = "C1241391305",
				[1108] = "C1241389380",
				[1109] = "C1240772759",
				[1113] = "C1241014230",
				[1114] = "C1241383720",
				[1115] = "C1241387223",
				[5482] = "C1240699520",
				[1117] = "C1241391300",
				[1118] = "C1241452189",
				[1119] = "C1241453063",
				[6521] = "C1240772869",
				[5502] = "C1241119046",
				[1122] = "C1241453970",
				[1123] = "C1240647051",
				[1124] = "C1240655159",
				[1125] = "C1240656246",
				[1126] = "C1240656671",
				[5526] = "c0",
				[4507] = "C1240771590",
				[5534] = "C1240824068",
				[6561] = "C1240954636",
				[1131] = "C1241213619",
				[11085] = "C1242562168",
				[1136] = "C1241304719",
				[1137] = "C1241391311",
				[9111] = "c0",
				[2283] = "C1240914649",
				[11173] = "C1241206811",
				[11181] = "C1241203530",
				[6621] = "C1241376313",
				[11213] = "C1241206160",
				[1152] = "C1241378714",
				[1153] = "C1240828495",
				[1154] = "C1241380008",
				[9239] = "c0",
				[1159] = "C1241380512",
				[1160] = "C1241381646",
				[8256] = "C1240822449",
				[11341] = "c0",
				[8280] = "C1241029370",
				[1166] = "C1241208529",
				[7732] = "C1241286675",
				[1168] = "C1241208542",
				[1169] = "C1241208553",
				[2339] = "c0",
				[1171] = "C1241208663",
				[1172] = "C1241209930",
				[1173] = "C1241210063",
				[8352] = "C1241112718",
				[3374] = "c0",
				[3376] = "C1240996780",
				[5730] = "C1241026700",
				[3382] = "C1242318047",
				[9431] = "C1240768722",
				[9439] = "C1240912752",
				[4743] = "C1243837186",
				[7816] = "C1240784558",
				[7828] = "C1240784554",
				[7840] = "C1240784582",
				[7844] = "C1240784460",
				[1197] = "C1240768031",
				[4787] = "C1240748463",
				[6845] = "C1240660008",
				[1202] = "C1241208521",
				[1203] = "C1241204811",
				[1205] = "C1241211613",
				[1206] = "C1241204698",
				[3444] = "C1240748310",
				[3446] = "C1240847102",
				[1218] = "C1241203349",
				[6921] = "C1240953828",
				[1221] = "C1240761402",
				[4883] = "C1241295926",
				[4907] = "C1241300392",
				[1239] = "C1241205074",
				[1240] = "C1241266995",
				[3506] = "C1240821408",
				[3508] = "C1242317755",
				[3512] = "C1240778644",
				[3514] = "C1240817718",
				[7029] = "C1240645686",
				[4987] = "C1240995111",
				[3520] = "C1240648175",
				[1251] = "C1241210244",
				[626] = "C1241209013",
				[3528] = "C1240851708",
				[5023] = "C1240994535",
				[1261] = "C1241286201",
				[1262] = "C1241286731",
				[8120] = "C1240855575",
				[1268] = "C1241210236",
				[11158] = "C1241208012",
				[1270] = "C1241211154",
				[11174] = "C1241205996",
				[9136] = "C1240682055",
				[3568] = "C1240747794",
				[6134] = "C1240636344",
				[640] = "C1240857410",
				[9208] = "c0",
				[1282] = "C1241203838",
				[9232] = "c0",
				[9240] = "c0",
				[9248] = "C1241189869",
				[4120] = "C1241296267",
				[5147] = "C1240770375",
				[645] = "C1240860049",
				[4136] = "c0",
				[646] = "C1240860303",
				[8281] = "C1241031823",
				[8321] = "C1241029429",
				[2601] = "c0",
				[651] = "C1240857223",
				[3628] = "C1241933048",
				[652] = "C1240857833",
				[9440] = "C1240775776",
				[656] = "C1240916684",
				[4244] = "C1240833228",
				[1321] = "C1241210253",
				[1322] = "C1241210517",
				[1323] = "C1241210536",
				[662] = "C1240862311",
				[6322] = "C1240681707",
				[664] = "C1240862326",
				[4292] = "C1240831527",
				[4296] = "C1240908671",
				[666] = "C1240862332",
				[668] = "C1240862357",
				[4324] = "C1240783569",
				[670] = "c0",
				[6382] = "C1240817593",
				[6394] = "C1240703807",
				[8697] = "W0",
				[673] = "C1240858638",
				[7441] = "C1242300223",
				[6442] = "C1240763607",
				[1358] = "C1240701953",
				[1359] = "C1240691363",
				[680] = "C1240857453",
				[1361] = "C1240599833",
				[7489] = "C1241279493",
				[1366] = "c0",
				[10951] = "C1241116636",
				[8921] = "W0",
				[687] = "C1240905889",
				[688] = "C1240858645",
				[172] = "C1241115542",
				[6542] = "C1240762478",
				[3786] = "C1240660394",
				[5527] = "C1240660012",
				[692] = "C1240907207",
				[5535] = "C1240822206",
				[1389] = "C1240778332",
				[1392] = "C1240782931",
				[1393] = "C1240777888",
				[1394] = "C1241383538",
				[698] = "C1240780435",
				[11159] = "C1241208012",
				[699] = "C1240781173",
				[3822] = "C1240911008",
				[11207] = "C1241205996",
				[11215] = "C1241207445",
				[703] = "C1240912651",
				[9209] = "c0",
				[705] = "C1240918962",
				[3844] = "C1240829830",
				[8282] = "C1241036825",
				[1422] = "C1240781215",
				[8306] = "C1241036896",
				[8314] = "C1241038439",
				[1426] = "C1240781574",
				[1427] = "C1240781605",
				[1428] = "C1240782804",
				[1429] = "C1240784950",
				[1430] = "C1240779877",
				[716] = "c0",
				[5727] = "C1241025871",
				[359] = "C1240694630",
				[360] = "C1240695995",
				[5763] = "C1240676272",
				[3908] = "C1240837327",
				[1444] = "C1240816313",
				[1445] = "C1240848429",
				[1446] = "C1240849514",
				[7829] = "C1240784555",
				[7841] = "C1240784561",
				[7845] = "C1240784567",
				[7849] = "C1240784555",
				[4788] = "C1243835375",
				[7861] = "C1240784590",
				[8578] = "C1243044299",
				[4808] = "C1240915172",
				[10656] = "C1241913395",
				[366] = "C1240680672",
				[9665] = "c0",
				[2935] = "C1240702424",
				[367] = "C1240697535",
				[736] = "C1240747738",
				[368] = "C1240699169",
				[737] = "C1240783839",
				[369] = "C1240700054",
				[370] = "C1240697202",
				[2965] = "C1240661815",
				[2967] = "C1240675366",
				[371] = "C1240697884",
				[743] = "C1240956871",
				[372] = "C1240699996",
				[745] = "C1240956854",
				[746] = "C1240956857",
				[747] = "C1240995858",
				[374] = "C1240697213",
				[11975] = "C1241198726",
				[750] = "C1240996390",
				[8930] = "C1241366620",
				[4984] = "C1240993115",
				[752] = "C1240995660",
				[753] = "C1240995867",
				[8978] = "C1241306948",
				[755] = "C1240996004",
				[7066] = "C1240646941",
				[757] = "C1240996411",
				[11080] = "C1242508472",
				[8121] = "C1240855576",
				[5056] = "C1240944971",
				[761] = "C1240956897",
				[1524] = "C1242326802",
				[9114] = "c0",
				[763] = "C1240997033",
				[4082] = "c0",
				[11208] = "C1241205996",
				[8169] = "C1240855575",
				[767] = "C1240955677",
				[8181] = "C1243835461",
				[9210] = "c0",
				[771] = "C1240956777",
				[772] = "C1240957085",
				[5152] = "C1240999524",
				[773] = "C1240957201",
				[8283] = "C1241031965",
				[775] = "C1240957326",
				[776] = "C1240957469",
				[8315] = "C1241038850",
				[5204] = "C1241428961",
				[780] = "C1240996776",
				[3125] = "C1241280694",
				[3127] = "C1241283896",
				[9434] = "C1240769763",
				[3141] = "C1242317755",
				[4245] = "C1240833460",
				[10553] = "C1241913643",
				[789] = "C1240703284",
				[790] = "C1240703386",
				[8539] = "c0",
				[6323] = "C1240681682",
				[4289] = "C1240833636",
				[4293] = "C1240850348",
				[4301] = "C1240840424",
				[398] = "C1240697366",
				[99] = "C1240690110",
				[8731] = "C1241089391",
				[804] = "C1240703433",
				[805] = "C1240703923",
				[3221] = "C1240690949",
				[8787] = "W0",
				[2202] = "C1240912767",
				[10945] = "C1241116260",
				[10953] = "C1241116133",
				[8923] = "C1241082763",
				[3261] = "C1240767012",
				[6523] = "C1241920869",
				[408] = "C1240696679",
				[6543] = "C1240817720",
				[5524] = "c0",
				[4505] = "C1240950208",
				[4509] = "C1240816774",
				[5536] = "C1240822209",
				[6563] = "C1240953823",
				[4521] = "C1240949010",
				[822] = "c0",
				[411] = "C1240680958",
				[11129] = "C1240997423",
				[3301] = "C1240681356",
				[6607] = "C1241205855",
				[11169] = "C1241206518",
				[1656] = "C1240997045",
				[6627] = "C1241380093",
				[11217] = "C1241208009",
				[11225] = "C1241203068",
				[10218] = "c0",
				[9211] = "c0",
				[2318] = "C1240919794",
				[8284] = "C1241030708",
				[7730] = "C1241281957",
				[2338] = "C1240919808",
				[3369] = "C1240633071",
				[5724] = "C1240661618",
				[422] = "C1240686458",
				[423] = "C1240686802",
				[9443] = "c0",
				[424] = "C1240687561",
				[4741] = "C1241292985",
				[850] = "C1240600211",
				[425] = "C1240690793",
				[851] = "C1240631570",
				[7830] = "C1240784554",
				[4765] = "C1240910688",
				[426] = "C1240699017",
				[7842] = "C1240784561",
				[7850] = "C1240784567",
				[427] = "C1240696659",
				[855] = "C1240630734",
				[7862] = "C1240784592",
				[428] = "C1240687756",
				[4809] = "C1240915903",
				[11665] = "C1243983605",
				[429] = "C1240688329",
				[8620] = "c0",
				[2418] = "C1240912642",
				[3447] = "C1240847078",
				[863] = "C1242326422",
				[867] = "C1240752398",
				[868] = "C1240788385",
				[8772] = "c0",
				[435] = "C1240690668",
				[4921] = "C1240766686",
				[873] = "C1240790034",
				[874] = "C1240789675",
				[437] = "C1240688264",
				[875] = "C1240752803",
				[3501] = "c0",
				[876] = "C1240753096",
				[3505] = "C1240746934",
				[3507] = "C1240823430",
				[3509] = "C1242317755",
				[8916] = "W0",
				[8924] = "C1241223749",
				[4985] = "C1240993355",
				[440] = "C1240694553",
				[3527] = "C1240650754",
				[441] = "C1240694722",
				[883] = "C1242329023",
				[7067] = "c0",
				[442] = "C1240692915",
				[110] = "C1240652500",
				[443] = "C1240690129",
				[5049] = "C1240994568",
				[888] = "C1240705077",
				[444] = "C1240691489",
				[5065] = "C1241937490",
				[11162] = "C1241208013",
				[5081] = "C1240910693",
				[11186] = "C1241208523",
				[3569] = "C1240772924",
				[8170] = "C1240855575",
				[447] = "C1240691344",
				[6132] = "C1240636068",
				[8182] = "C1243836461",
				[448] = "C1240691923",
				[4102] = "C1241422298",
				[449] = "C1240690889",
				[5149] = "C1240994008",
				[5153] = "c0",
				[901] = "C1242326601",
				[8277] = "W0",
				[4146] = "C1240851992",
				[8309] = "C1241037315",
				[452] = "C1240692284",
				[905] = "C1240766694",
				[3621] = "C1241928309",
				[8341] = "C1241108894",
				[3625] = "C1241928350",
				[907] = "C1240789216",
				[5213] = "c0",
				[113] = "C1240652593",
				[910] = "C1241118583",
				[911] = "C1241118586",
				[5241] = "C1240994223",
				[11506] = "C1243598236",
				[913] = "C1240789346",
				[6284] = "C1240755607",
				[915] = "C1241118696",
				[10] = "C1240652325",
				[3924] = "c0",
				[897] = "C1242328721",
				[6324] = "C1240685471",
				[2521] = "c0",
				[11124] = "C1241210134",
				[8573] = "c0",
				[4294] = "C1240850353",
				[5050] = "C1240999143",
				[11666] = "C1243395055",
				[2585] = "c0",
				[2583] = "c0",
				[2581] = "C1241932181",
				[3626] = "C1241928720",
				[9433] = "C1240769135",
				[925] = "C1241118908",
				[1121] = "c0",
				[3602] = "C1241926572",
				[5361] = "C1240787083",
				[2478] = "C1242326416",
				[2603] = "c0",
				[10416] = "C1243938809",
				[5202] = "C1241427338",
				[5381] = "C1240637309",
				[5385] = "C1241430137",
				[5165] = "C1241428323",
				[8733] = "C1240864611",
				[5159] = "C1241426606",
				[3561] = "C1240747424",
				[8940] = "C1241306974",
				[5156] = "C1241422254",
				[8773] = "C1241089418",
				[8171] = "C1240855574",
				[8928] = "C1241306459",
				[4402] = "C1240703023",
				[4496] = "C1240674523",
				[5021] = "C1240992710",
				[2903] = "C1241226373",
				[5441] = "C1240703165",
				[2841] = "c0",
				[11161] = "C1241208012",
				[446] = "C1240691804",
				[766] = "C1240956793",
				[11008] = "C1243940885",
				[3063] = "C1241279488",
				[1177] = "C1241208710",
				[357] = "C1240680522",
				[641] = "C1240857464",
				[5481] = "C1240699202",
				[10963] = "C1241118018",
				[8925] = "C1241306444",
				[713] = "C1240917176",
				[1424] = "C1240777191",
				[5501] = "C1241417899",
				[8257] = "C1240863206",
				[421] = "C1240686149",
				[5517] = "c0",
				[4494] = "C1240673667",
				[1170] = "C1241208651",
				[2766] = "C1241276322",
				[4506] = "C1240950957",
				[4123] = "c0",
				[3601] = "C1240820325",
				[1800] = "C1241118687",
				[451] = "C1240694202",
				[2954] = "C1240674821",
				[8285] = "C1241031144",
				[2284] = "C1240919475",
				[2782] = "C1240784547",
				[5728] = "C1241026531",
				[4022] = "c0",
				[8548] = "c0",
				[6030] = "C1240959786",
				[5581] = "C1240637805",
				[477] = "C1240687004",
				[356] = "C1240697854",
				[3821] = "C1240909880",
				[5601] = "c0",
				[478] = "C1240687550",
				[6628] = "C1241381800",
				[11183] = "C1241203658",
				[4511] = "C1240816872",
				[479] = "C1240690099",
				[409] = "C1240680773",
				[1362] = "C1240633751",
				[6605] = "C1240946048",
				[480] = "C1240690451",
				[8304] = "C1241031893",
				[3845] = "C1240832377",
				[962] = "C1240749329",
				[481] = "C1240687571",
				[5051] = "C1240999222",
				[11669] = "c0",
				[669] = "C1240914214",
				[482] = "C1240687579",
				[679] = "C1240857461",
				[11339] = "c0",
				[8278] = "C1241033719",
				[11342] = "C1241134551",
				[7731] = "C1241281959",
				[11371] = "c0",
				[8310] = "C1241038294",
				[492] = "C1240700118",
				[969] = "C1240945615",
				[6844] = "C1240659918",
				[665] = "C1240860762",
				[9229] = "c0",
				[7944] = "C1241279891",
				[10412] = "C1241913745",
				[8809] = "c0",
				[5729] = "C1241026624",
				[8254] = "C1240820813",
				[7843] = "C1240784561",
				[3921] = "C1242327217",
				[9437] = "C1241205049",
				[4726] = "C1240910784",
				[11499] = "C1241630222",
				[4734] = "c0",
				[1088] = "C1240763938",
				[4742] = "C1243829375",
				[7815] = "C1240784558",
				[794] = "C1240703819",
				[11547] = "C1241630158",
				[793] = "C1240907503",
				[8734] = "C1240938410",
				[975] = "C1240945626",
				[7839] = "C1240784565",
				[3923] = "C1242331147",
				[2902] = "C1241224879",
				[3782] = "C1240633112",
				[438] = "C1240688404",
				[10942] = "C1241115882",
				[439] = "C1240688476",
				[5821] = "C1241416468",
				[8574] = "c0",
				[1269] = "C1241210241",
				[4810] = "C1241017625",
				[4642] = "C1240854081",
				[2937] = "C1240791994",
				[5726] = "C1241025616",
				[5722] = "C1240661107",
				[10967] = "C1241200030",
				[644] = "C1240859731",
				[5723] = "C1240661621",
				[2934] = "C1240684178",
				[2936] = "C1240790205",
				[2938] = "C1240792264",
				[8572] = "c0",
				[7726] = "c0",
				[430] = "C1240689368",
				[4866] = "c0",
				[450] = "C1240692888",
				[5163] = "C1241298767",
				[5901] = "c0",
				[4882] = "C1241294157",
				[7725] = "c0",
				[3981] = "c0",
				[714] = "c0",
				[4290] = "C1240830128",
				[11051] = "C1242508056",
				[2966] = "C1240674779",
				[2968] = "C1240675430",
				[517] = "C1240684645",
				[516] = "C1240687553",
				[643] = "C1240858658",
				[642] = "C1240858842",
				[1201] = "C1241205070",
				[895] = "C1240705086",
				[361] = "C1240700093",
				[852] = "C1240631988",
				[3565] = "C1240747549",
				[11160] = "C1241208011",
				[10924] = "C1242316374",
				[882] = "C1240788950",
				[1116] = "C1241389839",
				[4062] = "C1240911101",
				[4021] = "C1240632229",
				[3627] = "C1241932279",
				[2767] = "C1241301250",
				[3129] = "C1241283935",
				[8485] = "C1241295545",
				[4721] = "C1241294155",
				[8481] = "C1241292717",
				[8945] = "c0",
				[5203] = "C1241428318",
				[819] = "C1242326866",
				[1120] = "C1241453154",
				[530] = "C1240695755",
				[11097] = "C1241915216",
				[7068] = "C1240646440",
				[445] = "C1240700606",
				[858] = "C1242326421",
				[902] = "C1242326841",
				[3922] = "C1242327634",
				[821] = "C1242329489",
				[11023] = "C1242507736",
				[4061] = "C1240911011",
				[4063] = "c0",
				[11066] = "C1242507742",
				[11373] = "c0",
				[1065] = "C1240774155",
				[7001] = "c0",
			},
			["LMoney"] = 716034488,
			["LvlTime"] = 1244302282,
			["Honor"] = 37077,
			["Money"] = 715704884,
			["Time"] = 1244304011,
			["W"] = {
				["NxHUD"] = {
					["_W"] = 8,
					["FI"] = 1,
					["FO"] = 0.15,
					["X"] = 795.9999880790713,
					["W"] = 8,
					["Lk"] = true,
					["Y"] = 203.9999839901927,
					["H"] = 40,
					["_X"] = 999999,
					["_H"] = 40,
					["_Y"] = -0.17,
					["Hide"] = true,
				},
				["NxMapDock"] = {
					["A"] = "TOPRIGHT",
					["_W"] = 52,
					["S"] = 1,
					["FI"] = 1,
					["FO"] = 0,
					["W"] = 47.99997735023532,
					["Y"] = 195.6094521938346,
					["H"] = 40,
					["X"] = -6.249904539437525,
					["_H"] = 69,
					["_L"] = 2,
					["L"] = 2,
					["_Y"] = -0.08,
					["_X"] = 100045,
				},
				["NxQuestList"] = {
					["A"] = "CENTER",
					["FI"] = 1,
					["FO"] = 0.75,
					["MaxY"] = 119.9999886751177,
					["H"] = 625.3127958578945,
					["_H"] = -0.65,
					["MaxA"] = "TOPLEFT",
					["Hide"] = true,
					["MaxS"] = 1,
					["_W"] = -0.52,
					["S"] = 1,
					["MaxX"] = 159.9999976158142,
					["W"] = 907.4992235377547,
					["MaxL"] = 2,
					["Y"] = 25.07853470625677,
					["X"] = -27.25052792950678,
					["MaxH"] = 959.9999094009413,
					["_Y"] = -0.15,
					["MaxW"] = 1279.999980926514,
					["_X"] = -0.24,
				},
				["NxTeamHUD"] = {
					["_W"] = 107,
					["FI"] = 0.5,
					["FO"] = 0,
					["X"] = 959.9999856948855,
					["W"] = 107,
					["Hide"] = true,
					["Y"] = 359.9999717473988,
					["H"] = 40,
					["_H"] = 40,
					["_Y"] = -0.3,
					["_X"] = -0.6,
				},
				["NxDD"] = {
					["A"] = "CENTER",
					["_W"] = 207,
					["S"] = 1,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = 207.0000236183402,
					["Y"] = 83.95308369468027,
					["X"] = -261.4999350681911,
					["_H"] = 209,
					["H"] = 208.9999930709602,
					["L"] = 4,
					["_Y"] = 0,
					["_X"] = 0,
				},
				["NxFav"] = {
					["A"] = "CENTER",
					["_W"] = -0.54,
					["S"] = 1,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = 864.00007867813,
					["Y"] = 46.87506129033772,
					["H"] = 599.9999529123313,
					["_H"] = -0.5,
					["X"] = -1.249968986958727,
					["_Y"] = -0.25,
					["_X"] = -0.23,
				},
				["NxSocial"] = {
					["_W"] = -0.5,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = 799.9999880790713,
					["Y"] = 215.9999830484393,
					["X"] = 399.9999940395356,
					["_H"] = -0.64,
					["Hide"] = true,
					["H"] = 767.9999397277841,
					["_Y"] = -0.18,
					["_X"] = -0.25,
				},
				["NxMap1"] = {
					["9002L"] = 1,
					["FI"] = 1,
					["FO"] = 0,
					["9008L"] = 1,
					["MaxY"] = 38.67214860510605,
					["9001Y"] = 29.06230883207457,
					["9003H"] = 40,
					["_H"] = -0.3,
					["_L"] = 1,
					["9004W"] = 100.000027120113,
					["MaxL"] = 2,
					["9004A"] = "BOTTOMRIGHT",
					["9008H"] = -0.3,
					["9002X"] = 71.40982044622569,
					["H"] = 40.00000894069658,
					["9001H"] = 40,
					["9003S"] = 1,
					["9003Y"] = 30.15601113206132,
					["9002H"] = 44.68750887084739,
					["9002W"] = 100.000027120113,
					["9002A"] = "BOTTOMRIGHT",
					["MaxH"] = 784.2186620202861,
					["MaxX"] = -54.99970830977398,
					["9004S"] = 1,
					["9001A"] = "BOTTOMRIGHT",
					["9008Y"] = -0.4,
					["9004L"] = 1,
					["A"] = "BOTTOMRIGHT",
					["9001T"] = 0.01,
					["9002S"] = 1,
					["9003A"] = "BOTTOMRIGHT",
					["9002T"] = 0.01,
					["9003W"] = 99.99999850988391,
					["MaxW"] = 1097.499983645976,
					["9003T"] = 0.01,
					["9002Y"] = 34.84365411335745,
					["9004H"] = 40,
					["9003L"] = 1,
					["9003X"] = 83.90891903774561,
					["9004Y"] = 31.40613509109415,
					["L"] = 1,
					["MaxA"] = "CENTER",
					["9001L"] = 1,
					["MaxS"] = 1,
					["_W"] = -0.19,
					["S"] = 1,
					["_X"] = -0.0001,
					["9001W"] = 100.000027120113,
					["T"] = 0.01,
					["W"] = 100.000027120113,
					["9008X"] = -0.0001,
					["Y"] = 9.69991490692027,
					["X"] = 38.85126055998712,
					["9004T"] = 0.01,
					["9001S"] = 1,
					["9004X"] = 67.6599730899934,
					["9001X"] = 60.40978341684068,
					["_Y"] = -0.4,
					["9008W"] = -0.19,
				},
				["NxHelp"] = {
					["_W"] = -0.5,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = 799.9999880790713,
					["Y"] = 119.9999905824663,
					["X"] = 399.9999940395356,
					["_H"] = -0.7,
					["H"] = 839.9999340772638,
					["_Y"] = -0.1,
					["_X"] = -0.25,
				},
				["NxGuide1"] = {
					["A"] = "CENTER",
					["_W"] = -0.45,
					["S"] = 1,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = 719.9999892711641,
					["Y"] = 106.8751796055558,
					["X"] = -61.24997047707483,
					["H"] = 539.999953806401,
					["_H"] = -0.45,
					["_X"] = -0.2,
					["_Y"] = -0.2,
					["Hide"] = true,
				},
				["Version"] = 0.31,
				["NxCombat"] = {
					["_W"] = -0.3,
					["FI"] = 1,
					["FO"] = 0.75,
					["X"] = 1119.9999833107,
					["W"] = 479.9999928474427,
					["Hide"] = true,
					["Y"] = 839.9999340772638,
					["H"] = 71.99999434947975,
					["_H"] = -0.06,
					["_Y"] = -0.7,
					["_X"] = -0.7,
				},
				["NxPunkHUD"] = {
					["A"] = "LEFT",
					["_W"] = 135,
					["S"] = 1,
					["FI"] = 0.5,
					["FO"] = 0,
					["W"] = 133.9999941885472,
					["Y"] = -44.95316915283845,
					["H"] = 40,
					["X"] = 116.2500745616842,
					["_H"] = 87,
					["Hide"] = true,
					["_Y"] = -0.1,
					["_X"] = -0.6,
				},
				["NxOpts"] = {
					["A"] = "CENTER",
					["FI"] = 1,
					["FO"] = 0.75,
					["MaxY"] = 119.9999886751177,
					["H"] = 728.6718641419431,
					["_H"] = -0.7,
					["MaxA"] = "TOPLEFT",
					["MaxL"] = 2,
					["MaxS"] = 1,
					["_W"] = -0.5,
					["S"] = 1,
					["MaxX"] = 159.9999976158142,
					["W"] = 917.5001389160732,
					["Y"] = 102.3045524611391,
					["X"] = -16.24971603975123,
					["MaxH"] = 959.9999094009413,
					["MaxW"] = 1279.999980926514,
					["_Y"] = -0.1,
					["_X"] = -0.25,
				},
				["NxEventsList"] = {
					["_W"] = -0.25,
					["FI"] = 1,
					["FO"] = 0.75,
					["X"] = 1199.999982118607,
					["W"] = 399.9999940395356,
					["Hide"] = true,
					["Y"] = 719.9999434947976,
					["H"] = 119.9999905824663,
					["_H"] = -0.1,
					["_Y"] = -0.6,
					["_X"] = -0.75,
				},
				["NxQuestWatch"] = {
					["A"] = "RIGHT",
					["MinW"] = 124.9999981373549,
					["FI"] = 0.4993750042161195,
					["FO"] = 0,
					["MinX"] = -129.7507266737412,
					["HideC"] = true,
					["H"] = 214.6099821536246,
					["_H"] = -0.1,
					["MinY"] = 248.6955033437088,
					["Mode"] = "Min",
					["_W"] = -0.2,
					["S"] = 1,
					["MinH"] = 40,
					["W"] = 288.9995341152022,
					["Y"] = -229.7260250191983,
					["Min"] = true,
					["X"] = -77.25107554717249,
					["MinT"] = 0.05454952521682632,
					["MinS"] = 1,
					["MinA"] = "TOPRIGHT",
					["L"] = 2,
					["_Y"] = -0.35,
					["_X"] = -0.8,
				},
			},
			["LXPMax"] = 1523800,
			["LXPRest"] = 0,
			["WareBags"] = {
				["Essence of Undeath"] = "1^|cff1eff00|Hitem:12808:0:0:0:0:0:0:1998034258:70|h[Essence of Undeath]|h|r",
				["Filled Etched Phial"] = "1^|cffffffff|Hitem:5868:0:0:0:0:0:0:1172029419:70|h[Filled Etched Phial]|h|r",
				["Leggings of Absolution"] = "1^|cffa335ee|Hitem:31067:2746:3340:0:0:0:0:0:70|h[Leggings of Absolution]|h|r",
				["Large Brilliant Shard"] = "8^|cff0070dd|Hitem:14344:0:0:0:0:0:0:1105668205:70|h[Large Brilliant Shard]|h|r",
				["Piccolo of the Flaming Fire"] = "1^|cff0070dd|Hitem:13379:0:0:0:0:0:0:0:70|h[Piccolo of the Flaming Fire]|h|r",
				["Blackened Basilisk"] = "14^|cffffffff|Hitem:27657:0:0:0:0:0:0:842302466:70|h[Blackened Basilisk]|h|r",
				["Flint and Tinder"] = "1^|cffffffff|Hitem:4471:0:0:0:0:0:0:0:70|h[Flint and Tinder]|h|r",
				["Sulfuron Slammer"] = "8^|cffffffff|Hitem:38466:0:0:0:0:0:0:0:70|h[Sulfuron Slammer]|h|r",
				["Crescent Key"] = "1^|cffffffff|Hitem:18249:0:0:0:0:0:0:0:70|h[Crescent Key]|h|r",
				["Greater Planar Essence"] = "6^|cff1eff00|Hitem:22446:0:0:0:0:0:0:1212615606:70|h[Greater Planar Essence]|h|r",
				["Qiraji Martial Drape"] = "1^|cff0070dd|Hitem:20885:0:0:0:0:0:0:1723023658:70|h[Qiraji Martial Drape]|h|r",
				["Superior Wizard Oil"] = "1^|cffffffff|Hitem:22522:0:0:0:0:0:0:1467102122:70|h[Superior Wizard Oil]|h|r",
				["Runed Eternium Rod"] = "1^|cff0070dd|Hitem:22463:0:0:0:0:0:0:1732619008:70|h[Runed Eternium Rod]|h|r",
				["Shattrath Flask of Pure Death"] = "5^|cffffffff|Hitem:35716:0:0:0:0:0:0:0:70|h[Shattrath Flask of Pure Death]|h|r",
				["Shadow Labyrinth Key"] = "1^|cffffffff|Hitem:27991:0:0:0:0:0:0:-1147523361:70|h[Shadow Labyrinth Key]|h|r",
				["Skeleton Key"] = "1^|cffffffff|Hitem:13704:0:0:0:0:0:0:1430983578:70|h[Skeleton Key]|h|r",
				["Hi-Explosive Bomb"] = "4^|cffffffff|Hitem:10562:0:0:0:0:0:0:1793916540:70|h[Hi-Explosive Bomb]|h|r",
				["Swiftness Potion"] = "2^|cffffffff|Hitem:2459:0:0:0:0:0:0:1488511929:70|h[Swiftness Potion]|h|r",
				["Strong Fishing Pole"] = "1^|cffffffff|Hitem:6365:3269:0:0:0:0:0:0:70|h[Strong Fishing Pole]|h|r",
				["Bel'dugur's Note"] = "1^|cffffffff|Hitem:4650:0:0:0:0:0:0:1898873719:70|h[Bel'dugur's Note]|h|r",
				["Noggenfogger Elixir"] = "17^|cffffffff|Hitem:8529:0:0:0:0:0:0:0:70|h[Noggenfogger Elixir]|h|r",
				["The Scarlet Key"] = "1^|cff1eff00|Hitem:7146:0:0:0:0:0:0:0:70|h[The Scarlet Key]|h|r",
				["Frostwolf Battle Standard"] = "1^|cff0070dd|Hitem:19046:0:0:0:0:0:0:0:70|h[Frostwolf Battle Standard]|h|r",
				["The Master's Key"] = "1^|cffffffff|Hitem:24490:0:0:0:0:0:0:1120320660:70|h[The Master's Key]|h|r",
				["Flawless Diamond Solitaire"] = "1^|cffffffff|Hitem:7340:2928:0:0:0:0:0:0:70|h[Flawless Diamond Solitaire]|h|r",
				["Warpforged Key"] = "1^|cffffffff|Hitem:30634:0:0:0:0:0:0:0:70|h[Warpforged Key]|h|r",
				["Bottled Alterac Spring Water"] = "5^|cffffffff|Hitem:19318:0:0:0:0:0:0:0:70|h[Bottled Alterac Spring Water]|h|r",
				["Spicy Hot Talbuk"] = "19^|cffffffff|Hitem:33872:0:0:0:0:0:0:2112512136:70|h[Spicy Hot Talbuk]|h|r",
				["Netherweave Cloth"] = "11^|cffffffff|Hitem:21877:0:0:0:0:0:0:731141080:70|h[Netherweave Cloth]|h|r",
				["Ethereum Stasis Chamber Key"] = "1^|cff1eff00|Hitem:29750:0:0:0:0:0:0:853544130:70|h[Ethereum Stasis Chamber Key]|h|r",
				["Auchenai Key"] = "1^|cffffffff|Hitem:30633:0:0:0:0:0:0:0:70|h[Auchenai Key]|h|r",
				["Sharpened Fish Hook"] = "19^|cffffffff|Hitem:34861:0:0:0:0:0:0:-313913720:70|h[Sharpened Fish Hook]|h|r",
				["The Eye of Haramad"] = "1^|cff0070dd|Hitem:32092:0:0:0:0:0:0:2067937614:70|h[The Eye of Haramad]|h|r",
				["Reservoir Key"] = "1^|cffffffff|Hitem:30623:0:0:0:0:0:0:0:70|h[Reservoir Key]|h|r",
				["Box of Empty Vials"] = "1^|cffffffff|Hitem:10695:0:0:0:0:0:0:1946489653:70|h[Box of Empty Vials]|h|r",
				["Evil Bat Eye"] = "1^|cffffffff|Hitem:11404:0:0:0:0:0:0:775312600:70|h[Evil Bat Eye]|h|r",
				["Unstable Trigger"] = "2^|cffffffff|Hitem:10560:0:0:0:0:0:0:1210610133:70|h[Unstable Trigger]|h|r",
				["Arcane Dust"] = "22^|cffffffff|Hitem:22445:0:0:0:0:0:0:1210876635:70|h[Arcane Dust]|h|r",
				["Heavy Netherweave Bandage"] = "20^|cffffffff|Hitem:21991:0:0:0:0:0:0:582608193:70|h[Heavy Netherweave Bandage]|h|r",
				["Key to the Arcatraz"] = "1^|cffffffff|Hitem:31084:0:0:0:0:0:0:428488874:70|h[Key to the Arcatraz]|h|r",
				["Scarab Coffer Key"] = "2^|cffffffff|Hitem:21761:0:0:0:0:0:0:1850262865:70|h[Scarab Coffer Key]|h|r",
				["Nightmare Vine"] = "16^|cffffffff|Hitem:22792:0:0:0:0:0:0:1862301652:70|h[Nightmare Vine]|h|r",
				["Jasper Idol"] = "1^|cff0070dd|Hitem:20870:0:0:0:0:0:0:1301461878:70|h[Jasper Idol]|h|r",
				["Key of Time"] = "1^|cffffffff|Hitem:30635:0:0:0:0:0:0:0:70|h[Key of Time]|h|r",
				["Shattered Halls Key"] = "1^|cffffffff|Hitem:28395:0:0:0:0:0:0:303751702:70|h[Shattered Halls Key]|h|r",
				["Large Prismatic Shard"] = "26^|cff0070dd|Hitem:22449:0:0:0:0:0:0:2062376080:70|h[Large Prismatic Shard]|h|r",
				["Memento of Tyrande"] = "1^|cffa335ee|Hitem:32496:0:0:0:0:0:0:-1846016558:70|h[Memento of Tyrande]|h|r",
				["Gold Scarab"] = "5^|cff1eff00|Hitem:20859:0:0:0:0:0:0:1801447058:70|h[Gold Scarab]|h|r",
				["Super Mana Potion"] = "14^|cffffffff|Hitem:22832:0:0:0:0:0:0:0:70|h[Super Mana Potion]|h|r",
				["Pendant of the Lost Ages"] = "1^|cffa335ee|Hitem:30008:0:0:0:0:0:0:1568236647:70|h[Pendant of the Lost Ages]|h|r",
				["Romantic Picnic Basket"] = "1^|cff0070dd|Hitem:34480:0:0:0:0:0:0:-867624403:70|h[Romantic Picnic Basket]|h|r",
				["Workshop Key"] = "1^|cffffffff|Hitem:6893:0:0:0:0:0:0:1362828292:70|h[Workshop Key]|h|r",
				["Signet Ring of the Bronze Dragonflight"] = "1^|cffa335ee|Hitem:21210:0:0:0:0:0:0:1630682303:70|h[Signet Ring of the Bronze Dragonflight]|h|r",
				["Clay Scarab"] = "5^|cff1eff00|Hitem:20863:0:0:0:0:0:0:0:70|h[Clay Scarab]|h|r",
				["Wastewander Water Pouch"] = "6^|cffffffff|Hitem:8483:0:0:0:0:0:0:-1908939067:70|h[Wastewander Water Pouch]|h|r",
				["Rune Thread"] = "6^|cffffffff|Hitem:14341:0:0:0:0:0:0:0:70|h[Rune Thread]|h|r",
				["Translucent Spellthread Necklace"] = "1^|cffa335ee|Hitem:32349:0:0:0:0:0:0:1512651866:70|h[Translucent Spellthread Necklace]|h|r",
				["Narain's Robe"] = "1^|cffffffff|Hitem:21040:0:0:0:0:0:0:-851500624:70|h[Narain's Robe]|h|r",
				["Blackened Urn"] = "1^|cffffffff|Hitem:24140:0:0:0:0:0:0:1131672984:70|h[Blackened Urn]|h|r",
				["Voodoo Skull"] = "5^|cffffffff|Hitem:33081:0:0:0:0:0:0:193935194:70|h[Voodoo Skull]|h|r",
				["Simple Wood"] = "16^|cffffffff|Hitem:4470:0:0:0:0:0:0:0:70|h[Simple Wood]|h|r",
				["Hearthstone"] = "1^|cffffffff|Hitem:6948:0:0:0:0:0:0:818818612:70|h[Hearthstone]|h|r",
				["Shadowforge Key"] = "1^|cffffffff|Hitem:11000:0:0:0:0:0:0:2127976614:70|h[Shadowforge Key]|h|r",
				["Key to the City"] = "1^|cff1eff00|Hitem:12382:0:0:0:0:0:0:0:70|h[Key to the City]|h|r",
				["Blessed Medallion of Karabor"] = "1^|cffa335ee|Hitem:32757:0:0:0:0:0:0:1977768931:70|h[Blessed Medallion of Karabor]|h|r",
				["Ogre Tannin"] = "27^|cff1eff00|Hitem:18240:0:0:0:0:0:0:505656592:70|h[Ogre Tannin]|h|r",
				["Runecloth"] = "24^|cffffffff|Hitem:14047:0:0:0:0:0:0:1197215512:70|h[Runecloth]|h|r",
				["The Lightning Capacitor"] = "1^|cffa335ee|Hitem:28785:0:0:0:0:0:0:1960325948:70|h[The Lightning Capacitor]|h|r",
				["Deathforge Key"] = "1^|cffffffff|Hitem:30688:0:0:0:0:0:0:1535615959:70|h[Deathforge Key]|h|r",
				["Deviate Fish"] = "5^|cffffffff|Hitem:6522:0:0:0:0:0:0:1775661056:70|h[Deviate Fish]|h|r",
				["Elune's Lantern"] = "1^|cff1eff00|Hitem:21540:0:0:0:0:0:0:2130740002:70|h[Elune's Lantern]|h|r",
				["Hinterlands Honey Ripple"] = "1^|cffffffff|Hitem:8684:0:0:0:0:0:0:2047151080:70|h[Hinterlands Honey Ripple]|h|r",
				["Jump-a-tron 4000 Key"] = "1^|cff1eff00|Hitem:27808:0:0:0:0:0:0:1045349282:70|h[Jump-a-tron 4000 Key]|h|r",
				["Imbued Vial"] = "15^|cffffffff|Hitem:18256:0:0:0:0:0:0:0:70|h[Imbued Vial]|h|r",
				["Goblin Gumbo Kettle"] = "1^|cff0070dd|Hitem:33219:0:0:0:0:0:0:1636596216:70|h[Goblin Gumbo Kettle]|h|r",
				["Flamewrought Key"] = "1^|cffffffff|Hitem:30637:0:0:0:0:0:0:0:70|h[Flamewrought Key]|h|r",
				["Soft Bushy Tail"] = "2^|cffffffff|Hitem:4582:0:0:0:0:0:0:2104348420:70|h[Soft Bushy Tail]|h|r",
				["Rod of the Blazing Light"] = "1^|cffa335ee|Hitem:34608:0:3117:3287:3123:0:0:1946783266:70|h[Rod of the Blazing Light]|h|r",
				["Mantle of Absolution"] = "1^|cffa335ee|Hitem:31069:2980:3123:3123:0:0:0:0:70|h[Mantle of Absolution]|h|r",
				["Handguards of the Avatar"] = "1^|cffa335ee|Hitem:30160:2937:0:0:0:0:0:0:70|h[Handguards of the Avatar]|h|r",
				["Smokey's Special Compound"] = "1^|cffffffff|Hitem:15736:0:0:0:0:0:0:1929910776:70|h[Smokey's Special Compound]|h|r",
				["Robes of Heavenly Purpose"] = "1^|cffa335ee|Hitem:33203:1144:3141:3123:3123:0:0:790172758:70|h[Robes of Heavenly Purpose]|h|r",
				["Ethereum Prison Key"] = "4^|cff1eff00|Hitem:29460:0:0:0:0:0:0:1220652744:70|h[Ethereum Prison Key]|h|r",
				["Kreeg's Stout Beatdown"] = "4^|cff1eff00|Hitem:18284:0:0:0:0:0:0:0:70|h[Kreeg's Stout Beatdown]|h|r",
				["Frostwolf Insignia Rank 6"] = "1^|cffa335ee|Hitem:17909:0:0:0:0:0:0:359784856:70|h[Frostwolf Insignia Rank 6]|h|r",
				["Bolt of Runecloth"] = "5^|cffffffff|Hitem:14048:0:0:0:0:0:0:1781273152:70|h[Bolt of Runecloth]|h|r",
				["Crashin' Thrashin' Racer Controller"] = "1^|cff1eff00|Hitem:37710:0:0:0:0:0:0:842925434:70|h[Crashin' Thrashin' Racer Controller]|h|r",
				["Anathema"] = "1^|cffa335ee|Hitem:18609:2568:0:0:0:0:0:1195013914:70|h[Anathema]|h|r",
				["Frayed Abomination Stitching"] = "3^|cff1eff00|Hitem:12735:0:0:0:0:0:0:-2108906111:70|h[Frayed Abomination Stitching]|h|r",
				["Relic Coffer Key"] = "5^|cffffffff|Hitem:11078:0:0:0:0:0:0:2047988328:70|h[Relic Coffer Key]|h|r",
				["Purified Draenic Water"] = "20^|cffffffff|Hitem:27860:0:0:0:0:0:0:1585560207:70|h[Purified Draenic Water]|h|r",
				["Greater Eternal Essence"] = "1^|cff1eff00|Hitem:16203:0:0:0:0:0:0:1237112048:70|h[Greater Eternal Essence]|h|r",
				["Bolt of Netherweave"] = "17^|cffffffff|Hitem:21840:0:0:0:0:0:0:1618195250:70|h[Bolt of Netherweave]|h|r",
				["Elune Stone"] = "17^|cffffffff|Hitem:21536:0:0:0:0:0:0:1005143698:70|h[Elune Stone]|h|r",
				["Circle of Flame"] = "1^|cffa335ee|Hitem:11808:2543:0:0:0:0:0:1542303871:70|h[Circle of Flame]|h|r",
				["Sacred Candle"] = "18^|cffffffff|Hitem:17029:0:0:0:0:0:0:0:70|h[Sacred Candle]|h|r",
				["Illusion Dust"] = "3^|cffffffff|Hitem:16204:0:0:0:0:0:0:1237097624:70|h[Illusion Dust]|h|r",
				["Yeh'kinya's Bramble"] = "1^|cffffffff|Hitem:10699:0:0:0:0:0:0:382942987:70|h[Yeh'kinya's Bramble]|h|r",
			},
			["Version"] = 0.02,
			["DurPercent"] = 100,
			["LTime"] = 1244302282,
			["XPRest"] = 0,
			["Pos"] = "2025^57.739198^92.275161",
		},
		["海加尔.Frostbolt"] = {
			["XPMax"] = 12300,
			["NXLoggedOnNum"] = 1,
			["Pos"] = "1014^51.783550^67.030877",
			["LXPMax"] = 12300,
			["Class"] = "Mage",
			["LLevel"] = 14,
			["LArenaPts"] = 0,
			["XPRest"] = 18450,
			["XP"] = 3153,
			["Time"] = 1244257210,
			["LMoney"] = 951479,
			["TimePlayed"] = 0,
			["Level"] = 14,
			["Profs"] = {
			},
			["E"] = {
				["Info"] = {
					{
						["NXX"] = 65.5728816986084,
						["NXY"] = 67.34724640846252,
						["NXName"] = "Entered",
						["NXTime"] = 1241432671.000022,
						["T"] = "I",
						["NXMapId"] = 1013,
					}, -- [1]
					{
						["NXX"] = 63.9051616191864,
						["NXY"] = 13.34094256162643,
						["NXName"] = "Entered",
						["NXTime"] = 1241432713.000023,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [2]
					{
						["NXX"] = 64.31167125701904,
						["NXY"] = 0.01229691843036562,
						["NXName"] = "Entered",
						["NXTime"] = 1241432838.000024,
						["T"] = "I",
						["NXMapId"] = 1008,
					}, -- [3]
					{
						["NXX"] = 36.87223792076111,
						["NXY"] = 3.832003846764565,
						["NXName"] = "Entered",
						["NXTime"] = 1241432840.000025,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [4]
					{
						["NXX"] = 27.56437361240387,
						["NXY"] = 51.78577303886414,
						["NXName"] = "Entered",
						["NXTime"] = 1241434193.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [5]
					{
						["NXX"] = 27.56437361240387,
						["NXY"] = 51.78577303886414,
						["NXName"] = "Entered",
						["NXTime"] = 1241495154.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [6]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1241579017.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [7]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1241580431.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [8]
					{
						["NXX"] = 26.9699364900589,
						["NXY"] = 52.86968946456909,
						["NXName"] = "Entered",
						["NXTime"] = 1241915494.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [9]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1241922076.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [10]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1241923551.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [11]
					{
						["NXX"] = 26.82839632034302,
						["NXY"] = 52.6666522026062,
						["NXName"] = "Entered",
						["NXTime"] = 1241972384.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [12]
					{
						["NXX"] = 26.99407339096069,
						["NXY"] = 52.86130309104919,
						["NXName"] = "Entered",
						["NXTime"] = 1242178812.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [13]
					{
						["NXX"] = 26.95925831794739,
						["NXY"] = 52.87845134735107,
						["NXName"] = "Entered",
						["NXTime"] = 1242301683.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [14]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1242316618.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [15]
					{
						["NXX"] = 26.97896659374237,
						["NXY"] = 52.86948680877686,
						["NXName"] = "Entered",
						["NXTime"] = 1242319840.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [16]
					{
						["NXX"] = 26.97896659374237,
						["NXY"] = 52.86948680877686,
						["NXName"] = "Entered",
						["NXTime"] = 1242446983.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [17]
					{
						["NXX"] = 26.94662511348724,
						["NXY"] = 52.85140872001648,
						["NXName"] = "Entered",
						["NXTime"] = 1242595357.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [18]
					{
						["NXX"] = 26.94378793239594,
						["NXY"] = 52.81818509101868,
						["NXName"] = "Entered",
						["NXTime"] = 1242649947.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [19]
					{
						["NXX"] = 26.94698572158814,
						["NXY"] = 52.83241271972656,
						["NXName"] = "Entered",
						["NXTime"] = 1242650037.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [20]
					{
						["NXX"] = 26.96904242038727,
						["NXY"] = 52.86628007888794,
						["NXName"] = "Entered",
						["NXTime"] = 1242655211.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [21]
					{
						["NXX"] = 27.01797485351563,
						["NXY"] = 52.71645188331604,
						["NXName"] = "Entered",
						["NXTime"] = 1242655792.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [22]
					{
						["NXX"] = 26.95997059345245,
						["NXY"] = 52.88206934928894,
						["NXName"] = "Entered",
						["NXTime"] = 1242739224.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [23]
					{
						["NXX"] = 26.9685834646225,
						["NXY"] = 52.86603569984436,
						["NXName"] = "Entered",
						["NXTime"] = 1242739289.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [24]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1242739906.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [25]
					{
						["NXX"] = 27.07124650478363,
						["NXY"] = 52.79822945594788,
						["NXName"] = "Entered",
						["NXTime"] = 1242838544.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [26]
					{
						["NXX"] = 27.01844274997711,
						["NXY"] = 52.70881056785584,
						["NXName"] = "Entered",
						["NXTime"] = 1242953994.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [27]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1242997823.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [28]
					{
						["NXX"] = 26.97223424911499,
						["NXY"] = 52.84701585769653,
						["NXName"] = "Entered",
						["NXTime"] = 1243064655.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [29]
					{
						["NXX"] = 26.98250412940979,
						["NXY"] = 52.8407633304596,
						["NXName"] = "Entered",
						["NXTime"] = 1243077562.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [30]
					{
						["NXX"] = 26.96854770183563,
						["NXY"] = 52.89276242256165,
						["NXName"] = "Entered",
						["NXTime"] = 1243090580.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [31]
					{
						["NXX"] = 26.97214484214783,
						["NXY"] = 52.87952423095703,
						["NXName"] = "Entered",
						["NXTime"] = 1243092148.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [32]
					{
						["NXX"] = 26.97214484214783,
						["NXY"] = 52.87952423095703,
						["NXName"] = "Entered",
						["NXTime"] = 1243099859.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [33]
					{
						["NXX"] = 26.97226107120514,
						["NXY"] = 52.86794304847717,
						["NXName"] = "Entered",
						["NXTime"] = 1243175222.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [34]
					{
						["NXX"] = 26.97959244251251,
						["NXY"] = 52.82332897186279,
						["NXName"] = "Entered",
						["NXTime"] = 1243208288.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [35]
					{
						["NXX"] = 26.97433233261108,
						["NXY"] = 52.8489351272583,
						["NXName"] = "Entered",
						["NXTime"] = 1243233207.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [36]
					{
						["NXX"] = 26.94588601589203,
						["NXY"] = 52.80919671058655,
						["NXName"] = "Entered",
						["NXTime"] = 1243315215.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [37]
					{
						["NXX"] = 26.94866955280304,
						["NXY"] = 52.86367535591126,
						["NXName"] = "Entered",
						["NXTime"] = 1243344089.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [38]
					{
						["NXX"] = 26.96727514266968,
						["NXY"] = 52.87371277809143,
						["NXName"] = "Entered",
						["NXTime"] = 1243396811.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [39]
					{
						["NXX"] = 26.98921263217926,
						["NXY"] = 52.86039710044861,
						["NXName"] = "Entered",
						["NXTime"] = 1243472081.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [40]
					{
						["NXX"] = 26.97122395038605,
						["NXY"] = 52.86890864372253,
						["NXName"] = "Entered",
						["NXTime"] = 1243473084.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [41]
					{
						["NXX"] = 26.9679069519043,
						["NXY"] = 52.87737846374512,
						["NXName"] = "Entered",
						["NXTime"] = 1243473160.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [42]
					{
						["NXX"] = 26.96921825408936,
						["NXY"] = 52.88374423980713,
						["NXName"] = "Entered",
						["NXTime"] = 1243475513.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [43]
					{
						["NXX"] = 26.97550356388092,
						["NXY"] = 52.87349820137024,
						["NXName"] = "Entered",
						["NXTime"] = 1243478627.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [44]
					{
						["NXX"] = 26.94766819477081,
						["NXY"] = 52.82809734344482,
						["NXName"] = "Entered",
						["NXTime"] = 1243478806.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [45]
					{
						["NXX"] = 26.94997191429138,
						["NXY"] = 52.87134051322937,
						["NXName"] = "Entered",
						["NXTime"] = 1243479306.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [46]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1243513376.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [47]
					{
						["NXX"] = 26.96700096130371,
						["NXY"] = 52.87004113197327,
						["NXName"] = "Entered",
						["NXTime"] = 1243689605.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [48]
					{
						["NXX"] = 14.97759521007538,
						["NXY"] = 60.93451380729675,
						["NXName"] = "Entered",
						["NXTime"] = 1243689996.000002,
						["T"] = "I",
						["NXMapId"] = 1008,
					}, -- [49]
					{
						["NXX"] = 36.42011284828186,
						["NXY"] = 3.094124048948288,
						["NXName"] = "Entered",
						["NXTime"] = 1243689997.000003,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [50]
					{
						["NXX"] = 14.62433487176895,
						["NXY"] = 62.02383637428284,
						["NXName"] = "Entered",
						["NXTime"] = 1243689997.000004,
						["T"] = "I",
						["NXMapId"] = 1008,
					}, -- [51]
					{
						["NXX"] = 36.33030354976654,
						["NXY"] = 3.424278274178505,
						["NXName"] = "Entered",
						["NXTime"] = 1243689997.000005,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [52]
					{
						["NXX"] = 13.81431818008423,
						["NXY"] = 66.30903482437134,
						["NXName"] = "Entered",
						["NXTime"] = 1243689998.000006,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [53]
					{
						["NXX"] = 49.88902807235718,
						["NXY"] = 27.99022495746613,
						["NXName"] = "+192 xp",
						["NXTime"] = 1243690172.000008,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [54]
					{
						["NXX"] = 52.42947340011597,
						["NXY"] = 28.54226529598236,
						["NXName"] = "+164 xp",
						["NXTime"] = 1243690477.00001,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [55]
					{
						["NXX"] = 52.78549790382385,
						["NXY"] = 28.71940732002258,
						["NXName"] = "+164 xp",
						["NXTime"] = 1243690516.000012,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [56]
					{
						["NXX"] = 53.12687754631043,
						["NXY"] = 29.25300598144531,
						["NXName"] = "+192 xp",
						["NXTime"] = 1243690544.000014,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [57]
					{
						["NXX"] = 53.45209240913391,
						["NXY"] = 28.91982793807983,
						["NXName"] = "+164 xp",
						["NXTime"] = 1243690581.000016,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [58]
					{
						["NXX"] = 53.61304879188538,
						["NXY"] = 29.06815409660339,
						["NXName"] = "+164 xp",
						["NXTime"] = 1243690596.000018,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [59]
					{
						["NXX"] = 53.68344187736511,
						["NXY"] = 29.01986837387085,
						["NXName"] = "+164 xp",
						["NXTime"] = 1243690638.00002,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [60]
					{
						["NXX"] = 53.87207865715027,
						["NXY"] = 29.34460043907166,
						["NXName"] = "+192 xp",
						["NXTime"] = 1243690674.000022,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [61]
					{
						["NXX"] = 54.01254296302795,
						["NXY"] = 29.39441204071045,
						["NXName"] = "+192 xp",
						["NXTime"] = 1243690719.000024,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [62]
					{
						["NXX"] = 54.0016233921051,
						["NXY"] = 30.08051216602325,
						["NXName"] = "+192 xp",
						["NXTime"] = 1243690748.000026,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [63]
					{
						["NXX"] = 54.34844493865967,
						["NXY"] = 30.15480041503906,
						["NXName"] = "+192 xp",
						["NXTime"] = 1243690776.000028,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [64]
					{
						["NXX"] = 54.44149374961853,
						["NXY"] = 30.33754527568817,
						["NXName"] = "+220 xp",
						["NXTime"] = 1243690806.00003,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [65]
					{
						["NXX"] = 54.46766018867493,
						["NXY"] = 30.23181557655335,
						["NXName"] = "+164 xp",
						["NXTime"] = 1243690831.000032,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [66]
					{
						["NXX"] = 54.46766018867493,
						["NXY"] = 30.23181557655335,
						["NXName"] = "Level 14",
						["NXTime"] = 1243690831.000033,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [67]
					{
						["NXX"] = 54.46244478225708,
						["NXY"] = 30.05459606647492,
						["NXName"] = "+144 xp",
						["NXTime"] = 1243690873.000035,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [68]
					{
						["NXX"] = 54.57749962806702,
						["NXY"] = 30.15874326229096,
						["NXName"] = "+172 xp",
						["NXTime"] = 1243690908.000037,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [69]
					{
						["NXX"] = 54.3286919593811,
						["NXY"] = 30.86199760437012,
						["NXName"] = "+144 xp",
						["NXTime"] = 1243690937.000039,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [70]
					{
						["NXX"] = 54.61586713790894,
						["NXY"] = 31.52717053890228,
						["NXName"] = "+144 xp",
						["NXTime"] = 1243690967.000041,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [71]
					{
						["NXX"] = 55.07083535194397,
						["NXY"] = 32.08419382572174,
						["NXName"] = "+144 xp",
						["NXTime"] = 1243691020.000043,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [72]
					{
						["NXX"] = 54.04369235038757,
						["NXY"] = 31.75747096538544,
						["NXName"] = "+172 xp",
						["NXTime"] = 1243691083.000046,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [73]
					{
						["NXX"] = 53.73690128326416,
						["NXY"] = 32.06948935985565,
						["NXName"] = "+144 xp",
						["NXTime"] = 1243691109.000048,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [74]
					{
						["NXX"] = 53.54998111724854,
						["NXY"] = 32.46693909168243,
						["NXName"] = "+144 xp",
						["NXTime"] = 1243691150.00005,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [75]
					{
						["NXX"] = 53.51488590240479,
						["NXY"] = 33.3634227514267,
						["NXName"] = "+172 xp",
						["NXTime"] = 1243691197.000052,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [76]
					{
						["NXX"] = 53.55184674263001,
						["NXY"] = 33.16377103328705,
						["NXName"] = "+202 xp",
						["NXTime"] = 1243691231.000054,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [77]
					{
						["NXX"] = 53.69102358818054,
						["NXY"] = 32.49989449977875,
						["NXName"] = "+230 xp",
						["NXTime"] = 1243691265.000056,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [78]
					{
						["NXX"] = 53.52212190628052,
						["NXY"] = 31.5312534570694,
						["NXName"] = "+144 xp",
						["NXTime"] = 1243691324.000058,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [79]
					{
						["NXX"] = 53.31589579582214,
						["NXY"] = 30.99631667137146,
						["NXName"] = "+144 xp",
						["NXTime"] = 1243691346.00006,
						["T"] = "I",
						["NXMapId"] = 1019,
					}, -- [80]
					{
						["NXX"] = 63.80835771560669,
						["NXY"] = 0.001700176289887168,
						["NXName"] = "Entered",
						["NXTime"] = 1243691489.000061,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [81]
					{
						["NXX"] = 27.09508538246155,
						["NXY"] = 52.68039703369141,
						["NXName"] = "Entered",
						["NXTime"] = 1243768038.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [82]
					{
						["NXX"] = 26.64792835712433,
						["NXY"] = 52.9865026473999,
						["NXName"] = "Entered",
						["NXTime"] = 1243786049.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [83]
					{
						["NXX"] = 26.97423696517944,
						["NXY"] = 52.85542607307434,
						["NXName"] = "Entered",
						["NXTime"] = 1243813797.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [84]
					{
						["NXX"] = 26.97423696517944,
						["NXY"] = 52.85542607307434,
						["NXName"] = "Entered",
						["NXTime"] = 1243837382.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [85]
					{
						["NXX"] = 26.96430683135986,
						["NXY"] = 52.87733674049377,
						["NXName"] = "Entered",
						["NXTime"] = 1243852378.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [86]
					{
						["NXX"] = 26.97087824344635,
						["NXY"] = 52.86656022071838,
						["NXName"] = "Entered",
						["NXTime"] = 1243918493.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [87]
					{
						["NXX"] = 27.02397704124451,
						["NXY"] = 52.72820591926575,
						["NXName"] = "Entered",
						["NXTime"] = 1243982740.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [88]
					{
						["NXX"] = 26.96123123168945,
						["NXY"] = 52.86266803741455,
						["NXName"] = "Entered",
						["NXTime"] = 1243983680.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [89]
					{
						["NXX"] = 26.96897685527802,
						["NXY"] = 52.86895036697388,
						["NXName"] = "Entered",
						["NXTime"] = 1243999383.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [90]
					{
						["NXX"] = 26.99629068374634,
						["NXY"] = 52.80990600585938,
						["NXName"] = "Entered",
						["NXTime"] = 1244005413.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [91]
					{
						["NXX"] = 27.07543969154358,
						["NXY"] = 52.6790201663971,
						["NXName"] = "Entered",
						["NXTime"] = 1244022571.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [92]
					{
						["NXX"] = 27.44714319705963,
						["NXY"] = 51.93887948989868,
						["NXName"] = "Entered",
						["NXTime"] = 1244070692.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [93]
					{
						["NXX"] = 26.97282731533051,
						["NXY"] = 52.84799933433533,
						["NXName"] = "Entered",
						["NXTime"] = 1244076538.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [94]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1244115972.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [95]
					{
						["NXX"] = 27.0063728094101,
						["NXY"] = 52.7587890625,
						["NXName"] = "Entered",
						["NXTime"] = 1244126268.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [96]
					{
						["NXX"] = 27.0063728094101,
						["NXY"] = 52.7587890625,
						["NXName"] = "Entered",
						["NXTime"] = 1244161774.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [97]
					{
						["NXX"] = 26.97232067584992,
						["NXY"] = 52.84894704818726,
						["NXName"] = "Entered",
						["NXTime"] = 1244207736.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [98]
					{
						["NXX"] = 26.97242498397827,
						["NXY"] = 52.86448001861572,
						["NXName"] = "Entered",
						["NXTime"] = 1244255907.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [99]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1244256259.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [100]
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1244256553.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [101]
				},
				["Death"] = {
					{
						["NXX"] = 52.8301477432251,
						["NXY"] = 10.9816312789917,
						["NXName"] = "Venture Co. Peon",
						["NXTime"] = 1241431095.000005,
						["T"] = "D",
						["NXMapId"] = 1019,
					}, -- [1]
				},
				["Kill"] = {
					{
						["NXX"] = 61.56072616577148,
						["NXY"] = 8.028791099786758,
						["NXKills"] = 1,
						["NXName"] = "Savannah Prowler",
						["NXTime"] = 1241430891.000003,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [1]
					{
						["NXX"] = 51.36449933052063,
						["NXY"] = 28.33382189273834,
						["NXKills"] = 1,
						["NXName"] = "Greater Plainstrider",
						["NXTime"] = 1241431491.000006,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [2]
					{
						["NXX"] = 51.73682570457459,
						["NXY"] = 27.95514166355133,
						["NXKills"] = 2,
						["NXName"] = "Greater Plainstrider",
						["NXTime"] = 1241431512.000008,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [3]
					{
						["NXX"] = 51.80805921554565,
						["NXY"] = 27.03224122524262,
						["NXKills"] = 1,
						["NXName"] = "Savannah Huntress",
						["NXTime"] = 1241431538.00001,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [4]
					{
						["NXX"] = 48.45369756221771,
						["NXY"] = 11.0165148973465,
						["NXKills"] = 1,
						["NXName"] = "Sunscale Scytheclaw",
						["NXTime"] = 1241431755.000012,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [5]
					{
						["NXX"] = 48.36994409561157,
						["NXY"] = 13.68281543254852,
						["NXKills"] = 1,
						["NXName"] = "Elder Mottled Boar",
						["NXTime"] = 1241432329.000018,
						["T"] = "K",
						["NXMapId"] = 1008,
					}, -- [6]
					{
						["NXX"] = 52.76021361351013,
						["NXY"] = 69.68050003051758,
						["NXKills"] = 1,
						["NXName"] = "Gamon",
						["NXTime"] = 1242739341.000002,
						["T"] = "K",
						["NXMapId"] = 1014,
					}, -- [7]
					{
						["NXX"] = 53.40403318405151,
						["NXY"] = 69.8327898979187,
						["NXKills"] = 2,
						["NXName"] = "Gamon",
						["NXTime"] = 1242838850.000002,
						["T"] = "K",
						["NXMapId"] = 1014,
					}, -- [8]
					{
						["NXX"] = 49.88902807235718,
						["NXY"] = 27.99022495746613,
						["NXKills"] = 2,
						["NXName"] = "Savannah Huntress",
						["NXTime"] = 1243690172.000007,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [9]
					{
						["NXX"] = 52.42947340011597,
						["NXY"] = 28.54226529598236,
						["NXKills"] = 3,
						["NXName"] = "Greater Plainstrider",
						["NXTime"] = 1243690477.000009,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [10]
					{
						["NXX"] = 52.7783989906311,
						["NXY"] = 28.74560654163361,
						["NXKills"] = 4,
						["NXName"] = "Greater Plainstrider",
						["NXTime"] = 1243690515.000011,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [11]
					{
						["NXX"] = 53.12687754631043,
						["NXY"] = 29.25300598144531,
						["NXKills"] = 5,
						["NXName"] = "Greater Plainstrider",
						["NXTime"] = 1243690544.000013,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [12]
					{
						["NXX"] = 53.45209240913391,
						["NXY"] = 28.91982793807983,
						["NXKills"] = 1,
						["NXName"] = "Sunscale Lashtail",
						["NXTime"] = 1243690581.000015,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [13]
					{
						["NXX"] = 53.62639427185059,
						["NXY"] = 29.06511425971985,
						["NXKills"] = 6,
						["NXName"] = "Greater Plainstrider",
						["NXTime"] = 1243690596.000017,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [14]
					{
						["NXX"] = 53.69482636451721,
						["NXY"] = 29.00524437427521,
						["NXKills"] = 7,
						["NXName"] = "Greater Plainstrider",
						["NXTime"] = 1243690638.000019,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [15]
					{
						["NXX"] = 53.86863350868225,
						["NXY"] = 29.33082580566406,
						["NXKills"] = 3,
						["NXName"] = "Savannah Huntress",
						["NXTime"] = 1243690674.000021,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [16]
					{
						["NXX"] = 54.01254296302795,
						["NXY"] = 29.39441204071045,
						["NXKills"] = 4,
						["NXName"] = "Savannah Huntress",
						["NXTime"] = 1243690718.000023,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [17]
					{
						["NXX"] = 54.0016233921051,
						["NXY"] = 30.08051216602325,
						["NXKills"] = 5,
						["NXName"] = "Savannah Huntress",
						["NXTime"] = 1243690748.000025,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [18]
					{
						["NXX"] = 54.34844493865967,
						["NXY"] = 30.15480041503906,
						["NXKills"] = 6,
						["NXName"] = "Savannah Huntress",
						["NXTime"] = 1243690776.000027,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [19]
					{
						["NXX"] = 54.44149374961853,
						["NXY"] = 30.33754527568817,
						["NXKills"] = 1,
						["NXName"] = "Savannah Highmane",
						["NXTime"] = 1243690805.000029,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [20]
					{
						["NXX"] = 54.46766018867493,
						["NXY"] = 30.23181557655335,
						["NXKills"] = 7,
						["NXName"] = "Savannah Huntress",
						["NXTime"] = 1243690830.000031,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [21]
					{
						["NXX"] = 54.46244478225708,
						["NXY"] = 30.05459606647492,
						["NXKills"] = 8,
						["NXName"] = "Savannah Huntress",
						["NXTime"] = 1243690873.000034,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [22]
					{
						["NXX"] = 54.57749962806702,
						["NXY"] = 30.15874326229096,
						["NXKills"] = 9,
						["NXName"] = "Savannah Huntress",
						["NXTime"] = 1243690908.000036,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [23]
					{
						["NXX"] = 54.32776212692261,
						["NXY"] = 30.86405396461487,
						["NXKills"] = 10,
						["NXName"] = "Savannah Huntress",
						["NXTime"] = 1243690937.000038,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [24]
					{
						["NXX"] = 54.61586713790894,
						["NXY"] = 31.52717053890228,
						["NXKills"] = 8,
						["NXName"] = "Greater Plainstrider",
						["NXTime"] = 1243690967.00004,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [25]
					{
						["NXX"] = 55.07083535194397,
						["NXY"] = 32.08419382572174,
						["NXKills"] = 11,
						["NXName"] = "Savannah Huntress",
						["NXTime"] = 1243691020.000042,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [26]
					{
						["NXX"] = 54.41440939903259,
						["NXY"] = 32.02066719532013,
						["NXKills"] = 1,
						["NXName"] = "Sickly Gazelle",
						["NXTime"] = 1243691053.000044,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [27]
					{
						["NXX"] = 54.04369235038757,
						["NXY"] = 31.75747096538544,
						["NXKills"] = 9,
						["NXName"] = "Greater Plainstrider",
						["NXTime"] = 1243691083.000045,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [28]
					{
						["NXX"] = 53.73690128326416,
						["NXY"] = 32.06948935985565,
						["NXKills"] = 10,
						["NXName"] = "Greater Plainstrider",
						["NXTime"] = 1243691109.000047,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [29]
					{
						["NXX"] = 53.54998111724854,
						["NXY"] = 32.46693909168243,
						["NXKills"] = 11,
						["NXName"] = "Greater Plainstrider",
						["NXTime"] = 1243691149.000049,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [30]
					{
						["NXX"] = 53.51488590240479,
						["NXY"] = 33.3634227514267,
						["NXKills"] = 12,
						["NXName"] = "Greater Plainstrider",
						["NXTime"] = 1243691196.000051,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [31]
					{
						["NXX"] = 53.57519388198853,
						["NXY"] = 33.18187892436981,
						["NXKills"] = 1,
						["NXName"] = "Fleeting Plainstrider",
						["NXTime"] = 1243691230.000053,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [32]
					{
						["NXX"] = 53.69102358818054,
						["NXY"] = 32.49989449977875,
						["NXKills"] = 1,
						["NXName"] = "Zhevra Runner",
						["NXTime"] = 1243691265.000055,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [33]
					{
						["NXX"] = 53.52452993392944,
						["NXY"] = 31.53164684772492,
						["NXKills"] = 13,
						["NXName"] = "Greater Plainstrider",
						["NXTime"] = 1243691324.000057,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [34]
					{
						["NXX"] = 53.31589579582214,
						["NXY"] = 30.99631667137146,
						["NXKills"] = 14,
						["NXName"] = "Greater Plainstrider",
						["NXTime"] = 1243691346.000059,
						["T"] = "K",
						["NXMapId"] = 1019,
					}, -- [35]
					{
						["NXX"] = 53.53893041610718,
						["NXY"] = 71.58713340759277,
						["NXKills"] = 3,
						["NXName"] = "Gamon",
						["NXTime"] = 1243918553.000002,
						["T"] = "K",
						["NXMapId"] = 1014,
					}, -- [36]
				},
				["Mine"] = {
				},
				["Herb"] = {
				},
			},
			["Q"] = {
				[894] = "c0",
				[1882] = "W0",
				[895] = "W0",
				[911] = "C1241431946",
				[896] = "W0",
				[866] = "W0",
				[371] = "W0",
				[867] = "W0",
				[887] = "W0",
				[899] = "W0",
				[915] = "C1241432948",
				[869] = "W0",
				[357] = "W0",
				[870] = "c0",
				[5502] = "C1241433077",
				[871] = "W0",
				[4921] = "W0",
				[925] = "C1241432630",
				[910] = "C1241431231",
				[1800] = "C1241432078",
				[359] = "c0",
				[172] = "C1241430430",
				[375] = "W0",
				[445] = "c0",
				[891] = "W0",
				[845] = "W0",
				[844] = "C1243691364",
				[848] = "W0",
				[865] = "c0",
				[369] = "W0",
				[5041] = "W0",
			},
			["ArenaPts"] = 0,
			["LTime"] = 1244256553,
			["Honor"] = 0,
			["Money"] = 951479,
			["LXP"] = 3153,
			["W"] = {
				["NxHUD"] = {
					["_W"] = 8,
					["FI"] = 1,
					["FO"] = 0.15,
					["W"] = 8,
					["Y"] = 203.9999839901927,
					["H"] = 40,
					["Hide"] = true,
					["_H"] = 40,
					["X"] = 795.9999880790713,
					["_X"] = 999999,
					["_Y"] = -0.17,
					["Lk"] = true,
				},
				["NxMapDock"] = {
					["A"] = "TOPRIGHT",
					["_W"] = 52,
					["S"] = 1,
					["FI"] = 1,
					["FO"] = 0,
					["W"] = 47.99997735023532,
					["Y"] = 195.6094521938346,
					["H"] = 40,
					["X"] = -6.249904539437525,
					["_H"] = 69,
					["_L"] = 2,
					["L"] = 2,
					["_Y"] = -0.08,
					["_X"] = 100045,
				},
				["NxQuestList"] = {
					["A"] = "CENTER",
					["FI"] = 1,
					["FO"] = 0.75,
					["MaxY"] = 119.9999886751177,
					["H"] = 625.3127958578945,
					["_H"] = -0.65,
					["MaxA"] = "TOPLEFT",
					["Hide"] = true,
					["MaxS"] = 1,
					["_W"] = -0.52,
					["S"] = 1,
					["MaxX"] = 159.9999976158142,
					["W"] = 907.4992235377547,
					["Y"] = 27.42230851318973,
					["X"] = -36.00061124562306,
					["MaxH"] = 959.9999094009413,
					["MaxL"] = 2,
					["_Y"] = -0.15,
					["MaxW"] = 1279.999980926514,
					["_X"] = -0.24,
				},
				["NxTeamHUD"] = {
					["_W"] = 107,
					["FI"] = 0.5,
					["FO"] = 0,
					["W"] = 107,
					["Y"] = 359.9999717473988,
					["H"] = 40,
					["_H"] = 40,
					["Hide"] = true,
					["X"] = 959.9999856948855,
					["_Y"] = -0.3,
					["_X"] = -0.6,
				},
				["NxDD"] = {
					["A"] = "CENTER",
					["_W"] = 207,
					["S"] = 1,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = 207.0000236183402,
					["Y"] = 83.95308369468027,
					["X"] = -261.4999350681911,
					["_X"] = 0,
					["_H"] = 209,
					["H"] = 208.9999930709602,
					["L"] = 4,
					["_Y"] = 0,
					["Hide"] = true,
				},
				["NxFav"] = {
					["A"] = "CENTER",
					["_W"] = -0.54,
					["S"] = 1,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = 864.00007867813,
					["Y"] = 46.87506129033772,
					["X"] = -1.249968986958727,
					["_H"] = -0.5,
					["_X"] = -0.23,
					["H"] = 599.9999529123313,
					["_Y"] = -0.25,
					["Hide"] = true,
				},
				["NxSocial"] = {
					["_W"] = -0.5,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = 799.9999880790713,
					["Y"] = 215.9999830484393,
					["X"] = 399.9999940395356,
					["_H"] = -0.64,
					["Hide"] = true,
					["H"] = 767.9999397277841,
					["_Y"] = -0.18,
					["_X"] = -0.25,
				},
				["NxMap1"] = {
					["9002L"] = 1,
					["FI"] = 1,
					["FO"] = 0,
					["9001Y"] = 29.06230883207457,
					["MaxY"] = 38.67214860510605,
					["9003H"] = 40,
					["_H"] = -0.3,
					["_L"] = 1,
					["9004A"] = "BOTTOMRIGHT",
					["9003Y"] = 30.15601113206132,
					["MaxL"] = 2,
					["9004W"] = 100.000027120113,
					["9002A"] = "BOTTOMRIGHT",
					["9002X"] = 71.40982044622569,
					["9008H"] = -0.3,
					["9001H"] = 40,
					["MaxX"] = 4.375457698472475,
					["9003S"] = 1,
					["9002H"] = 44.68750887084739,
					["9002W"] = 100.000027120113,
					["9001A"] = "BOTTOMRIGHT",
					["MaxH"] = 784.2186620202861,
					["X"] = 38.85126055998712,
					["9004S"] = 1,
					["MaxW"] = 1096.249983664602,
					["9008Y"] = -0.4,
					["9004L"] = 1,
					["A"] = "BOTTOMRIGHT",
					["_X"] = -0.0001,
					["9002S"] = 1,
					["9001W"] = 100.000027120113,
					["9002T"] = 0.01,
					["9004Y"] = 31.40613509109415,
					["9002Y"] = 34.84365411335745,
					["9003A"] = "BOTTOMRIGHT",
					["9004H"] = 40,
					["9008W"] = -0.19,
					["9003L"] = 1,
					["9003X"] = 83.90891903774561,
					["9003T"] = 0.01,
					["L"] = 1,
					["MaxA"] = "CENTER",
					["9001L"] = 1,
					["MaxS"] = 1,
					["_W"] = -0.19,
					["S"] = 1,
					["9003W"] = 99.99999850988391,
					["H"] = 40.00000894069658,
					["T"] = 0.01,
					["W"] = 100.000027120113,
					["9008X"] = -0.0001,
					["Y"] = 9.69991490692027,
					["9001T"] = 0.01,
					["9004T"] = 0.01,
					["9001S"] = 1,
					["9004X"] = 67.6599730899934,
					["9001X"] = 60.40978341684068,
					["_Y"] = -0.4,
					["9008L"] = 1,
				},
				["NxHelp"] = {
					["_W"] = -0.5,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = 799.9999880790713,
					["Y"] = 119.9999905824663,
					["X"] = 399.9999940395356,
					["_H"] = -0.7,
					["H"] = 839.9999340772638,
					["_Y"] = -0.1,
					["_X"] = -0.25,
				},
				["NxGuide1"] = {
					["A"] = "CENTER",
					["_W"] = -0.45,
					["S"] = 1,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = 719.9999892711641,
					["Y"] = 106.8751796055558,
					["H"] = 539.999953806401,
					["_H"] = -0.45,
					["_X"] = -0.2,
					["X"] = -61.24997047707483,
					["_Y"] = -0.2,
					["Hide"] = true,
				},
				["Version"] = 0.31,
				["NxCombat"] = {
					["_W"] = -0.3,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = 479.9999928474427,
					["Y"] = 839.9999340772638,
					["H"] = 71.99999434947975,
					["_H"] = -0.06,
					["Hide"] = true,
					["X"] = 1119.9999833107,
					["_Y"] = -0.7,
					["_X"] = -0.7,
				},
				["NxPunkHUD"] = {
					["A"] = "LEFT",
					["_W"] = 135,
					["S"] = 1,
					["FI"] = 0.5,
					["FO"] = 0,
					["W"] = 133.9999941885472,
					["Y"] = -44.95316915283845,
					["X"] = 116.2500745616842,
					["_H"] = 87,
					["Hide"] = true,
					["H"] = 40,
					["_Y"] = -0.1,
					["_X"] = -0.6,
				},
				["NxOpts"] = {
					["A"] = "CENTER",
					["FI"] = 1,
					["FO"] = 0.75,
					["MaxY"] = 119.9999886751177,
					["H"] = 728.6718641419431,
					["_H"] = -0.7,
					["MaxA"] = "TOPLEFT",
					["MaxL"] = 2,
					["MaxS"] = 1,
					["_W"] = -0.5,
					["S"] = 1,
					["MaxX"] = 159.9999976158142,
					["W"] = 917.5001389160732,
					["Y"] = 102.3045524611391,
					["X"] = -16.24971603975123,
					["MaxH"] = 959.9999094009413,
					["Hide"] = true,
					["MaxW"] = 1279.999980926514,
					["_Y"] = -0.1,
					["_X"] = -0.25,
				},
				["NxEventsList"] = {
					["_W"] = -0.25,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = 399.9999940395356,
					["Y"] = 719.9999434947976,
					["H"] = 119.9999905824663,
					["_H"] = -0.1,
					["Hide"] = true,
					["X"] = 1199.999982118607,
					["_Y"] = -0.6,
					["_X"] = -0.75,
				},
				["NxQuestWatch"] = {
					["A"] = "RIGHT",
					["MinW"] = 124.9999981373549,
					["FI"] = 0.4993750042161195,
					["FO"] = 0,
					["MinX"] = -129.7507362104843,
					["HideC"] = true,
					["H"] = 214.6099821536246,
					["_H"] = -0.1,
					["MinY"] = 248.6955033437088,
					["MinH"] = 40,
					["_W"] = -0.2,
					["S"] = 1,
					["W"] = 288.9995531886883,
					["Y"] = -179.3354198435631,
					["X"] = -91.00091798602166,
					["MinT"] = 0.05454952521682632,
					["MinS"] = 1,
					["MinA"] = "TOPRIGHT",
					["L"] = 2,
					["_Y"] = -0.35,
					["_X"] = -0.8,
				},
			},
			["L"] = {
				["Events"] = {
				},
				["Version"] = 0.1,
				["FavI"] = {
				},
				["Social"] = {
				},
				["Quest"] = {
				},
				["FavF"] = {
				},
			},
			["LXPRest"] = 18450,
			["LHonor"] = 0,
			["Version"] = 0.02,
			["DurPercent"] = 98.18181818181819,
			["DurLowPercent"] = 93.33333333333333,
			["TBar"] = {
				["Version"] = 0.1,
				["NxMap1TB"] = {
					["Space"] = 1,
					["AlignR"] = true,
					["AlignB"] = true,
					["Size"] = 18.37994612595363,
				},
			},
			["LvlTime"] = 1244256553,
			["Opts"] = {
				["MapShowGatherH"] = false,
				["QMapShowQuestGivers3"] = 3,
				["MapShowGatherM"] = false,
			},
		},
		["艾萨拉.Salama"] = {
			["Q"] = {
			},
			["NXLoggedOnNum"] = 1,
			["E"] = {
				["Info"] = {
				},
				["Death"] = {
				},
				["Kill"] = {
				},
				["Mine"] = {
				},
				["Herb"] = {
				},
			},
			["W"] = {
				["NxHUD"] = {
					["_W"] = 8,
					["FI"] = 1,
					["FO"] = 0.15,
					["W"] = 8,
					["Y"] = -0.17,
					["X"] = 999999,
					["_H"] = 40,
					["H"] = 40,
					["_Y"] = -0.17,
					["_X"] = 999999,
				},
				["NxQuestList"] = {
					["_W"] = -0.52,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = -0.52,
					["Y"] = -0.15,
					["X"] = -0.24,
					["_H"] = -0.65,
					["H"] = -0.65,
					["_Y"] = -0.15,
					["_X"] = -0.24,
				},
				["NxDD"] = {
					["_W"] = 207,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = 207,
					["Y"] = 0,
					["X"] = 0,
					["_H"] = 209,
					["_X"] = 0,
					["H"] = 209,
					["_Y"] = 0,
					["Hide"] = true,
				},
				["NxQuestWatch"] = {
					["_W"] = -0.2,
					["FI"] = 1,
					["FO"] = 0.15,
					["W"] = -0.2,
					["Y"] = -0.35,
					["X"] = -0.8,
					["_H"] = -0.1,
					["H"] = -0.1,
					["_Y"] = -0.35,
					["_X"] = -0.8,
				},
				["NxMapDock"] = {
					["_W"] = 52,
					["FI"] = 1,
					["FO"] = 0,
					["W"] = 52,
					["Y"] = -0.08,
					["X"] = 100045,
					["H"] = 69,
					["_H"] = 69,
					["_L"] = 2,
					["L"] = 2,
					["_Y"] = -0.08,
					["_X"] = 100045,
				},
				["NxGuide1"] = {
					["_W"] = -0.45,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = -0.45,
					["Y"] = -0.2,
					["X"] = -0.2,
					["_H"] = -0.45,
					["Hide"] = true,
					["H"] = -0.45,
					["_Y"] = -0.2,
					["_X"] = -0.2,
				},
				["Version"] = 0.31,
				["NxMap1"] = {
					["9002L"] = 1,
					["FI"] = 1,
					["FO"] = 0,
					["9001Y"] = -0.4,
					["9003H"] = -0.3,
					["_H"] = -0.3,
					["_L"] = 1,
					["9003Y"] = -0.4,
					["9008H"] = -0.3,
					["9002X"] = -0.0001,
					["9001H"] = -0.3,
					["9002H"] = -0.3,
					["9002W"] = -0.19,
					["9008Y"] = -0.4,
					["_X"] = -0.0001,
					["9002Y"] = -0.4,
					["9003W"] = -0.19,
					["H"] = 230.3999828338625,
					["9003L"] = 1,
					["9003X"] = -0.0001,
					["L"] = 1,
					["9001L"] = 1,
					["_W"] = -0.19,
					["9008L"] = 1,
					["9008W"] = -0.19,
					["9004H"] = -0.3,
					["9004L"] = 1,
					["W"] = 194.56,
					["9008X"] = -0.0001,
					["Y"] = 307.1999771118167,
					["X"] = 0.1024,
					["9004Y"] = -0.4,
					["9004W"] = -0.19,
					["9004X"] = -0.0001,
					["9001X"] = -0.0001,
					["_Y"] = -0.4,
					["9001W"] = -0.19,
				},
				["NxPunkHUD"] = {
					["_W"] = 135,
					["FI"] = 0.5,
					["FO"] = 0,
					["W"] = 135,
					["Y"] = -0.1,
					["X"] = -0.6,
					["_H"] = 87,
					["H"] = 87,
					["_Y"] = -0.1,
					["_X"] = -0.6,
				},
				["NxEventsList"] = {
					["_W"] = -0.25,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = -0.25,
					["Y"] = -0.6,
					["X"] = -0.75,
					["_H"] = -0.1,
					["_X"] = -0.75,
					["H"] = -0.1,
					["_Y"] = -0.6,
					["Hide"] = true,
				},
				["NxCombat"] = {
					["_W"] = -0.3,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = -0.3,
					["Y"] = -0.7,
					["X"] = -0.7,
					["_H"] = -0.06,
					["_X"] = -0.7,
					["H"] = -0.06,
					["_Y"] = -0.7,
					["Hide"] = true,
				},
				["NxTeamHUD"] = {
					["_W"] = 107,
					["FI"] = 0.5,
					["FO"] = 0,
					["W"] = 107,
					["Y"] = -0.3,
					["X"] = -0.6,
					["_H"] = 40,
					["_X"] = -0.6,
					["H"] = 40,
					["_Y"] = -0.3,
					["Hide"] = true,
				},
			},
			["TBar"] = {
				["Version"] = 0.1,
				["NxMap1TB"] = {
					["Space"] = 1,
					["AlignR"] = true,
					["AlignB"] = true,
					["Size"] = 22,
				},
			},
			["Version"] = 0.02,
			["TimePlayed"] = 0,
			["L"] = {
				["Version"] = 0.1,
				["Events"] = {
				},
				["Quest"] = {
				},
			},
			["Profs"] = {
			},
			["Opts"] = {
				["MapShowGatherH"] = false,
				["QMapShowQuestGivers3"] = 1,
				["MapShowGatherM"] = false,
			},
		},
		["屠魔山谷.缠云格格"] = {
			["XPMax"] = 66200,
			["NXLoggedOnNum"] = 1,
			["E"] = {
				["Info"] = {
					{
						["NXX"] = 26.94458961486816,
						["NXY"] = 52.85540819168091,
						["NXName"] = "Entered",
						["NXTime"] = 1240709745.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [1]
					{
						["NXX"] = 26.98395252227783,
						["NXY"] = 52.83988118171692,
						["NXName"] = "Entered",
						["NXTime"] = 1242371759.000001,
						["T"] = "I",
						["NXMapId"] = 1014,
					}, -- [2]
				},
				["Death"] = {
				},
				["Kill"] = {
				},
				["Mine"] = {
				},
				["Herb"] = {
				},
			},
			["Class"] = "Rogue",
			["LLevel"] = 38,
			["LArenaPts"] = 0,
			["Pos"] = "1014^51.208442^70.179528",
			["TBar"] = {
				["Version"] = 0.1,
				["NxMap1TB"] = {
					["Space"] = 1,
					["AlignR"] = true,
					["AlignB"] = true,
					["Size"] = 22,
				},
			},
			["LMoney"] = 579495,
			["TimePlayed"] = 0,
			["Level"] = 38,
			["Profs"] = {
			},
			["XPRest"] = 99300,
			["Q"] = {
				[11339] = "W0",
				[1106] = "W0",
				[2932] = "W0",
				[9457] = "W0",
				[572] = "W0",
				[629] = "W0",
				[1164] = "W0",
				[638] = "W0",
				[6521] = "W0",
				[582] = "W0",
				[1180] = "W0",
				[676] = "W0",
				[196] = "W0",
				[1102] = "W0",
				[193] = "W0",
			},
			["LXPMax"] = 66200,
			["ArenaPts"] = 0,
			["Honor"] = 1110,
			["Money"] = 579495,
			["XP"] = 7360,
			["LXP"] = 7360,
			["L"] = {
				["Events"] = {
				},
				["Quest"] = {
				},
				["Version"] = 0.1,
			},
			["LXPRest"] = 99300,
			["LHonor"] = 1110,
			["Version"] = 0.02,
			["W"] = {
				["NxHUD"] = {
					["_W"] = 8,
					["FI"] = 1,
					["FO"] = 0.15,
					["W"] = 8,
					["Y"] = 203.9999839901927,
					["H"] = 40,
					["_H"] = 40,
					["Hide"] = true,
					["X"] = 795.9999880790713,
					["_Y"] = -0.17,
					["_X"] = 999999,
				},
				["NxQuestList"] = {
					["_W"] = -0.52,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = 831.9999876022341,
					["Y"] = 179.9999858736994,
					["X"] = 383.9999942779542,
					["_H"] = -0.65,
					["Hide"] = true,
					["H"] = 779.9999387860307,
					["_Y"] = -0.15,
					["_X"] = -0.24,
				},
				["NxDD"] = {
					["_W"] = 207,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = 207,
					["Y"] = 0,
					["X"] = 0,
					["_H"] = 209,
					["_X"] = 0,
					["H"] = 209,
					["_Y"] = 0,
					["Hide"] = true,
				},
				["NxQuestWatch"] = {
					["_W"] = -0.2,
					["FI"] = 1,
					["FO"] = 0.15,
					["W"] = 319.9999952316285,
					["Y"] = 419.9999670386319,
					["X"] = 1279.999980926514,
					["_H"] = -0.1,
					["H"] = 119.9999905824663,
					["_Y"] = -0.35,
					["_X"] = -0.8,
				},
				["NxMapDock"] = {
					["_W"] = 52,
					["FI"] = 1,
					["FO"] = 0,
					["W"] = 52,
					["Y"] = 95.99999246597301,
					["X"] = 1547.999976158142,
					["H"] = 69,
					["_H"] = 69,
					["_L"] = 2,
					["L"] = 2,
					["_Y"] = -0.08,
					["_X"] = 100045,
				},
				["NxGuide1"] = {
					["_W"] = -0.45,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = 719.9999892711642,
					["Y"] = 239.9999811649325,
					["X"] = 319.9999952316285,
					["_H"] = -0.45,
					["Hide"] = true,
					["H"] = 539.9999576210983,
					["_Y"] = -0.2,
					["_X"] = -0.2,
				},
				["Version"] = 0.31,
				["NxMap1"] = {
					["9002L"] = 1,
					["FI"] = 1,
					["FO"] = 0,
					["9001Y"] = -0.4,
					["9003H"] = -0.3,
					["_H"] = -0.3,
					["_L"] = 1,
					["9003Y"] = -0.4,
					["9008H"] = -0.3,
					["9002X"] = -0.0001,
					["9001H"] = -0.3,
					["9002H"] = -0.3,
					["9002W"] = -0.19,
					["9008Y"] = -0.4,
					["_X"] = -0.0001,
					["9002Y"] = -0.4,
					["9003W"] = -0.19,
					["H"] = 230.3999828338625,
					["9003L"] = 1,
					["9003X"] = -0.0001,
					["L"] = 1,
					["9001L"] = 1,
					["_W"] = -0.19,
					["9008L"] = 1,
					["9008W"] = -0.19,
					["9004H"] = -0.3,
					["9004Y"] = -0.4,
					["W"] = 194.56,
					["9008X"] = -0.0001,
					["Y"] = 307.1999771118167,
					["X"] = 0.1024,
					["9004W"] = -0.19,
					["9004L"] = 1,
					["9004X"] = -0.0001,
					["9001X"] = -0.0001,
					["_Y"] = -0.4,
					["9001W"] = -0.19,
				},
				["NxPunkHUD"] = {
					["_W"] = 135,
					["FI"] = 0.5,
					["FO"] = 0,
					["W"] = 135,
					["Y"] = 119.9999905824663,
					["X"] = 959.9999856948855,
					["_H"] = 87,
					["H"] = 87,
					["_Y"] = -0.1,
					["_X"] = -0.6,
				},
				["NxEventsList"] = {
					["_W"] = -0.25,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = 399.9999940395356,
					["Y"] = 719.9999434947976,
					["X"] = 1199.999982118607,
					["_H"] = -0.1,
					["_X"] = -0.75,
					["H"] = 119.9999905824663,
					["_Y"] = -0.6,
					["Hide"] = true,
				},
				["NxCombat"] = {
					["_W"] = -0.3,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = 479.9999928474427,
					["Y"] = 839.9999340772638,
					["X"] = 1119.9999833107,
					["_H"] = -0.06,
					["_X"] = -0.7,
					["H"] = 71.99999434947975,
					["_Y"] = -0.7,
					["Hide"] = true,
				},
				["NxTeamHUD"] = {
					["_W"] = 107,
					["FI"] = 0.5,
					["FO"] = 0,
					["W"] = 107,
					["Y"] = 359.9999717473988,
					["X"] = 959.9999856948855,
					["_H"] = 40,
					["_X"] = -0.6,
					["H"] = 40,
					["_Y"] = -0.3,
					["Hide"] = true,
				},
			},
			["Time"] = 1242372014,
			["LTime"] = 1242371758,
			["LvlTime"] = 1242371758,
			["Opts"] = {
				["MapShowGatherH"] = false,
				["QMapShowQuestGivers3"] = 1,
				["MapShowGatherM"] = false,
			},
		},
		["轻风之语.Dispel"] = {
			["XPMax"] = 400,
			["NXLoggedOnNum"] = 1,
			["E"] = {
				["Info"] = {
					{
						["NXX"] = 0,
						["NXY"] = 0,
						["NXName"] = "Entered",
						["NXTime"] = 1242374786.000001,
						["T"] = "I",
						["NXMapId"] = 1008,
					}, -- [1]
				},
				["Death"] = {
				},
				["Kill"] = {
				},
				["Mine"] = {
				},
				["Herb"] = {
				},
			},
			["Class"] = "Priest",
			["LLevel"] = 1,
			["LArenaPts"] = 0,
			["Opts"] = {
				["MapShowGatherH"] = false,
				["QMapShowQuestGivers3"] = 1,
				["MapShowGatherM"] = false,
			},
			["TBar"] = {
				["Version"] = 0.1,
				["NxMap1TB"] = {
					["Space"] = 1,
					["AlignR"] = true,
					["Size"] = 22,
					["AlignB"] = true,
				},
			},
			["LMoney"] = 0,
			["TimePlayed"] = 0,
			["Level"] = 1,
			["Profs"] = {
			},
			["LvlTime"] = 1242374759,
			["Q"] = {
			},
			["LTime"] = 1242374759,
			["LXPMax"] = 400,
			["Honor"] = 0,
			["Money"] = 0,
			["LXP"] = 0,
			["W"] = {
				["NxHUD"] = {
					["_W"] = 8,
					["FI"] = 1,
					["FO"] = 0.15,
					["W"] = 8,
					["Y"] = 203.9999839901927,
					["X"] = 795.9999880790713,
					["_H"] = 40,
					["_X"] = 999999,
					["H"] = 40,
					["_Y"] = -0.17,
					["Hide"] = true,
				},
				["NxQuestList"] = {
					["_W"] = -0.52,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = 831.9999876022341,
					["Y"] = 179.9999858736994,
					["X"] = 383.9999942779542,
					["_H"] = -0.65,
					["_X"] = -0.24,
					["H"] = 779.9999387860307,
					["_Y"] = -0.15,
					["Hide"] = true,
				},
				["NxDD"] = {
					["_W"] = 207,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = 207,
					["Y"] = 0,
					["X"] = 0,
					["_H"] = 209,
					["Hide"] = true,
					["H"] = 209,
					["_Y"] = 0,
					["_X"] = 0,
				},
				["NxQuestWatch"] = {
					["_W"] = -0.2,
					["FI"] = 1,
					["FO"] = 0.15,
					["W"] = 319.9999952316285,
					["Y"] = 419.9999670386319,
					["X"] = 1279.999980926514,
					["_H"] = -0.1,
					["H"] = 119.9999905824663,
					["_Y"] = -0.35,
					["_X"] = -0.8,
				},
				["NxGuide1"] = {
					["_W"] = -0.45,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = 719.9999892711642,
					["Y"] = 239.9999811649325,
					["X"] = 319.9999952316285,
					["_H"] = -0.45,
					["_X"] = -0.2,
					["H"] = 539.9999576210983,
					["_Y"] = -0.2,
					["Hide"] = true,
				},
				["Version"] = 0.31,
				["NxMap1"] = {
					["9002L"] = 1,
					["FI"] = 1,
					["FO"] = 0,
					["9001Y"] = -0.4,
					["9003H"] = -0.3,
					["_H"] = -0.3,
					["_L"] = 1,
					["9003Y"] = -0.4,
					["MaxL"] = 2,
					["9008H"] = -0.3,
					["9002X"] = -0.0001,
					["9001H"] = -0.3,
					["MaxX"] = 159.9999976158142,
					["9002H"] = -0.3,
					["9002W"] = -0.19,
					["MaxH"] = 959.9999094009413,
					["9008Y"] = -0.4,
					["_X"] = -0.0001,
					["A"] = "TOPLEFT",
					["9002Y"] = -0.4,
					["9003W"] = -0.19,
					["9001W"] = -0.19,
					["MaxY"] = 119.9999886751177,
					["H"] = 230.3999866485598,
					["9003L"] = 1,
					["9003X"] = -0.0001,
					["9008L"] = 1,
					["L"] = 1,
					["MaxA"] = "TOPLEFT",
					["9001L"] = 1,
					["MaxS"] = 1,
					["_W"] = -0.19,
					["S"] = 1,
					["9008W"] = -0.19,
					["9004W"] = -0.19,
					["9004Y"] = -0.4,
					["W"] = 194.5599908447267,
					["9008X"] = -0.0001,
					["Y"] = 307.1999885559084,
					["X"] = 0.1023999958872796,
					["9004L"] = 1,
					["9004H"] = -0.3,
					["9004X"] = -0.0001,
					["9001X"] = -0.0001,
					["_Y"] = -0.4,
					["MaxW"] = 1279.999980926514,
				},
				["NxPunkHUD"] = {
					["_W"] = 135,
					["FI"] = 0.5,
					["FO"] = 0,
					["W"] = 135,
					["Y"] = 119.9999905824663,
					["X"] = 959.9999856948855,
					["_H"] = 87,
					["H"] = 87,
					["_Y"] = -0.1,
					["_X"] = -0.6,
				},
				["NxTeamHUD"] = {
					["_W"] = 107,
					["FI"] = 0.5,
					["FO"] = 0,
					["W"] = 107,
					["Y"] = 359.9999717473988,
					["X"] = 959.9999856948855,
					["_H"] = 40,
					["Hide"] = true,
					["H"] = 40,
					["_Y"] = -0.3,
					["_X"] = -0.6,
				},
				["NxCombat"] = {
					["_W"] = -0.3,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = 479.9999928474427,
					["Y"] = 839.9999340772638,
					["X"] = 1119.9999833107,
					["_H"] = -0.06,
					["Hide"] = true,
					["H"] = 71.99999434947975,
					["_Y"] = -0.7,
					["_X"] = -0.7,
				},
				["NxEventsList"] = {
					["_W"] = -0.25,
					["FI"] = 1,
					["FO"] = 0.75,
					["W"] = 399.9999940395356,
					["Y"] = 719.9999434947976,
					["X"] = 1199.999982118607,
					["_H"] = -0.1,
					["Hide"] = true,
					["H"] = 119.9999905824663,
					["_Y"] = -0.6,
					["_X"] = -0.75,
				},
			},
			["L"] = {
				["Events"] = {
				},
				["Quest"] = {
				},
				["Version"] = 0.1,
			},
			["LXPRest"] = 0,
			["LHonor"] = 0,
			["Version"] = 0.02,
			["Time"] = 1242375009,
			["XP"] = 0,
			["ArenaPts"] = 0,
			["XPRest"] = 0,
			["Pos"] = "1008^53.198290^64.554322",
		},
	},
	["NXSocial"] = {
		["艾萨拉"] = {
			["PkAct"] = {
			},
			["Pal"] = {
				[""] = {
				},
			},
			["Pk"] = {
			},
		},
		["海加尔"] = {
			["PkAct"] = {
			},
			["Pal"] = {
				[""] = {
					["没有鱼丸"] = "",
					["硕哥哥"] = "",
					["Inoo"] = "",
					["我不想死"] = "",
					["思念晓风"] = "",
					["丄兲凍結孒"] = "",
					["矿工袋"] = "",
					["千里独徘徊"] = "",
					["小小的笨笨"] = "",
					["Afa"] = "",
					["现代小德"] = "",
					["老鬼不孤单"] = "",
					["Bigboom"] = "",
					["苏乐乐"] = "",
					["奶香娃娃"] = "",
					["默默无闻"] = "",
					["匆匆那年"] = "",
					["流氓越"] = "",
					["綄羙小寳贝"] = "",
					["嗜血小骑"] = "",
					["Rudexx"] = "",
					["姐夫是我呀"] = "",
					["鬼六小苯"] = "",
					["紫金铃之光辉"] = "",
					["丄兲凍結了"] = "",
					["雨泠泠"] = "",
					["小革命"] = "",
					["一只狼"] = "",
					["Fgenzi"] = "",
					["亥哥"] = "",
					["死亡地狱"] = "",
					["凌波飞羽"] = "",
					["Posions"] = "",
					["Saul"] = "",
					["要害"] = "70~Shaman",
					["笨笨的小小"] = "",
					["火炎水只爹"] = "",
					["满天飞"] = "",
					["冥影乂契约"] = "70~Warlock",
					["大众帅哥乙"] = "",
					["哈泥"] = "",
					["Chaeyeon"] = "",
					["红手"] = "",
					["机械复古"] = "",
					["Legionator"] = "",
					["Blackscorpio"] = "70~Rogue",
					["月光酒"] = "",
					["振軒"] = "",
					["小小奥法之尘"] = "",
					["Soifon"] = "",
					["Frostbolt"] = "",
					["Holyvirgin"] = "",
					["Poisons"] = "",
					["Sparanoid"] = "",
					["东方未明"] = "",
				},
			},
			["Pk"] = {
			},
		},
		["屠魔山谷"] = {
			["PkAct"] = {
			},
			["Pal"] = {
				[""] = {
				},
			},
			["Pk"] = {
			},
		},
		["Version"] = 0.2,
		["轻风之语"] = {
			["PkAct"] = {
			},
			["Pal"] = {
				[""] = {
				},
			},
			["Pk"] = {
			},
		},
	},
	["NXVer1"] = 3.11,
	["NXWare"] = {
		["Version"] = 0.1,
		["海加尔"] = {
			["GloRy Of EmpIre"] = {
			},
			["I Love Smers"] = {
			},
		},
	},
	["NXVerT"] = 1240929413,
	["NXVendorV"] = {
		["?~Innkeeper Haelthol"] = {
			"8950^|cffbfbfbf32s", -- [1]
			"27855^|cffbfbfbf44s |cff7f7f0080c", -- [2]
			"29449^|cffbfbfbf64s", -- [3]
			"8953^|cffbfbfbf32s", -- [4]
			"27856^|cffbfbfbf44s |cff7f7f0080c", -- [5]
			"29450^|cffbfbfbf64s", -- [6]
			"8932^|cffbfbfbf32s", -- [7]
			"27857^|cffbfbfbf44s |cff7f7f0080c", -- [8]
			"29448^|cffbfbfbf64s", -- [9]
			"8766^|cffbfbfbf32s", -- [10]
			"28399^|cffbfbfbf44s |cff7f7f0080c", -- [11]
			"27860^|cffbfbfbf51s |cff7f7f0020c", -- [12]
			["POS"] = "9005^44.269025325775^44.334307312965",
			["T"] = 1244023282,
		},
		["?~Arodis Sunblade"] = {
			"29050^|r1 Chestguard Token", -- [1]
			"29056^|r1 Chestguard Token", -- [2]
			"29055^|r1 Gloves Token", -- [3]
			"29057^|r1 Gloves Token", -- [4]
			"29049^|r1 Helm Token", -- [5]
			"29058^|r1 Helm Token", -- [6]
			"29053^|r1 Leggings Token", -- [7]
			"29059^|r1 Leggings Token", -- [8]
			"29054^|r1 Pauldrons Token", -- [9]
			"29060^|r1 Pauldrons Token", -- [10]
			["T"] = 1244041319,
			["POS"] = "3006^43.641448020935^90.513056516647",
			["R"] = 1,
		},
		["?~Ernie Packwell"] = {
			"14341^|cffbfbfbf40s", -- [1]
			"18256^|cffffff001g |cffbfbfbf60s", -- [2]
			"6532^|cffbfbfbf2s", -- [3]
			"3713^|cffbfbfbf1s |cff7f7f0028c", -- [4]
			"4471^|cffbfbfbf1s |cff7f7f008c", -- [5]
			"4470^|cff7f7f0030c", -- [6]
			"10648^|cffbfbfbf1s", -- [7]
			["POS"] = "3006^66.105300188065^64.734065532684",
			["T"] = 1242997310,
		},
		["?~Moorane Hearthgrain"] = {
			"4540^|cff7f7f0025c", -- [1]
			"4541^|cffbfbfbf1s |cff7f7f0025c", -- [2]
			"4542^|cffbfbfbf5s", -- [3]
			"4544^|cffbfbfbf10s", -- [4]
			"4601^|cffbfbfbf20s", -- [5]
			"8950^|cffbfbfbf40s", -- [6]
			["POS"] = "1019^52.338767051697^30.557516217232",
			["T"] = 1243690334,
		},
		["?~Razbo Rustgear"] = {
			"2522^|cffffff001g |cffbfbfbf91s |cff7f7f0066c", -- [1]
			"2530^|cffffff004g |cffbfbfbf43s |cff7f7f0087c", -- [2]
			"2523^|cffffff002g |cffbfbfbf40s |cff7f7f0043c", -- [3]
			"2531^|cffffff004g |cffbfbfbf77s |cff7f7f0044c", -- [4]
			"2432^|cffbfbfbf65s |cff7f7f0037c", -- [5]
			"2438^|cffffff001g |cffbfbfbf78s |cff7f7f0047c", -- [6]
			"2467^|cffbfbfbf80s |cff7f7f0016c", -- [7]
			"2473^|cffffff002g |cffbfbfbf18s |cff7f7f0090c", -- [8]
			"2420^|cffffff001g |cffbfbfbf1s |cff7f7f0047c", -- [9]
			"2426^|cffffff002g |cffbfbfbf76s |cff7f7f0084c", -- [10]
			["T"] = 1243835082,
			["POS"] = "1009^42.586904764175^73.400193452835",
			["R"] = 1,
		},
		["?~Shankys"] = {
			"6256^|cff7f7f0023c", -- [1]
			"6529^|cff7f7f0050c", -- [2]
			"6530^|cffbfbfbf1s", -- [3]
			"6532^|cffbfbfbf2s |cff7f7f0050c", -- [4]
			"6368^|cffbfbfbf4s", -- [5]
			"6369^|cffbfbfbf22s", -- [6]
			"17062^|cffbfbfbf22s", -- [7]
			"6533^|cffbfbfbf2s |cff7f7f0050c", -- [8]
			["T"] = 1244070718,
			["POS"] = "1014^69.798547029495^29.679328203201",
		},
		["?~Tydormu"] = {
			"31068^|r1 Leggings Token", -- [1]
			"31063^|r1 Helm Token", -- [2]
			"31060^|r1 Gloves Token", -- [3]
			"31069^|r1 Pauldrons Token", -- [4]
			"31066^|r1 Chestguard Token", -- [5]
			"31061^|r1 Gloves Token", -- [6]
			"31064^|r1 Helm Token", -- [7]
			"31067^|r1 Leggings Token", -- [8]
			"31070^|r1 Pauldrons Token", -- [9]
			"31065^|r1 Chestguard Token", -- [10]
			["T"] = 1242833768,
			["POS"] = "11023^57.175141572952^49.848738312721",
			["R"] = 1,
		},
		["?~Samir"] = {
			"2901^|cff7f7f0081c", -- [1]
			"5956^|cff7f7f0018c", -- [2]
			"2880^|cffbfbfbf1s", -- [3]
			"3466^|cffbfbfbf20s", -- [4]
			"18567^|cffffff0015g", -- [5]
			"3857^|cffbfbfbf5s", -- [6]
			["POS"] = "2012^70.726132392883^69.184184074402",
			["T"] = 1242741284,
			["R"] = 1,
		},
		["?~Nakodu"] = {
			"23138^|cffffff004g |cffbfbfbf80s", -- [1]
			"30833^|cffffff004g |cffbfbfbf80s", -- [2]
			"29199^|cffffff0080g", -- [3]
			"30633^|cffffff008g", -- [4]
			"24179^|cffffff009g |cffbfbfbf60s", -- [5]
			"22538^|cffffff0016g", -- [6]
			"24175^|cffffff009g |cffbfbfbf60s", -- [7]
			"22910^|cffffff006g |cffbfbfbf40s", -- [8]
			"30846^|cffffff0080g", -- [9]
			"34200^|cffffff0012g |cffbfbfbf80s", -- [10]
			"30836^|cffffff0013g |cffbfbfbf95s |cff7f7f0022c", -- [11]
			"30835^|cffffff0020g |cffbfbfbf85s |cff7f7f003c", -- [12]
			"30841^|cffffff0014g |cffbfbfbf7s |cff7f7f0062c", -- [13]
			"31357^|cffffff003g |cffbfbfbf20s", -- [14]
			"33148^|cffffff008g", -- [15]
			"30832^|cffffff0040g |cffbfbfbf38s |cff7f7f0073c", -- [16]
			"30834^|cffffff0015g |cffbfbfbf80s |cff7f7f0022c", -- [17]
			"30830^|cffffff00200g |cffbfbfbf40s |cff7f7f0064c", -- [18]
			"31778^|cffbfbfbf80s", -- [19]
			"33157^|cffffff009g |cffbfbfbf60s", -- [20]
			"35335^|cffffff007g |cffbfbfbf13s |cff7f7f0073c", -- [21]
			"35340^|cffffff0014g |cffbfbfbf53s |cff7f7f0036c", -- [22]
			["POS"] = "3006^62.227982282639^68.992191553116",
			["T"] = 1242997293,
		},
		["?~Barkeep Morag"] = {
			"2723^|cff7f7f0050c", -- [1]
			"2593^|cffbfbfbf1s |cff7f7f0050c", -- [2]
			"2596^|cffbfbfbf1s |cff7f7f0020c", -- [3]
			"2594^|cffbfbfbf15s", -- [4]
			"2595^|cffbfbfbf20s", -- [5]
			"159^|cff7f7f0025c", -- [6]
			"1179^|cffbfbfbf1s |cff7f7f0025c", -- [7]
			"1205^|cffbfbfbf5s", -- [8]
			"1708^|cffbfbfbf10s", -- [9]
			"1645^|cffbfbfbf20s", -- [10]
			"8766^|cffbfbfbf40s", -- [11]
			"117^|cff7f7f0025c", -- [12]
			"2287^|cffbfbfbf1s |cff7f7f0025c", -- [13]
			"3770^|cffbfbfbf5s", -- [14]
			"3771^|cffbfbfbf10s", -- [15]
			"4599^|cffbfbfbf20s", -- [16]
			"8952^|cffbfbfbf40s", -- [17]
			["T"] = 1242739807,
			["POS"] = "1014^54.597824811935^68.224710226059",
		},
		["?~Lisrythe Bloodwatch"] = {
			"28458^|cffffff001g |cffbfbfbf60s", -- [1]
			"28462^|cffffff001g |cffbfbfbf60s", -- [2]
			"28459^|cffffff001g |cffbfbfbf60s", -- [3]
			"28461^|cffffff001g |cffbfbfbf60s", -- [4]
			"28460^|cffffff001g |cffbfbfbf60s", -- [5]
			"28465^|cffffff001g |cffbfbfbf60s", -- [6]
			"28463^|cffffff001g |cffbfbfbf60s", -- [7]
			"28464^|cffffff001g |cffbfbfbf60s", -- [8]
			"28466^|cffffff001g |cffbfbfbf60s", -- [9]
			"28469^|cffffff001g |cffbfbfbf60s", -- [10]
			"28468^|cffffff001g |cffbfbfbf60s", -- [11]
			"28467^|cffffff001g |cffbfbfbf60s", -- [12]
			"28470^|cffffff001g |cffbfbfbf60s", -- [13]
			["T"] = 1242735662,
			["POS"] = "3006^54.379296302795^82.834750413895",
		},
		["?~Okuno"] = {
			"32438^|cffffff006g |cffbfbfbf40s", -- [1]
			"32440^|cffffff006g |cffbfbfbf40s", -- [2]
			"32429^|cffffff006g |cffbfbfbf40s", -- [3]
			"32430^|cffffff006g |cffbfbfbf40s", -- [4]
			"32435^|cffffff006g |cffbfbfbf40s", -- [5]
			"32436^|cffffff006g |cffbfbfbf40s", -- [6]
			"32442^|cffffff006g |cffbfbfbf40s", -- [7]
			"32444^|cffffff006g |cffbfbfbf40s", -- [8]
			"32439^|cffffff006g |cffbfbfbf40s", -- [9]
			"32437^|cffffff006g |cffbfbfbf40s", -- [10]
			"32447^|cffffff006g |cffbfbfbf40s", -- [11]
			"32431^|cffffff006g |cffbfbfbf40s", -- [12]
			"32432^|cffffff006g |cffbfbfbf40s", -- [13]
			"32433^|cffffff006g |cffbfbfbf40s", -- [14]
			"32434^|cffffff006g |cffbfbfbf40s", -- [15]
			"32443^|cffffff006g |cffbfbfbf40s", -- [16]
			"32441^|cffffff006g |cffbfbfbf40s", -- [17]
			"32490^|cffffff0023g |cffbfbfbf5s |cff7f7f0025c", -- [18]
			["POS"] = "13013^71.050035953522^46.700149774551",
			["T"] = 1244114468,
			["R"] = 1,
		},
		["?~Hraq"] = {
			"2901^|cff7f7f0081c", -- [1]
			"5956^|cff7f7f0018c", -- [2]
			"2880^|cffbfbfbf1s", -- [3]
			"3466^|cffbfbfbf20s", -- [4]
			"18567^|cffffff0015g", -- [5]
			"3857^|cffbfbfbf5s", -- [6]
			["POS"] = "1019^51.138538122177^29.012879729271",
			["T"] = 1243690224,
			["R"] = 1,
		},
		["?~Korthul"] = {
			"30758^|cffffff0010g |cffbfbfbf33s |cff7f7f0077c", -- [1]
			"30757^|cffffff0010g |cffbfbfbf42s |cff7f7f0057c", -- [2]
			"30759^|cffffff0010g |cffbfbfbf24s |cff7f7f0098c", -- [3]
			"11285^|cffbfbfbf10s", -- [4]
			"28053^|cffbfbfbf16s", -- [5]
			"28056^|cffbfbfbf30s", -- [6]
			"11284^|cffbfbfbf10s", -- [7]
			"28060^|cffbfbfbf16s", -- [8]
			"28061^|cffbfbfbf30s", -- [9]
			["POS"] = "3005^29.932937026024^31.106987595558",
			["T"] = 1243567020,
			["R"] = 1,
		},
		["?~Smith Hauthaa"] = {
			"34919^|r75 Badge of Justice", -- [1]
			"34918^|r100 Badge of Justice", -- [2]
			"34917^|r100 Badge of Justice", -- [3]
			"34926^|r75 Badge of Justice", -- [4]
			"34925^|r100 Badge of Justice", -- [5]
			"34924^|r100 Badge of Justice", -- [6]
			"34938^|r75 Badge of Justice", -- [7]
			"34937^|r100 Badge of Justice", -- [8]
			"34936^|r100 Badge of Justice", -- [9]
			"34900^|r100 Badge of Justice", -- [10]
			"34902^|r75 Badge of Justice", -- [11]
			"34901^|r100 Badge of Justice", -- [12]
			"34906^|r100 Badge of Justice", -- [13]
			"34911^|r75 Badge of Justice", -- [14]
			"34910^|r100 Badge of Justice", -- [15]
			"34903^|r100 Badge of Justice", -- [16]
			"34904^|r75 Badge of Justice", -- [17]
			"34905^|r100 Badge of Justice", -- [18]
			"34929^|r75 Badge of Justice", -- [19]
			"34927^|r100 Badge of Justice", -- [20]
			"34928^|r100 Badge of Justice", -- [21]
			"34912^|r100 Badge of Justice", -- [22]
			"34916^|r75 Badge of Justice", -- [23]
			"34914^|r100 Badge of Justice", -- [24]
			"34932^|r75 Badge of Justice", -- [25]
			"34930^|r100 Badge of Justice", -- [26]
			"34931^|r100 Badge of Justice", -- [27]
			"34935^|r75 Badge of Justice", -- [28]
			"34933^|r100 Badge of Justice", -- [29]
			"34934^|r100 Badge of Justice", -- [30]
			"34923^|r75 Badge of Justice", -- [31]
			"34921^|r100 Badge of Justice", -- [32]
			"34922^|r100 Badge of Justice", -- [33]
			"34947^|r75 Badge of Justice", -- [34]
			"34945^|r100 Badge of Justice", -- [35]
			"34946^|r100 Badge of Justice", -- [36]
			"34944^|r75 Badge of Justice", -- [37]
			"34942^|r100 Badge of Justice", -- [38]
			"34943^|r100 Badge of Justice", -- [39]
			"34941^|r75 Badge of Justice", -- [40]
			"34939^|r100 Badge of Justice", -- [41]
			"34940^|r100 Badge of Justice", -- [42]
			"34889^|r60 Badge of Justice", -- [43]
			"34890^|r60 Badge of Justice", -- [44]
			"34887^|r60 Badge of Justice", -- [45]
			"34888^|r60 Badge of Justice", -- [46]
			"34891^|r150 Badge of Justice", -- [47]
			"34895^|r150 Badge of Justice", -- [48]
			"34892^|r150 Badge of Justice", -- [49]
			"34898^|r150 Badge of Justice", -- [50]
			"34896^|r150 Badge of Justice", -- [51]
			"34893^|r105 Badge of Justice", -- [52]
			"34950^|r45 Badge of Justice", -- [53]
			"34951^|r45 Badge of Justice", -- [54]
			"34894^|r105 Badge of Justice", -- [55]
			"34949^|r45 Badge of Justice", -- [56]
			"34952^|r45 Badge of Justice", -- [57]
			["T"] = 1244015785,
			["POS"] = "2029^50.543421506882^40.875855088234",
			["R"] = 1,
		},
		["?~Kulwia"] = {
			"7005^|cff7f7f0066c", -- [1]
			"2901^|cff7f7f0065c", -- [2]
			"5956^|cff7f7f0014c", -- [3]
			"6256^|cff7f7f0018c", -- [4]
			"6217^|cff7f7f0099c", -- [5]
			"2320^|cff7f7f008c", -- [6]
			"2321^|cff7f7f0080c", -- [7]
			"2678^|cff7f7f008c", -- [8]
			"2692^|cff7f7f0032c", -- [9]
			"2880^|cff7f7f0080c", -- [10]
			"2928^|cff7f7f0016c", -- [11]
			"3371^|cff7f7f0016c", -- [12]
			"3372^|cffbfbfbf1s |cff7f7f0060c", -- [13]
			"4289^|cff7f7f0040c", -- [14]
			"6529^|cff7f7f0040c", -- [15]
			"6530^|cff7f7f0080c", -- [16]
			"2324^|cff7f7f0020c", -- [17]
			"39354^|cff7f7f0012c", -- [18]
			["POS"] = "1016^45.35576403141^59.400427341461",
			["T"] = 1243079864,
		},
		["?~Sergeant Thunderhorn"] = {
			"31958^|cffff70a09000 honor |r20 EOS", -- [1]
			"31959^|cffff70a027000 honor |r40 AV", -- [2]
			"31965^|cffff70a018000 honor |r20 EOS", -- [3]
			"31966^|cffff70a027000 honor |r40 AV", -- [4]
			"31984^|cffff70a027000 honor |r40 AV", -- [5]
			"31985^|cffff70a09000 honor |r20 EOS", -- [6]
			"31986^|cffff70a027000 honor |r40 AV", -- [7]
			"32003^|cffff70a09000 honor |r20 EOS", -- [8]
			"32014^|cffff70a027000 honor |r40 AV", -- [9]
			"32025^|cffff70a027000 honor |r40 AV", -- [10]
			"32026^|cffff70a018000 honor |r20 EOS", -- [11]
			"32027^|cffff70a09000 honor |r20 EOS", -- [12]
			"32028^|cffff70a018000 honor |r20 EOS", -- [13]
			"32044^|cffff70a018000 honor |r20 EOS", -- [14]
			"32046^|cffff70a09000 honor |r20 EOS", -- [15]
			"32052^|cffff70a018000 honor |r20 EOS", -- [16]
			"32053^|cffff70a025200 honor |r20 EOS", -- [17]
			"32054^|cffff70a08000 honor |r10 EOS", -- [18]
			"32055^|cffff70a027000 honor |r40 AV", -- [19]
			"31978^|cffff70a09000 honor |r20 EOS", -- [20]
			"32961^|cffff70a09000 honor |r20 EOS", -- [21]
			"32962^|cffff70a08000 honor |r10 EOS", -- [22]
			"32963^|cffff70a025200 honor |r20 EOS", -- [23]
			"32964^|cffff70a025200 honor |r20 EOS", -- [24]
			"32045^|cffff70a015000 honor |r20 EOS", -- [25]
			"33309^|cffff70a015000 honor |r20 EOS", -- [26]
			"33313^|cffff70a015000 honor |r20 EOS", -- [27]
			"33946^|cffff70a08000 honor |r10 EOS", -- [28]
			"33943^|cffff70a08000 honor |r10 EOS", -- [29]
			"33076^|cffff70a08000 honor |r10 EOS", -- [30]
			"33937^|cffff70a08000 honor |r10 EOS", -- [31]
			"33077^|cffff70a08000 honor |r10 EOS", -- [32]
			"33949^|cffff70a08000 honor |r10 EOS", -- [33]
			"33940^|cffff70a08000 honor |r10 EOS", -- [34]
			"33952^|cffff70a08000 honor |r10 EOS", -- [35]
			"33078^|cffff70a08000 honor |r10 EOS", -- [36]
			["T"] = 1243311125,
			["POS"] = "1014^37.174528837204^64.727085828781",
			["R"] = 1,
		},
		["?~Fantei"] = {
			"17034^|cffbfbfbf1s |cff7f7f0060c", -- [1]
			"17035^|cffbfbfbf3s |cff7f7f0020c", -- [2]
			"17036^|cffbfbfbf6s |cff7f7f0040c", -- [3]
			"17037^|cffbfbfbf11s |cff7f7f0020c", -- [4]
			"17038^|cffbfbfbf16s", -- [5]
			"22147^|cffbfbfbf40s", -- [6]
			"17031^|cffbfbfbf8s", -- [7]
			"17032^|cffbfbfbf16s", -- [8]
			"17020^|cffbfbfbf8s", -- [9]
			"17030^|cffbfbfbf16s", -- [10]
			"17033^|cffbfbfbf16s", -- [11]
			"17028^|cffbfbfbf5s |cff7f7f0060c", -- [12]
			"17029^|cffbfbfbf8s", -- [13]
			"17021^|cffbfbfbf5s |cff7f7f0060c", -- [14]
			"17026^|cffbfbfbf8s", -- [15]
			"22148^|cffbfbfbf12s", -- [16]
			"5565^|cffbfbfbf40s", -- [17]
			"16583^|cffbfbfbf80s", -- [18]
			"21177^|cffbfbfbf24s", -- [19]
			"37201^|cffbfbfbf40s", -- [20]
			"30823^|cffffff0024g", -- [21]
			["T"] = 1244037886,
			["POS"] = "3006^64.698487520218^70.249092578888",
		},
		["?~Hula'mahi"] = {
			"6947^|cff7f7f0025c", -- [1]
			"6949^|cff7f7f0050c", -- [2]
			"6950^|cffbfbfbf1s |cff7f7f0050c", -- [3]
			"8926^|cffbfbfbf5s", -- [4]
			"8927^|cffbfbfbf7s", -- [5]
			"8928^|cffbfbfbf8s", -- [6]
			"43230^|cffbfbfbf40s", -- [7]
			"43231^|cffbfbfbf45s", -- [8]
			"3775^|cff7f7f0070c", -- [9]
			"5237^|cff7f7f0040c", -- [10]
			"2892^|cffbfbfbf1s", -- [11]
			"2893^|cffbfbfbf2s", -- [12]
			"8984^|cffbfbfbf1s |cff7f7f0050c", -- [13]
			"8985^|cffbfbfbf2s |cff7f7f0050c", -- [14]
			"20844^|cffbfbfbf3s", -- [15]
			"22053^|cffbfbfbf10s", -- [16]
			"43232^|cffbfbfbf45s", -- [17]
			"43233^|cffbfbfbf50s", -- [18]
			"10918^|cff7f7f0050c", -- [19]
			"10920^|cffbfbfbf1s |cff7f7f0050c", -- [20]
			"10921^|cffbfbfbf2s |cff7f7f0050c", -- [21]
			"10922^|cffbfbfbf8s", -- [22]
			"43234^|cffbfbfbf35s", -- [23]
			"43235^|cffbfbfbf40s", -- [24]
			"21835^|cffbfbfbf15s", -- [25]
			"43237^|cffbfbfbf40s", -- [26]
			"17034^|cffbfbfbf2s", -- [27]
			"17035^|cffbfbfbf4s", -- [28]
			"17036^|cffbfbfbf8s", -- [29]
			"17037^|cffbfbfbf14s", -- [30]
			"17038^|cffbfbfbf20s", -- [31]
			"22147^|cffbfbfbf50s", -- [32]
			"17031^|cffbfbfbf10s", -- [33]
			"17032^|cffbfbfbf20s", -- [34]
			"17020^|cffbfbfbf10s", -- [35]
			"17030^|cffbfbfbf20s", -- [36]
			"17033^|cffbfbfbf20s", -- [37]
			"17028^|cffbfbfbf7s", -- [38]
			"17029^|cffbfbfbf10s", -- [39]
			"17021^|cffbfbfbf7s", -- [40]
			"17026^|cffbfbfbf10s", -- [41]
			"22148^|cffbfbfbf15s", -- [42]
			"5565^|cffbfbfbf50s", -- [43]
			"16583^|cffffff001g", -- [44]
			"21177^|cffbfbfbf30s", -- [45]
			"37201^|cffbfbfbf50s", -- [46]
			"2449^|cff7f7f0080c", -- [47]
			["POS"] = "1019^51.416164636612^30.226299166679",
			["T"] = 1243690246,
		},
		["?~Gunter"] = {
			"33926^|cffbfbfbf10s", -- [1]
			"27657^|cffbfbfbf6s", -- [2]
			"27667^|cffbfbfbf6s", -- [3]
			"27666^|cffbfbfbf6s", -- [4]
			"8948^|cffbfbfbf40s", -- [5]
			"27859^|cffbfbfbf56s", -- [6]
			"29453^|cffbfbfbf80s", -- [7]
			["T"] = 1244037383,
			["POS"] = "12118^82.422053813934^64.546847343445",
		},
		["?~Horthus"] = {
			"17034^|cffbfbfbf1s |cff7f7f0060c", -- [1]
			"17035^|cffbfbfbf3s |cff7f7f0020c", -- [2]
			"17036^|cffbfbfbf6s |cff7f7f0040c", -- [3]
			"17037^|cffbfbfbf11s |cff7f7f0020c", -- [4]
			"17038^|cffbfbfbf16s", -- [5]
			"22147^|cffbfbfbf40s", -- [6]
			"17031^|cffbfbfbf8s", -- [7]
			"17032^|cffbfbfbf16s", -- [8]
			"17020^|cffbfbfbf8s", -- [9]
			"17030^|cffbfbfbf16s", -- [10]
			"17033^|cffbfbfbf16s", -- [11]
			"17028^|cffbfbfbf5s |cff7f7f0060c", -- [12]
			"17029^|cffbfbfbf8s", -- [13]
			"17021^|cffbfbfbf5s |cff7f7f0060c", -- [14]
			"17026^|cffbfbfbf8s", -- [15]
			"22148^|cffbfbfbf12s", -- [16]
			"5565^|cffbfbfbf40s", -- [17]
			"16583^|cffbfbfbf80s", -- [18]
			"21177^|cffbfbfbf24s", -- [19]
			"37201^|cffbfbfbf40s", -- [20]
			["T"] = 1244160319,
			["POS"] = "1014^45.482036471367^56.859445571899",
		},
		["?~Vend-O-Tron D-Luxe"] = {
			"7005^|cff7f7f0082c", -- [1]
			"6256^|cff7f7f0023c", -- [2]
			"2901^|cff7f7f0081c", -- [3]
			"5956^|cff7f7f0018c", -- [4]
			"6217^|cffbfbfbf1s |cff7f7f0024c", -- [5]
			"2320^|cff7f7f0010c", -- [6]
			"2321^|cffbfbfbf1s", -- [7]
			"4291^|cffbfbfbf5s", -- [8]
			"8343^|cffbfbfbf20s", -- [9]
			"14341^|cffbfbfbf50s", -- [10]
			"2678^|cff7f7f0010c", -- [11]
			"2692^|cff7f7f0040c", -- [12]
			"3713^|cffbfbfbf1s |cff7f7f0060c", -- [13]
			"2880^|cffbfbfbf1s", -- [14]
			"3466^|cffbfbfbf20s", -- [15]
			"3857^|cffbfbfbf5s", -- [16]
			"2928^|cff7f7f0020c", -- [17]
			"2324^|cff7f7f0025c", -- [18]
			"2604^|cff7f7f0050c", -- [19]
			"2325^|cffbfbfbf10s", -- [20]
			"4341^|cffbfbfbf5s", -- [21]
			"4342^|cffbfbfbf25s", -- [22]
			"4340^|cffbfbfbf3s |cff7f7f0050c", -- [23]
			"3371^|cff7f7f0020c", -- [24]
			"3372^|cffbfbfbf2s", -- [25]
			"8925^|cffbfbfbf25s", -- [26]
			"4289^|cff7f7f0050c", -- [27]
			"4399^|cffbfbfbf2s", -- [28]
			"4400^|cffbfbfbf20s", -- [29]
			"6530^|cffbfbfbf1s", -- [30]
			"6532^|cffbfbfbf2s |cff7f7f0050c", -- [31]
			"17034^|cffbfbfbf2s", -- [32]
			"17035^|cffbfbfbf4s", -- [33]
			"17036^|cffbfbfbf8s", -- [34]
			"17037^|cffbfbfbf14s", -- [35]
			"17038^|cffbfbfbf20s", -- [36]
			"22147^|cffbfbfbf50s", -- [37]
			"17031^|cffbfbfbf10s", -- [38]
			"17032^|cffbfbfbf20s", -- [39]
			"17020^|cffbfbfbf10s", -- [40]
			"17030^|cffbfbfbf20s", -- [41]
			"17033^|cffbfbfbf20s", -- [42]
			"17028^|cffbfbfbf7s", -- [43]
			"17029^|cffbfbfbf10s", -- [44]
			"17021^|cffbfbfbf7s", -- [45]
			"17026^|cffbfbfbf10s", -- [46]
			"22148^|cffbfbfbf15s", -- [47]
			"5565^|cffbfbfbf50s", -- [48]
			"16583^|cffffff001g", -- [49]
			"21177^|cffbfbfbf30s", -- [50]
			"37201^|cffbfbfbf50s", -- [51]
			["T"] = 1242732160,
			["POS"] = "1008^50.264936685562^12.54703104496",
			["R"] = 1,
		},
		["?~Innkeeper Gryshka"] = {
			"117^|cff7f7f0025c", -- [1]
			"2287^|cffbfbfbf1s |cff7f7f0025c", -- [2]
			"3770^|cffbfbfbf5s", -- [3]
			"3771^|cffbfbfbf10s", -- [4]
			"4599^|cffbfbfbf20s", -- [5]
			"8952^|cffbfbfbf40s", -- [6]
			"27854^|cffbfbfbf56s", -- [7]
			"33454^|cffbfbfbf85s", -- [8]
			"35953^|cffffff001g |cffbfbfbf60s", -- [9]
			"159^|cff7f7f0025c", -- [10]
			"1179^|cffbfbfbf1s |cff7f7f0025c", -- [11]
			"1205^|cffbfbfbf5s", -- [12]
			"1708^|cffbfbfbf10s", -- [13]
			"1645^|cffbfbfbf20s", -- [14]
			"8766^|cffbfbfbf40s", -- [15]
			"28399^|cffbfbfbf56s", -- [16]
			"35954^|cffbfbfbf60s", -- [17]
			"33444^|cffbfbfbf85s", -- [18]
			"33445^|cffffff001g |cffbfbfbf10s", -- [19]
			["T"] = 1243786866,
			["POS"] = "1014^54.069858789444^68.710273504257",
		},
		["?~Aaron Hollman"] = {
			"25846^|cffffff003g |cffbfbfbf20s", -- [1]
			"23590^|cffffff003g |cffbfbfbf20s", -- [2]
			"23593^|cffffff003g |cffbfbfbf20s", -- [3]
			"23591^|cffffff003g |cffbfbfbf20s", -- [4]
			"23592^|cffffff003g |cffbfbfbf20s", -- [5]
			"2901^|cff7f7f0065c", -- [6]
			"5956^|cff7f7f0014c", -- [7]
			"2880^|cff7f7f0080c", -- [8]
			"3466^|cffbfbfbf16s", -- [9]
			"18567^|cffffff0012g", -- [10]
			"3857^|cffbfbfbf4s", -- [11]
			["T"] = 1244159392,
			["POS"] = "3006^63.994914293289^72.029334306717",
			["R"] = 1,
		},
		["?~Grella"] = {
			"32722^|cffbfbfbf32s", -- [1]
			"32721^|cffbfbfbf36s", -- [2]
			"32538^|cffffff0011g |cffbfbfbf1s |cff7f7f0053c", -- [3]
			"32539^|cffffff0011g |cffbfbfbf5s |cff7f7f0033c", -- [4]
			"38628^|cffffff0032g", -- [5]
			"32319^|cffffff00160g", -- [6]
			"32314^|cffffff00160g", -- [7]
			"32316^|cffffff00160g", -- [8]
			"32317^|cffffff00160g", -- [9]
			"32318^|cffffff00160g", -- [10]
			"32445^|cffbfbfbf80s", -- [11]
			"32771^|cffffff003g |cffbfbfbf29s |cff7f7f0084c", -- [12]
			"32770^|cffffff003g |cffbfbfbf29s |cff7f7f0084c", -- [13]
			["T"] = 1243940890,
			["POS"] = "3007^64.271700382233^66.216826438904",
			["R"] = 1,
		},
		["?~Ontuvo"] = {
			"32227^|r15 Badge of Justice", -- [1]
			"32228^|r15 Badge of Justice", -- [2]
			"32229^|r15 Badge of Justice", -- [3]
			"32231^|r15 Badge of Justice", -- [4]
			"32230^|r15 Badge of Justice", -- [5]
			"32249^|r15 Badge of Justice", -- [6]
			"35264^|cffffff0040g", -- [7]
			"35244^|cffffff0040g", -- [8]
			"35261^|cffffff0040g", -- [9]
			"35250^|cffffff0040g", -- [10]
			"35263^|cffffff0040g", -- [11]
			"35249^|cffffff0040g", -- [12]
			"35260^|cffffff0040g", -- [13]
			"35248^|cffffff0040g", -- [14]
			"35262^|cffffff0040g", -- [15]
			"35256^|cffffff0040g", -- [16]
			"35245^|cffffff0040g", -- [17]
			"35255^|cffffff0040g", -- [18]
			"35246^|cffffff0040g", -- [19]
			"35269^|cffffff0040g", -- [20]
			"35254^|cffffff0040g", -- [21]
			"35253^|cffffff0040g", -- [22]
			"35268^|cffffff0040g", -- [23]
			"35239^|cffffff0040g", -- [24]
			"35266^|cffffff0040g", -- [25]
			"35240^|cffffff0040g", -- [26]
			"35238^|cffffff0040g", -- [27]
			"35251^|cffffff0040g", -- [28]
			"35252^|cffffff0040g", -- [29]
			"35259^|cffffff0040g", -- [30]
			"35241^|cffffff0040g", -- [31]
			"35271^|cffffff0040g", -- [32]
			"35768^|cffffff0040g", -- [33]
			"35767^|cffffff0040g", -- [34]
			"35766^|cffffff0040g", -- [35]
			"35769^|cffffff0040g", -- [36]
			"35267^|cffffff0040g", -- [37]
			"35270^|cffffff0040g", -- [38]
			"35258^|cffffff0040g", -- [39]
			"35242^|cffffff0040g", -- [40]
			"35247^|cffffff0040g", -- [41]
			"35265^|cffffff0040g", -- [42]
			"35257^|cffffff0040g", -- [43]
			"35243^|cffffff0040g", -- [44]
			"37504^|cffffff0040g", -- [45]
			"35322^|cffffff009g |cffbfbfbf60s", -- [46]
			"35323^|cffffff009g |cffbfbfbf60s", -- [47]
			"35325^|cffffff009g |cffbfbfbf60s", -- [48]
			["POS"] = "3006^48.798856139183^41.238448023796",
			["T"] = 1243937730,
		},
		["?~Almaador"] = {
			"25904^|cffffff009g |cffbfbfbf60s", -- [1]
			"28273^|cffffff004g |cffbfbfbf80s", -- [2]
			"33155^|cffffff009g |cffbfbfbf60s", -- [3]
			"29717^|cffffff009g |cffbfbfbf60s", -- [4]
			"29195^|cffffff0080g", -- [5]
			"30634^|cffffff008g", -- [6]
			"22915^|cffffff006g |cffbfbfbf40s", -- [7]
			"22537^|cffffff008g", -- [8]
			"30826^|cffffff009g |cffbfbfbf60s", -- [9]
			"33159^|cffffff009g |cffbfbfbf60s", -- [10]
			"24182^|cffffff009g |cffbfbfbf60s", -- [11]
			"29180^|cffffff0010g |cffbfbfbf42s |cff7f7f0030c", -- [12]
			"29179^|cffffff0014g |cffbfbfbf7s |cff7f7f0062c", -- [13]
			"28281^|cffffff004g |cffbfbfbf80s", -- [14]
			"13517^|cffffff006g |cffbfbfbf40s", -- [15]
			"29191^|cffffff0080g", -- [16]
			"31354^|cffffff003g |cffbfbfbf20s", -- [17]
			"33153^|cffffff008g", -- [18]
			"29177^|cffffff0063g |cffbfbfbf20s |cff7f7f0090c", -- [19]
			"29176^|cffffff00107g |cffbfbfbf59s |cff7f7f0042c", -- [20]
			"29175^|cffffff00160g |cffbfbfbf29s |cff7f7f0020c", -- [21]
			"31781^|cffbfbfbf80s", -- [22]
			"35333^|cffffff0010g |cffbfbfbf62s |cff7f7f0078c", -- [23]
			"35341^|cffffff0010g |cffbfbfbf93s |cff7f7f0082c", -- [24]
			["T"] = 1243061257,
			["POS"] = "3006^51.321470737457^41.768300533295",
		},
		["?~Master Smith Burninate"] = {
			"159^|cff7f7f0020c", -- [1]
			"1205^|cffbfbfbf4s", -- [2]
			"1708^|cffbfbfbf8s", -- [3]
			"1645^|cffbfbfbf16s", -- [4]
			"4498^|cffbfbfbf20s", -- [5]
			"4497^|cffffff001g |cffbfbfbf60s", -- [6]
			"2515^|cff7f7f0040c", -- [7]
			"3030^|cffbfbfbf2s |cff7f7f0040c", -- [8]
			"11285^|cffbfbfbf8s", -- [9]
			"28053^|cffbfbfbf12s |cff7f7f0080c", -- [10]
			"2519^|cff7f7f0040c", -- [11]
			"3033^|cffbfbfbf2s |cff7f7f0040c", -- [12]
			"11284^|cffbfbfbf8s", -- [13]
			"28060^|cffbfbfbf12s |cff7f7f0080c", -- [14]
			"4470^|cff7f7f0030c", -- [15]
			"4471^|cffbfbfbf1s |cff7f7f008c", -- [16]
			"25873^|cff7f7f0060c", -- [17]
			"25875^|cffbfbfbf1s |cff7f7f0060c", -- [18]
			"25876^|cffbfbfbf6s |cff7f7f0040c", -- [19]
			"29013^|cffbfbfbf6s |cff7f7f0040c", -- [20]
			"29009^|cffbfbfbf1s |cff7f7f0060c", -- [21]
			"29010^|cffbfbfbf6s |cff7f7f0040c", -- [22]
			"29014^|cffbfbfbf6s |cff7f7f0040c", -- [23]
			"117^|cff7f7f0020c", -- [24]
			"2287^|cffbfbfbf1s", -- [25]
			"3770^|cffbfbfbf4s", -- [26]
			"3771^|cffbfbfbf8s", -- [27]
			"4599^|cffbfbfbf16s", -- [28]
			"8952^|cffbfbfbf32s", -- [29]
			"1179^|cffbfbfbf1s", -- [30]
			"8766^|cffbfbfbf32s", -- [31]
			"2901^|cff7f7f0065c", -- [32]
			"5956^|cff7f7f0014c", -- [33]
			"2880^|cff7f7f0080c", -- [34]
			"3466^|cffbfbfbf16s", -- [35]
			"18567^|cffffff0012g", -- [36]
			"3857^|cffbfbfbf4s", -- [37]
			["T"] = 1243836896,
			["POS"] = "2017^38.660031557083^28.334864974022",
			["R"] = 1,
		},
		["?~Kaja"] = {
			"5441^|cffbfbfbf8s", -- [1]
			"2509^|cffbfbfbf3s |cff7f7f0031c", -- [2]
			"2511^|cffbfbfbf10s |cff7f7f0059c", -- [3]
			"2516^|cff7f7f008c", -- [4]
			"2519^|cff7f7f0040c", -- [5]
			"3023^|cffbfbfbf30s |cff7f7f0018c", -- [6]
			"3024^|cffbfbfbf56s |cff7f7f0078c", -- [7]
			"3025^|cffffff001g |cffbfbfbf47s |cff7f7f0083c", -- [8]
			"3033^|cffbfbfbf2s |cff7f7f0040c", -- [9]
			"11284^|cffbfbfbf8s", -- [10]
			"28060^|cffbfbfbf12s |cff7f7f0080c", -- [11]
			["T"] = 1244291536,
			["POS"] = "1014^52.333235740662^62.381625175476",
			["R"] = 1,
		},
		["?~Griftah"] = {
			"27978^|cffbfbfbf80s", -- [1]
			"27992^|cffffff004g", -- [2]
			"27979^|cffffff008g", -- [3]
			"27945^|cffffff0012g", -- [4]
			"27941^|cffffff0016g", -- [5]
			"27976^|cffffff0020g", -- [6]
			"27982^|cffffff0024g", -- [7]
			"27944^|cffffff0028g", -- [8]
			"27940^|cffffff0032g", -- [9]
			"34249^|cffffff0080g", -- [10]
			["POS"] = "3006^65.656101703644^69.01273727417",
			["T"] = 1242997230,
		},
		["?~Veynna Dawnstar"] = {
			"30152^|r1 Helm Token", -- [1]
			"30161^|r1 Helm Token", -- [2]
			"30150^|r1 Chestguard Token", -- [3]
			"30159^|r1 Chestguard Token", -- [4]
			"30153^|r1 Leggings Token", -- [5]
			"30162^|r1 Leggings Token", -- [6]
			"30154^|r1 Pauldrons Token", -- [7]
			"30163^|r1 Pauldrons Token", -- [8]
			"30151^|r1 Gloves Token", -- [9]
			"30160^|r1 Gloves Token", -- [10]
			["POS"] = "3006^44.919407367706^91.414642333984",
			["T"] = 1243937544,
		},
		["?~Bar Talet"] = {
			"30758^|cffffff0010g |cffbfbfbf33s |cff7f7f0077c", -- [1]
			"30757^|cffffff0010g |cffbfbfbf42s |cff7f7f0057c", -- [2]
			"30759^|cffffff0010g |cffbfbfbf24s |cff7f7f0098c", -- [3]
			["POS"] = "3007^49.28323328495^45.65070271492",
			["T"] = 1243947310,
			["R"] = 1,
		},
		["?~Garyl"] = {
			"5976^|cffffff001g", -- [1]
			"31779^|cffffff001g", -- [2]
			"31804^|cffffff001g", -- [3]
			"31776^|cffffff001g", -- [4]
			"31777^|cffffff001g", -- [5]
			"31778^|cffffff001g", -- [6]
			"32828^|r10 Apexis Shard", -- [7]
			"31780^|cffffff001g", -- [8]
			"31781^|cffffff001g", -- [9]
			"32445^|cffffff001g", -- [10]
			"31775^|r10 INV_Mushroom_02", -- [11]
			"35221^|cffffff001g", -- [12]
			"31773^|cffffff001g", -- [13]
			"24004^|cffffff001g", -- [14]
			"19505^|r60 WG", -- [15]
			"19031^|r60 AV", -- [16]
			"15197^|r3 AB |r3 WG", -- [17]
			"15199^|r20 AV |r20 AB |r20 WG", -- [18]
			["POS"] = "1014^43.837252259254^74.611419439316",
			["T"] = 1243472751,
		},
		["?~Nasmara Moonsong"] = {
			"21895^|cffffff003g |cffbfbfbf20s", -- [1]
			"21916^|cffffff004g |cffbfbfbf80s", -- [2]
			"21918^|cffffff004g |cffbfbfbf80s", -- [3]
			"21917^|cffffff004g |cffbfbfbf80s", -- [4]
			"21919^|cffffff004g |cffbfbfbf80s", -- [5]
			["POS"] = "3006^66.32404923439^68.880748748779",
			["T"] = 1242997240,
		},
		["?~Provisioner Ameenah"] = {
			"17034^|cffbfbfbf2s", -- [1]
			"17035^|cffbfbfbf4s", -- [2]
			"17036^|cffbfbfbf8s", -- [3]
			"17037^|cffbfbfbf14s", -- [4]
			"17038^|cffbfbfbf20s", -- [5]
			"22147^|cffbfbfbf50s", -- [6]
			"17031^|cffbfbfbf10s", -- [7]
			"17032^|cffbfbfbf20s", -- [8]
			"17020^|cffbfbfbf10s", -- [9]
			"17030^|cffbfbfbf20s", -- [10]
			"17033^|cffbfbfbf20s", -- [11]
			"17028^|cffbfbfbf7s", -- [12]
			"17029^|cffbfbfbf10s", -- [13]
			"17021^|cffbfbfbf7s", -- [14]
			"17026^|cffbfbfbf10s", -- [15]
			"22148^|cffbfbfbf15s", -- [16]
			"5565^|cffbfbfbf50s", -- [17]
			"16583^|cffffff001g", -- [18]
			"21177^|cffbfbfbf30s", -- [19]
			"37201^|cffbfbfbf50s", -- [20]
			["T"] = 1242741301,
			["POS"] = "2012^70.577150583267^69.423818588257",
		},
		["?~Tarban Hearthgrain"] = {
			"4540^|cff7f7f0025c", -- [1]
			"4541^|cffbfbfbf1s |cff7f7f0025c", -- [2]
			"4542^|cffbfbfbf5s", -- [3]
			"4544^|cffbfbfbf10s", -- [4]
			"4601^|cffbfbfbf20s", -- [5]
			"8950^|cffbfbfbf40s", -- [6]
			"159^|cff7f7f0025c", -- [7]
			"30817^|cff7f7f0025c", -- [8]
			"2678^|cff7f7f0010c", -- [9]
			"2692^|cff7f7f0040c", -- [10]
			"3713^|cffbfbfbf1s |cff7f7f0060c", -- [11]
			"21099^|cffbfbfbf5s", -- [12]
			"21219^|cffbfbfbf50s", -- [13]
			["POS"] = "1019^55.124151706696^32.059690356255",
			["T"] = 1243690983,
		},
		["?~Apprentice Darius"] = {
			"33205^|cffffff0019g |cffbfbfbf20s", -- [1]
			"29187^|cffffff0024g", -- [2]
			"33209^|cffffff003g |cffbfbfbf20s", -- [3]
			"31401^|cffffff009g |cffbfbfbf60s", -- [4]
			"34581^|cffbfbfbf80s", -- [5]
			"34582^|cffbfbfbf80s", -- [6]
			"33165^|cffffff002g |cffbfbfbf40s", -- [7]
			"33124^|cffffff004g", -- [8]
			["POS"] = "2006^46.871018409729^75.428247451782",
			["T"] = 1243324712,
		},
		["?~Raider Bork"] = {
			"29466^|r30 AV |r30 AB |r30 WG", -- [1]
			"29469^|r30 AV |r30 AB |r30 WG", -- [2]
			"29470^|r30 AV |r30 AB |r30 WG", -- [3]
			"29472^|r30 AV |r30 AB |r30 WG", -- [4]
			"34129^|r30 AV |r30 AB |r30 WG", -- [5]
			["T"] = 1243311128,
			["POS"] = "1014^38.013163208961^64.319586753845",
		},
		["?~Arrond"] = {
			"2320^|cff7f7f008c", -- [1]
			"2321^|cff7f7f0080c", -- [2]
			"4291^|cffbfbfbf4s", -- [3]
			"8343^|cffbfbfbf16s", -- [4]
			"14341^|cffbfbfbf40s", -- [5]
			"38426^|cffffff002g |cffbfbfbf40s", -- [6]
			"2324^|cff7f7f0020c", -- [7]
			"2604^|cff7f7f0040c", -- [8]
			"6260^|cff7f7f0040c", -- [9]
			"2605^|cff7f7f0080c", -- [10]
			"4341^|cffbfbfbf4s", -- [11]
			"4340^|cffbfbfbf2s |cff7f7f0080c", -- [12]
			"6261^|cffbfbfbf8s", -- [13]
			"2325^|cffbfbfbf8s", -- [14]
			"4342^|cffbfbfbf20s", -- [15]
			"10290^|cffbfbfbf20s", -- [16]
			"21900^|cffffff004g |cffbfbfbf80s", -- [17]
			"21901^|cffffff004g |cffbfbfbf80s", -- [18]
			["POS"] = "3005^55.96861243248^58.182048797607",
			["T"] = 1243945169,
		},
		["?~Snack-O-Matic IV"] = {
			"159^|cff7f7f0025c", -- [1]
			"1179^|cffbfbfbf1s |cff7f7f0025c", -- [2]
			"1205^|cffbfbfbf5s", -- [3]
			"1708^|cffbfbfbf10s", -- [4]
			"1645^|cffbfbfbf20s", -- [5]
			"8766^|cffbfbfbf40s", -- [6]
			"7228^|cffbfbfbf5s", -- [7]
			"2070^|cff7f7f0025c", -- [8]
			"414^|cffbfbfbf1s |cff7f7f0025c", -- [9]
			"422^|cffbfbfbf5s", -- [10]
			"1707^|cffbfbfbf10s", -- [11]
			"3927^|cffbfbfbf20s", -- [12]
			"8932^|cffbfbfbf40s", -- [13]
			"4540^|cff7f7f0025c", -- [14]
			"4541^|cffbfbfbf1s |cff7f7f0025c", -- [15]
			"4542^|cffbfbfbf5s", -- [16]
			"4544^|cffbfbfbf10s", -- [17]
			"4601^|cffbfbfbf20s", -- [18]
			"8950^|cffbfbfbf40s", -- [19]
			"4536^|cff7f7f0025c", -- [20]
			"4537^|cffbfbfbf1s |cff7f7f0025c", -- [21]
			"4538^|cffbfbfbf5s", -- [22]
			"4539^|cffbfbfbf10s", -- [23]
			"4602^|cffbfbfbf20s", -- [24]
			"8953^|cffbfbfbf40s", -- [25]
			["T"] = 1242732153,
			["POS"] = "1008^50.347745418549^12.690488994122",
		},
		["?~Spirit Sage Gartok"] = {
			"32947^|r2 INV_Jewelry_FrostwolfTrinket_04", -- [1]
			"32948^|r2 INV_Jewelry_FrostwolfTrinket_04", -- [2]
			"28553^|r50 INV_Jewelry_FrostwolfTrinket_04", -- [3]
			"28555^|r50 INV_Jewelry_FrostwolfTrinket_04", -- [4]
			"28559^|r18 INV_Jewelry_FrostwolfTrinket_04", -- [5]
			"28560^|r18 INV_Jewelry_FrostwolfTrinket_04", -- [6]
			"28761^|r18 INV_Jewelry_FrostwolfTrinket_04", -- [7]
			"28576^|r18 INV_Jewelry_FrostwolfTrinket_04", -- [8]
			"28577^|r18 INV_Jewelry_FrostwolfTrinket_04", -- [9]
			"28758^|r18 INV_Jewelry_FrostwolfTrinket_04", -- [10]
			"28561^|r18 INV_Jewelry_FrostwolfTrinket_04", -- [11]
			"28574^|r18 INV_Jewelry_FrostwolfTrinket_04", -- [12]
			"28575^|r18 INV_Jewelry_FrostwolfTrinket_04", -- [13]
			"28760^|r18 INV_Jewelry_FrostwolfTrinket_04", -- [14]
			"28759^|r18 INV_Jewelry_FrostwolfTrinket_04", -- [15]
			"28556^|r8 INV_Jewelry_FrostwolfTrinket_04", -- [16]
			"28557^|r8 INV_Jewelry_FrostwolfTrinket_04", -- [17]
			["T"] = 1243766458,
			["POS"] = "3007^49.834194779396^46.67284488678",
		},
		["?~Arcanist Xorith"] = {
			"32898^|r1 Spell_Shadow_Metamorphosis", -- [1]
			"32899^|r1 Spell_Shadow_Metamorphosis", -- [2]
			"32901^|r1 Spell_Shadow_Metamorphosis", -- [3]
			"32900^|r1 Spell_Shadow_Metamorphosis", -- [4]
			"35716^|r1 Spell_Shadow_Metamorphosis", -- [5]
			"35717^|r1 Spell_Shadow_Metamorphosis", -- [6]
			["T"] = 1244025627,
			["POS"] = "3006^60.567432641983^63.363617658615",
		},
		["?~Ythyar"] = {
			"17037^|cffbfbfbf11s |cff7f7f0020c", -- [1]
			"17038^|cffbfbfbf16s", -- [2]
			"22147^|cffbfbfbf40s", -- [3]
			"17031^|cffbfbfbf8s", -- [4]
			"17032^|cffbfbfbf16s", -- [5]
			"17020^|cffbfbfbf8s", -- [6]
			"17030^|cffbfbfbf16s", -- [7]
			"17033^|cffbfbfbf16s", -- [8]
			"17028^|cffbfbfbf5s |cff7f7f0060c", -- [9]
			"17029^|cffbfbfbf8s", -- [10]
			"17021^|cffbfbfbf5s |cff7f7f0060c", -- [11]
			"17026^|cffbfbfbf8s", -- [12]
			"22148^|cffbfbfbf12s", -- [13]
			"5565^|cffbfbfbf40s", -- [14]
			"16583^|cffbfbfbf80s", -- [15]
			"21177^|cffbfbfbf24s", -- [16]
			"37201^|cffbfbfbf40s", -- [17]
			"25902^|cffffff009g |cffbfbfbf60s", -- [18]
			"25903^|cffffff009g |cffbfbfbf60s", -- [19]
			"22535^|cffffff008g", -- [20]
			["POS"] = "12058^46.745145320892^74.500066041946",
			["T"] = 1243329014,
			["R"] = 1,
		},
		["?~Quartermaster Jaffrey Noreliqe"] = {
			"32071^|r2 Research Token", -- [1]
			"33783^|r4 Research Token", -- [2]
			"27644^|r20 Battle Token |r1 Research Token", -- [3]
			"27654^|r40 Battle Token |r2 Research Token", -- [4]
			"27646^|r20 Battle Token |r1 Research Token", -- [5]
			"27647^|r40 Battle Token |r2 Research Token", -- [6]
			"27638^|r20 Battle Token |r1 Research Token", -- [7]
			"27649^|r40 Battle Token |r2 Research Token", -- [8]
			"27637^|r20 Battle Token |r1 Research Token", -- [9]
			"27650^|r40 Battle Token |r2 Research Token", -- [10]
			"27639^|r20 Battle Token |r1 Research Token", -- [11]
			"27653^|r40 Battle Token |r2 Research Token", -- [12]
			"27643^|r20 Battle Token |r1 Research Token", -- [13]
			"27652^|r40 Battle Token |r2 Research Token", -- [14]
			"27645^|r20 Battle Token |r1 Research Token", -- [15]
			"27648^|r40 Battle Token |r2 Research Token", -- [16]
			"27680^|r8 Research Token", -- [17]
			"27679^|r100 Battle Token", -- [18]
			["POS"] = "3003^41.258987784386^44.300058484077",
			["T"] = 1242657617,
		},
		["?~Matron Tikkit"] = {
			"8952^|cffbfbfbf32s", -- [1]
			"27854^|cffbfbfbf44s |cff7f7f0080c", -- [2]
			"29451^|cffbfbfbf64s", -- [3]
			"7228^|cffbfbfbf4s", -- [4]
			"8766^|cffbfbfbf32s", -- [5]
			"28399^|cffbfbfbf44s |cff7f7f0080c", -- [6]
			"27860^|cffbfbfbf51s |cff7f7f0020c", -- [7]
			["POS"] = "3003^56.688779592514^34.512382745743",
			["T"] = 1243832802,
		},
		["?~Kerpow Blastwrench"] = {
			"3025^|cffffff001g |cffbfbfbf84s |cff7f7f0079c", -- [1]
			"28060^|cffbfbfbf16s", -- [2]
			"28061^|cffbfbfbf30s", -- [3]
			["POS"] = "3004^66.057544946671^67.287480831146",
			["T"] = 1243933775,
			["R"] = 1,
		},
		["?~Tasaldan"] = {
			"11285^|cffbfbfbf10s", -- [1]
			"28053^|cffbfbfbf16s", -- [2]
			"28056^|cffbfbfbf30s", -- [3]
			"11284^|cffbfbfbf10s", -- [4]
			"28060^|cffbfbfbf16s", -- [5]
			"28061^|cffbfbfbf30s", -- [6]
			"30611^|cffbfbfbf50s", -- [7]
			"30612^|cffbfbfbf50s", -- [8]
			["POS"] = "3003^41.620856523514^43.959522247314",
			["T"] = 1243331349,
		},
		["?~Mahir Redstroke"] = {
			"2526^|cffffff001g |cffbfbfbf54s |cff7f7f0069c", -- [1]
			"2534^|cffffff003g |cffbfbfbf63s |cff7f7f0045c", -- [2]
			"8927^|cffbfbfbf5s |cff7f7f0060c", -- [3]
			"8928^|cffbfbfbf6s |cff7f7f0040c", -- [4]
			"3775^|cff7f7f0056c", -- [5]
			"5237^|cff7f7f0032c", -- [6]
			"8985^|cffbfbfbf2s", -- [7]
			"20844^|cffbfbfbf2s |cff7f7f0040c", -- [8]
			"22053^|cffbfbfbf8s", -- [9]
			"10922^|cffbfbfbf6s |cff7f7f0040c", -- [10]
			"21835^|cffbfbfbf12s", -- [11]
			["T"] = 1242768957,
			["POS"] = "3006^54.451817274094^82.424259185791",
			["R"] = 1,
		},
		["?~Trak'gen"] = {
			"4540^|cff7f7f0025c", -- [1]
			"159^|cff7f7f0025c", -- [2]
			"2512^|cff7f7f0010c", -- [3]
			"2516^|cff7f7f0010c", -- [4]
			"25861^|cff7f7f0015c", -- [5]
			"28979^|cff7f7f0015c", -- [6]
			"4496^|cffbfbfbf5s", -- [7]
			"4498^|cffbfbfbf25s", -- [8]
			"4470^|cff7f7f0038c", -- [9]
			"4471^|cffbfbfbf1s |cff7f7f0035c", -- [10]
			"5042^|cff7f7f0050c", -- [11]
			"29007^|cff7f7f0030c", -- [12]
			"25872^|cff7f7f0030c", -- [13]
			"1179^|cffbfbfbf1s |cff7f7f0025c", -- [14]
			"2515^|cff7f7f0050c", -- [15]
			"2519^|cff7f7f0050c", -- [16]
			"1205^|cffbfbfbf5s", -- [17]
			"5048^|cff7f7f0050c", -- [18]
			"25873^|cff7f7f0075c", -- [19]
			"29008^|cff7f7f0075c", -- [20]
			"4497^|cffffff002g", -- [21]
			"3030^|cffbfbfbf3s", -- [22]
			"3033^|cffbfbfbf3s", -- [23]
			"29009^|cffbfbfbf2s", -- [24]
			"25875^|cffbfbfbf2s", -- [25]
			"1708^|cffbfbfbf10s", -- [26]
			"1645^|cffbfbfbf20s", -- [27]
			"11285^|cffbfbfbf10s", -- [28]
			"28053^|cffbfbfbf16s", -- [29]
			"11284^|cffbfbfbf10s", -- [30]
			"28060^|cffbfbfbf16s", -- [31]
			"25876^|cffbfbfbf8s", -- [32]
			"29013^|cffbfbfbf8s", -- [33]
			"29010^|cffbfbfbf8s", -- [34]
			"29014^|cffbfbfbf8s", -- [35]
			["POS"] = "1014^48.016455769539^80.39225935936",
			["T"] = 1243472457,
		},
		["?~Horde Field Scout"] = {
			"27928^|r15 Thrallmar Token", -- [1]
			"27930^|r15 Thrallmar Token", -- [2]
			"27939^|r15 Thrallmar Token", -- [3]
			"27949^|r15 Thrallmar Token", -- [4]
			"27947^|r15 Thrallmar Token", -- [5]
			"27989^|r15 Thrallmar Token", -- [6]
			"27924^|r30 Thrallmar Token", -- [7]
			["POS"] = "3008^32.92487859726^48.876863718033",
			["T"] = 1242897069,
		},
		["?~Jim Saltit"] = {
			"159^|cff7f7f0020c", -- [1]
			"30817^|cff7f7f0020c", -- [2]
			"2678^|cff7f7f008c", -- [3]
			"2692^|cff7f7f0032c", -- [4]
			"3713^|cffbfbfbf1s |cff7f7f0028c", -- [5]
			"21099^|cffbfbfbf4s", -- [6]
			"21219^|cffbfbfbf40s", -- [7]
			["POS"] = "3006^63.490056991577^68.730562925339",
			["T"] = 1242997289,
		},
		["?~Inscriber Veredis"] = {
			"28907^|r2 Arcane Rune", -- [1]
			"28908^|r2 Arcane Rune", -- [2]
			"28904^|r2 Arcane Rune", -- [3]
			"28903^|r2 Arcane Rune", -- [4]
			"28910^|r8 Arcane Rune", -- [5]
			"28911^|r8 Arcane Rune", -- [6]
			"28912^|r8 Arcane Rune", -- [7]
			"28909^|r8 Arcane Rune", -- [8]
			["POS"] = "3006^59.799230098724^63.957345485687",
			["T"] = 1243938853,
		},
		["?~Wind Trader Lathrai"] = {
			"23816^|cffffff004g", -- [1]
			"23815^|cffffff006g", -- [2]
			"23811^|cffffff006g", -- [3]
			"5956^|cff7f7f0018c", -- [4]
			"2901^|cff7f7f0081c", -- [5]
			"4399^|cffbfbfbf2s", -- [6]
			"4400^|cffbfbfbf20s", -- [7]
			"40533^|cffffff005g", -- [8]
			"39684^|cffbfbfbf90s", -- [9]
			"2880^|cffbfbfbf1s", -- [10]
			"3466^|cffbfbfbf20s", -- [11]
			"10648^|cffbfbfbf1s |cff7f7f0025c", -- [12]
			"10647^|cffbfbfbf20s", -- [13]
			"4361^|cffbfbfbf4s |cff7f7f0080c", -- [14]
			"4371^|cffbfbfbf8s", -- [15]
			"4363^|cffbfbfbf2s", -- [16]
			"4357^|cff7f7f0016c", -- [17]
			"4364^|cff7f7f0048c", -- [18]
			["T"] = 1242836392,
			["POS"] = "3006^72.325623035431^30.902454257011",
		},
		["?~Rin'wosho the Trader"] = {
			"19766^|cffffff004g", -- [1]
			"19771^|cffffff004g", -- [2]
			"19778^|cffffff004g", -- [3]
			"19781^|cffffff004g", -- [4]
			"20001^|cffffff004g", -- [5]
			"20012^|cffffff004g", -- [6]
			"20757^|cffffff003g |cffbfbfbf20s", -- [7]
			"19765^|cffffff004g", -- [8]
			"19770^|cffffff004g", -- [9]
			"19773^|cffffff004g", -- [10]
			"19777^|cffffff004g", -- [11]
			"19780^|cffffff004g", -- [12]
			"20000^|cffffff009g |cffbfbfbf60s", -- [13]
			"20014^|cffffff004g", -- [14]
			"20756^|cffffff003g |cffbfbfbf20s", -- [15]
			"19764^|cffffff004g", -- [16]
			"19769^|cffffff004g", -- [17]
			"19772^|cffffff004g", -- [18]
			"19776^|cffffff004g", -- [19]
			"19779^|cffffff004g", -- [20]
			"20011^|cffffff004g", -- [21]
			"20013^|cffffff004g", -- [22]
			["POS"] = "2021^15.107162296772^16.039906442165",
			["T"] = 1243836482,
			["R"] = 1,
		},
		["?~Mortog Steamhead"] = {
			"32904^|r1 INV_Spear_06", -- [1]
			"32903^|r1 INV_Spear_06", -- [2]
			"8927^|cffbfbfbf5s |cff7f7f0060c", -- [3]
			"8928^|cffbfbfbf6s |cff7f7f0040c", -- [4]
			"3775^|cff7f7f0056c", -- [5]
			"5237^|cff7f7f0032c", -- [6]
			"8985^|cffbfbfbf2s", -- [7]
			"20844^|cffbfbfbf2s |cff7f7f0040c", -- [8]
			"22053^|cffbfbfbf8s", -- [9]
			"10922^|cffbfbfbf6s |cff7f7f0040c", -- [10]
			"21835^|cffbfbfbf12s", -- [11]
			"11285^|cffbfbfbf8s", -- [12]
			"28053^|cffbfbfbf12s |cff7f7f0080c", -- [13]
			"28056^|cffbfbfbf24s", -- [14]
			"11284^|cffbfbfbf8s", -- [15]
			"28060^|cffbfbfbf12s |cff7f7f0080c", -- [16]
			"28061^|cffbfbfbf24s", -- [17]
			"17037^|cffbfbfbf11s |cff7f7f0020c", -- [18]
			"17038^|cffbfbfbf16s", -- [19]
			"22147^|cffbfbfbf40s", -- [20]
			"17031^|cffbfbfbf8s", -- [21]
			"17032^|cffbfbfbf16s", -- [22]
			"17020^|cffbfbfbf8s", -- [23]
			"17030^|cffbfbfbf16s", -- [24]
			"17033^|cffbfbfbf16s", -- [25]
			"17028^|cffbfbfbf5s |cff7f7f0060c", -- [26]
			"17029^|cffbfbfbf8s", -- [27]
			"17021^|cffbfbfbf5s |cff7f7f0060c", -- [28]
			"17026^|cffbfbfbf8s", -- [29]
			"22148^|cffbfbfbf12s", -- [30]
			"5565^|cffbfbfbf40s", -- [31]
			"16583^|cffbfbfbf80s", -- [32]
			"21177^|cffbfbfbf24s", -- [33]
			"37201^|cffbfbfbf40s", -- [34]
			["T"] = 1244091753,
			["POS"] = "3008^51.521956920624^35.471397638321",
			["R"] = 1,
		},
		["?~First Sergeant Hola'mahi"] = {
			"22859^|cffff70a02805 honor |r20 AB", -- [1]
			"22869^|cffff70a02805 honor |r20 AV", -- [2]
			"22882^|cffff70a04335 honor |r30 WG", -- [3]
			"22885^|cffff70a04590 honor |r30 AB", -- [4]
			"23262^|cffff70a02805 honor |r20 AB", -- [5]
			"23261^|cffff70a04335 honor |r30 AV", -- [6]
			"17618^|cffff70a08415 honor |r20 AB", -- [7]
			"17620^|cffff70a08415 honor |r20 AV", -- [8]
			"17624^|cffff70a013770 honor |r30 AB", -- [9]
			"17625^|cffff70a013005 honor |r30 WG", -- [10]
			"17623^|cffff70a013005 honor |r30 AV", -- [11]
			"17622^|cffff70a08415 honor |r20 AB", -- [12]
			["T"] = 1243311306,
			["POS"] = "1014^38.105520606041^64.37441110611",
		},
		["?~Kevin Browning"] = {
			"33042^|cffbfbfbf64s", -- [1]
			["T"] = 1243984051,
			["POS"] = "3006^68.133598566055^60.426598787308",
		},
		["?~Dama Wildmane"] = {
			"25474^|cffffff00100g", -- [1]
			"25475^|cffffff00100g", -- [2]
			"25476^|cffffff00100g", -- [3]
			"25531^|cffffff00200g", -- [4]
			"25533^|cffffff00200g", -- [5]
			"25477^|cffffff00200g", -- [6]
			"25532^|cffffff00200g", -- [7]
			["T"] = 1243566998,
			["POS"] = "3005^29.153195023537^29.53813970089",
		},
		["?~Coreiel"] = {
			"2526^|cffffff001g |cffbfbfbf93s |cff7f7f0036c", -- [1]
			"2534^|cffffff004g |cffbfbfbf54s |cff7f7f0031c", -- [2]
			"2520^|cffffff002g |cffbfbfbf46s |cff7f7f0029c", -- [3]
			"2528^|cffffff005g |cffbfbfbf18s |cff7f7f0036c", -- [4]
			"2521^|cffffff003g |cffbfbfbf8s |cff7f7f0096c", -- [5]
			"2529^|cffffff006g |cffbfbfbf50s |cff7f7f0032c", -- [6]
			"30569^|cffffff001g |cffbfbfbf81s |cff7f7f0066c", -- [7]
			"30571^|cffffff0014g |cffbfbfbf9s |cff7f7f0072c", -- [8]
			"28915^|r70 Battle Token |r15 Research Token", -- [9]
			"29228^|r100 Battle Token |r20 Research Token", -- [10]
			"24208^|cffffff0012g", -- [11]
			["T"] = 1244302301,
			["POS"] = "3003^42.855229973793^42.558568716049",
			["R"] = 1,
		},
		["?~Osrok the Immovable"] = {
			"2901^|cff7f7f0065c", -- [1]
			"5956^|cff7f7f0014c", -- [2]
			"2880^|cff7f7f0080c", -- [3]
			"3466^|cffbfbfbf16s", -- [4]
			"18567^|cffffff0012g", -- [5]
			"3857^|cffbfbfbf4s", -- [6]
			"30777^|cffffff004g |cffbfbfbf74s |cff7f7f004c", -- [7]
			"30771^|cffffff005g |cffbfbfbf20s |cff7f7f0026c", -- [8]
			"30765^|cffffff0010g |cffbfbfbf12s |cff7f7f0086c", -- [9]
			"30775^|cffffff008g |cffbfbfbf68s |cff7f7f0076c", -- [10]
			"30781^|cffffff008g |cffbfbfbf8s |cff7f7f002c", -- [11]
			"30784^|cffffff004g |cffbfbfbf4s |cff7f7f001c", -- [12]
			["T"] = 1244291076,
			["POS"] = "3003^56.022489070892^37.302255630493",
			["R"] = 1,
		},
	},
	["Version"] = 0.02,
	["NXCap"] = {
		["Q"] = {
			[22313] = "0Apprentice Morlann#5c30^462875f92f~Apprentice Morlann#5c30^2875d92e~287697fe76e7ef76e7f57727ea7767bb7777ba7747aa784787774770774770768765762750",
			[22361] = "0Mordant Grimsby#5d23^46288e0430~Mordant Grimsby#5d23^288e042f~288d13d48e53d89143ff9203e19143bc9273a093437c92f352917369903358",
			[6125] = "0Talo Thornhoof#1e60^462ec2b6ff~Talo Thornhoof#1e60^2ec2a6ff~2e67d15d",
			[12323] = "0Rackmore's Log#o2b67b^46235c44d8~Rackmore's Chest#o2b67a^234c8164~235694e0~2346b13b",
			[10285] = "0Marlene Redpath#2aaf^466f7d7c9b~Pamela Redpath#2aae^2952fd5c",
			[8247] = "0Maxwort Uberglint#2540^4616a6b3cb~~",
			[16511] = "0Ogtinc#20d5^460a6c46d1~Ogtinc#20d5^0a6c56d3~0a9c0347a082e3a182eea2a304",
			[10317] = "0Greta Mosshoof#2aaa^462d82ed1c~Islen Waterseer#170d^61a856fe",
			[16559] = "0Hermit Ortell#3b5a^4650abbb25~Hermit Ortell#3b5a^50abab25~5043d5d2~50294de3~5068c6af",
			[16575] = "0Hermit Ortell#3b5a^4650abab25~Commander Mar'alith#3b4d^507db578",
			[22745] = "0p^46609f37ff~Wind Trader Zhareem#5f31^4fbfa5e0~08731a7b",
			[22777] = "0Wind Trader Zhareem#5f31^464fbf75e9~~",
			[16703] = "0Aurel Goldleaf#3bb2^465084a612~Bor Wildmane#3bca^507c4604",
			[1049] = "0Apothecary Lydon#8a8^46389d230d~Dusty Rug#o6c0^38a08302@500 41",
			[65] = "0Senior Surveyor Fizzledowser#1e2c^4659806462~Zilzibin Drumlore#1b62^4490576b@350 11",
			[6249] = "0Witch Doctor Uzer'i#1fb3^462ebe56ee~Witch Doctor Uzer'i#1fb3^2ebe46ed~2e8e79cc8d89e88e09ea8df9ad8f7a2e8f0a318dea3b8cea4a8cea4c8dea69",
			[6253] = "0Witch Doctor Uzer'i#1fb3^462ebe56ef~Witch Doctor Uzer'i#1fb3^2ebe56ef~2ebb382fb65941b096fa",
			[10485] = "0Greta Mosshoof#2aaa^462d831d21~Greta Mosshoof#2aaa^2d82fd1d~2d64177f~2d64177f~2d636779",
			[529] = "0Clarice Foster#15a7^466849b42d~Yuriv's Tombstone#o60c8^527136cd",
			[2117] = "0Witch Doctor Jin'Zil#f9b^4653be8fa4~Witch Doctor Jin'Zil#f9b^53be9fa4@250 a~538075aa82a63466c27856f1f15c22f1~535521a450f1cc50c1cf50a1aa541147~5377f4b87774687664547463eb70c4287133b772e39573136671d35275437266620d6391f864e1c95fe2a25c329f~53656223",
			[2121] = "0Darsok Swiftdagger#d79^466183f4f0~Witch Doctor Jin'Zil#f9b^53be8fa5@250 a",
			[12603] = "0Tammra Windfield#2e58^4653791955~Tammra Windfield#2e58^53796955@150 3e~537d37007f07337ad7157526e27586837666527ab6598036458195d88105f1",
			[2133] = "0Apothecary Lydon#8a8^46389d330e~Apothecary Lydon#8a8^389d1310@63 25~38aa975caa8802a747c6acd7aeaa7803",
			[2135] = "0Apothecary Lydon#8a8^46389d2311~Apothecary Zamah#d5b^683a734b@38 25",
			[12643] = "0Deathguard Podrig#18f5^46526f36ac~Karos Razok#8b2^527486ce@25 41",
			[8583] = "0Torwa Pathfinder#2593^466bb75c21~Torwa Pathfinder#2593^6bb74c23~6baacb8aaaaa00",
			[23337] = "0Old Man Barlo#63ec^466062f206~Old Man Barlo#63ec^6063020f~73c86abbc86abbc86abbc86abbc86abbc86abbc86abb",
			[12763] = "0Tammra Windfield#2e58^4653797955~Tammra Windfield#2e58^53793955@250 3e~53582b0d55db09560b4d52ab374d2ad24ecaa6563ba5581b0f561aba4ddbcb",
			[2173] = "0Apothecary Zamah#d5b^46683b435a~Apothecary Zamah#d5b^683ac351@88 25~53a9c745",
			[2177] = "0Braelyn Firehand#1066^46537579a8~Braelyn Firehand#1066^537579a3~059ec834",
			[2179] = "0Braelyn Firehand#1066^46537579a3~Talon Den Hoard#o4c8f^534431bc~534151d2~534b628a~53475234",
			[12803] = "0Makaba Flathoof#2e51^46615a046e~Tammra Windfield#2e58^53795957",
			[17471] = "0Keeper Remulos#2e38^463e5ce6b0~~~~~",
			[2193] = "0Ziz Fizziks#1069^465396da00~Ziz Fizziks#1069^5396c9ff@250 20~53a27659",
			[2205] = "~Auld Stonespire#1163^685d3988@500 3e~476cae61",
			[2209] = "0Fizzle Brassbolts#1166^4667c77c51~Fizzle Brassbolts#1166^67c76c4f~67baeb2ab7bbd0b70b87b94a7db10a3dc0099e",
			[12923] = "0Xen'Zilla#3210^4653b62f2a~Xen'Zilla#3210^53b62f2c@250 a~53a68d649d5d0b97ac5199ec01975bd9969ba9968c209b5b789a2c44~539b5a8a9cca699c7a5f9c6a3e9c0a2f9cfa179dba0e",
			[2213] = "0Fizzle Brassbolts#1166^4667c76c4f~Martek the Exiled#120a^0c6bd870",
			[2215] = "0Wizzle Brassbolts#1165^4667c7ac4f~Wizzle Brassbolts#1165^67c7ac4e~5545f3a644d3b84533e144f41544842944944644044443542b44f3ce4503b5",
			[2217] = "0Martek the Exiled#120a^460c6bd870~Martek the Exiled#120a^0c6c3864~0c824ada835ac5841aca7fdaf97cab797c0b0d7eda977f1a59a48730a3e6ac",
			[2219] = "~Master Apothecary Faranell#807^6c7c3b1c@125 25~476cae61",
			[2227] = "0Master Apothecary Faranell#807^466c7bdb1d~Master Apothecary Faranell#807^6c7c1b18@125 25~69d245efd2959f",
			[2229] = "0Kravel Koalbeard#1164^4667c6fc59~Fizzle Brassbolts#1166^67c77c52",
			[2231] = "0Kravel Koalbeard#1164^4667c6ec54~Krazek#305^5544fc57",
			[2233] = "0Krazek#305^465544fc57~Krazek#305^55450c57~582b0976276a991e9aa82089802069a41ca9f91f092520797f20aa72274a95",
			[2235] = "0Krazek#305^4655450c57~Kravel Koalbeard#1164^67c6fc5a",
			[2237] = "0Kravel Koalbeard#1164^4667c6fc54~Crank Fizzlebub#9c2^55455c59",
			[2239] = "0Crank Fizzlebub#9c2^4655454c58~Kravel Koalbeard#1164^67c6fc5c",
			[13043] = "~Varimathras#979^6c904ead~617afec6",
			[11005] = "0Orcish Orphan#386c^0d44860b1e~Orphan Matron Battlewail#3873^44b5240e~",
			[2245] = "0Kravel Koalbeard#1164^4667c6ec52~Crank Fizzlebub#9c2^55454c59",
			[2247] = "0Arch Druid Hamuul Runetotem#1689^4668c8748f~Rabine Saturna#2e19^3e84072d",
			[2249] = "0Rabine Saturna#2e19^463e84072d~Layo Starstrike#33a4^50d14301",
			[2251] = "0Layo Starstrike#33a4^4650d12301~Layo Starstrike#33a4^50d11302~50a2f7b2a2e7e2a18824a1381da0881ea048109ad878~50a2d78aa21816a06819a078079ed84c9c98a19b48759c47e6",
			[2253] = "0Layo Starstrike#33a4^4650d11302~Layo Starstrike#33a4^50d13305~509a386a",
			[11053] = "0Rabine Saturna#2e19^463e84172d~~",
			[9015] = "0Alchemist Pestlezugg#15da^465982244f~Alchemist Pestlezugg#15da^5982344f~6b6f6d04",
			[11069] = "0Kim'jael#20e4^460a88837c~Kim'jael#20e4^0a88837b@350 5~0a769791",
			[13123] = "0Argent Guard Thaelrid#12b3^460e238257~Bashana Runetotem#237f^68b54562@500 3e~0e238257",
			[2263] = "0Melor Stonehoof#d71^46689c4cda~Melor Stonehoof#d71^689c7ce8~672604fa",
			[22171] = "0Skyguard Prisoner#5b57^4660bfedc7~Sky Sergeant Doryn#5a08^60a51aa6~60b22c28b28c0bb25c28bcee1b",
			[2273] = "0Melor Stonehoof#d71^46689c6ce2~Melor Stonehoof#d71^689c7cd9~015f7af0",
			[2275] = "0Martek the Exiled#120a^460c6be871~Fizzle Brassbolts#1166^67c7ac4e",
			[13211] = "0Harlo Wigglesworth#2deb^46729c5624~Winna Hazzard#270c^2d57885c@2 25",
			[4567] = "~Dran Droffers#1b4a^449865d6@37 25~6a71b1f4",
			[22347] = "0Apprentice Garion#5c31^4628759921~Apprentice Garion#5c31^28759924~2877f76a6f57bd7007c26b280f6a68276a9835",
			[22363] = "0Mordant Grimsby#5d23^46288e042f~Mordant Grimsby#5d23^288e142f~289143e49433da92038690e3839033a38ad3b889b40b921431900464",
			[13243] = "0Karang Amakkar#31d5^46051e9581~Karang Amakkar#31d5^051e8584~05902a23",
			[22427] = "0Nazeer Bloodpike#12b7^46285a14e7~Tabetha#1992^28759921",
			[2305] = "0Dorn Plainstalker#baa^466789e6a3~Braug Dimspirit#1189^53c9474b",
			[2307] = "0Tatternack Steelforge#d69^4661735939~Tatternack Steelforge#d69^61736938@62 25~6786e6ff",
			[2309] = "0Braug Dimspirit#1189^4653c9474b~Braug Dimspirit#1189^53c93749~05c10be9",
			[18479] = "0Craftsman Wilhelm#3ff8^4629c04894~~~~~",
			[2319] = "0Braug Dimspirit#1189^4653c9374b~Parqual Fintallas#1188^6c936a69",
			[2321] = "0Parqual Fintallas#1188^466c938a64~Parqual Fintallas#1188^6c93aa6a~4ad30567",
			[16513] = "0Ogtinc#20d5^460a6c56d2~Ogtinc#20d5^0a6c56d1~0a2a6ad4",
			[22683] = "0Horde Warbringer#3bf6^464fab9912~~",
			[16561] = "0Windcaller Proudhorn#3b57^465082b61b~Windcaller Proudhorn#3b57^5082d618~508c357e9af54f9bb545a38542a4943a9a84159564a69713b497d36499d23296a24a9361fa8ab1d285a2278452f5",
			[2333] = "0Overlord Mok'Morokk#1194^46285cb509~Overlord Mok'Morokk#1194^285cb507~2871ea91~2862da80~285dab1c",
			[15465] = "0Hadoken Swiftstrider#1ec3^462ebf76cc~Zilzibin Drumlore#1b62^4490476c",
			[2337] = "0Tharg#1196^46285f6504~Tharg#1196^285f6503~28715a5b749a66732ac372db766b5cf475cad8752ab471bac771fa84729a84~28726a5371ba5f731a59746a6e74aa6074dab572db766b5cf475cadb71caa8~287cfbe07c8bf37c1c127bec3087fbb3",
			[2339] = "0Draz'Zilb#1195^46285ed547~Draz'Zilb#1195^285ee548~2872aa48743a6372bb1376fd17762d4d741d5e6d4cf3~28765a81736ae2726be0736ca376fd17762d4d741d5e",
			[2341] = "0Draz'Zilb#1195^46285ee549~Overlord Mok'Morokk#1194^285ce508",
			[2343] = "0Overlord Mok'Morokk#1194^46285ce508~Draz'Zilb#1195^285ee547",
			[2345] = "0Draz'Zilb#1195^46285ee547~Draz'Zilb#1195^285ed548~287bcc247bcc247bcc247bbc24891b99",
			[2347] = "0Overlord Mok'Morokk#1194^46285d0506~Draz'Zilb#1195^285ee548~285d1509",
			[16705] = "0Bor Wildmane#3bca^46507c5604~Bor Wildmane#3bca^507c4604~50672757",
			[6749] = "0Oathstone of Ysera's Dragonflight^465822db6e~~",
			[2355] = "0Mudcrush Durtfeet#1197^462859e61e~Mudcrush Durtfeet#1197^2859c61f~2889e2758aa26a8ad2398c32618c329d8de2ab8f22b093829f",
			[11461] = "0Neeru Fireblade#c90^46447ee80e~Thrall#1355^4451960b@88 25",
			[6765] = "0Captain Vanessa Beltis#20bc^460a87ce05~Captain Vanessa Beltis#20bc^0a87ce05~0a879e07",
			[18863] = "0Magistrix Elosai#42c5^4667760810~Wizlo Bearingshiner#2abd^6736f531@250 25~679968b9a3a91d",
			[18879] = "0Advisor Sarophas#42c9^460c0f27ad~Advisor Sarophas#42c9^0c0f17b4@250 25~0c68d4b6~0c6ac44c",
			[9487] = "0Vaelan#283b^4611ffaffa~Vaelan#283b^11ffaffa~28903e22",
			[2395] = "~Rau Cliffrunner#1272^6775d840@250 3e~676b750c",
			[9575] = "0Yeh'kinya#2183^4659ab3395~Yeh'kinya#2183^59ab3394~64930dd7",
			[2403] = "0Nazeer Bloodpike#12b7^46285a14e7~Nazeer Bloodpike#12b7^285a34e7~286aa4446e94d36bd4306844196563cf61441370a4596153c2644438",
			[2405] = "0Nazeer Bloodpike#12b7^46285a34e7~Nazeer Bloodpike#12b7^285a24e7~28b6f834",
			[2407] = "0\"Swamp Eye\" Jarl#12b8^46288db434~\"Swamp Eye\" Jarl#12b8^288db435~2893a32f",
			[2411] = "0Melor Stonehoof#d71^46689c4cda~Melor Stonehoof#d71^689c8cdb~287908af",
			[2413] = "0\"Swamp Eye\" Jarl#12b8^46288dc435~\"Swamp Eye\" Jarl#12b8^288db434~2856f3a256f3a257239b58b3a658b3a658b3a658b3a658c3a658c3a658c3a6",
			[6889] = "0Marvon Rivetseeker#1e5b^465986d756~Marvon Rivetseeker#1e5b^5986d757~619fd628",
			[6893] = "0Marvon Rivetseeker#1e5b^465986d757~Altar of Hakkar#o24564^57b2f875",
			[2437] = "0\"Swamp Eye\" Jarl#12b8^46288db435~\"Swamp Eye\" Jarl#12b8^288dc434~288ed4138d83f38cc3de8d73c990b4019164018fa4319064199063fd8f040b",
			[13843] = "0Je'neu Sancrea#31c0^46051db57a~Je'neu Sancrea#31c0^051db57b@125 25~0e238257",
			[2443] = "0Mebok Mizzyrix#d76^46619f8604~Mebok Mizzyrix#d76^619f8603@500 20~476cae616cae616cae616cae616cae616cae61~619f5605~619f5605~619f5605",
			[9767] = "0Trull Failbane#2842^462d58a86b~Nara Wildmane#168a^68c1a4fa",
			[9815] = "0Felnok Steelspring#28e4^46729d7629~Tinkee Steamboil#281b^16a723d9",
			[2479] = "0Loose Dirt#o51f9^46288db426~Nazeer Bloodpike#12b7^285a34e7",
			[2481] = "0Nazeer Bloodpike#12b7^46285a34e7~Kin'weelay#9d7^5552646f",
			[7013] = "0Kaldorei Tome of Summoning#o24ef6^460a9854fe~Ag'tor Bloodfist#2180^0a391839@37 25~0a983508",
			[7029] = "0Kadrak#2186^46617b10dc~Kadrak#2186^617b10de@88 25~534bf2ba",
			[14059] = "0Vark Battlescar#2e2f^46233b3b37~Vark Battlescar#2e2f^233b4b3a~3c4d98ba4d98ba4d98ba4d98ba4d98ba4d98ba4d98ba~3c4d9a57",
			[9975] = "0Mulgris Deepriver#29f3^466f894a54~Nara Wildmane#168a^68c194f7@62 25",
			[7041] = "~Yeh'kinya#2183^59ab3394~2e8f287197885e939786",
			[2503] = "0Black Shield#o5200^46284bd7c1~Krog#133e^285d2515",
			[12061] = "0Gregor Greystone#28bf^46729cc639~Duke Nicholas Zverenhoff#2b1f^29c1489f@75 c",
			[10047] = "0Janice's Parcel#o2af16^466f6318d3~Royal Overseer Bauhaus#2a1d^6cb1d6f8",
			[2523] = "0Bubbling Cauldron#o81c^465552646d~Nazeer Bloodpike#12b7^285a34e8~289ada6f",
			[2525] = "0Nazeer Bloodpike#12b7^46285a34e8~Zor Lonetree#fcf^44637610",
			[10103] = "0Janice Felstone#2a1a^466f6218a5~Janice Felstone#2a1a^6f6218a3~6f5ff8c4",
			[2537] = "0Suspicious Hoofprint#o2db89^46284be79c~Krog#133e^285d2515",
			[2539] = "0Theramore Guard Badge#o5232^46284c27b2~Krog#133e^285d2515",
			[2541] = "0\"Stinky\" Ignatz#1310^462877e2d0~Mebok Mizzyrix#d76^619f8603@250 20~287cf3f7",
			[18273] = "~Rayne#3f07^29c0a87d~3c4daa584daa584daa584daa584daa584daa584daa584daa584daa584daa584daa584daa584daa584daa584daa58",
			[7137] = "~Chemist Cuely#20c6^6c7c6b77@19 25~0a7a99a4~0a7a1831~0a7c37c5~0a79576c",
			[12269] = "0Hornizz Brimbuzzle#1783^46237a49dc~Hornizz Brimbuzzle#1783^237a59df~23a4de96a49e9aa46ea0a47ea0a48ea0a49e9ba49e99a47e93",
			[1281] = "0Zengu#a8f^4604bcc565~Tor'gan#a92^04bf05d3@62 25~043ce9a93a09c8",
			[18417] = "0Zanza the Restless#3ac2^46758a32ce~~",
			[1283] = "0Tor'gan#a92^4604bf05d3~Zengu#a8f^04bcc56a@25 a",
			[18465] = "0Craftsman Wilhelm#3ff8^4629c04894~~~~",
			[18481] = "0Craftsman Wilhelm#3ff8^4629c04894~~~~~~",
			[18497] = "0Aurel Goldleaf#3bb2^465084a613~Aurel Goldleaf#3bb2^5084a614~5067275765f73d~",
			[8241] = "0Talo Thornhoof#1e60^462ec2b6ff~Talo Thornhoof#1e60^2ec2a6ff~2d88744189b47289b47489b4748dc4518e74518fa4538b74038ea3c98e03908e5363~2d8b541a9342de8ec3c88fa3df8ab45e87b47a87a4658aa4098f138b8ae28a90a4208e1448",
			[10295] = "0Wanted Poster - Arnak Grimtotem#o2aff3^466775881d~Cliffwatcher Longhorn#2929^6774e812@250 3e~67618447",
			[16515] = "0Ogtinc#20d5^460a6c66d4~Greta Mosshoof#2aaa^2d82bd1e~57b2f875",
			[8273] = "0Yuka Screwspigot#2548^4616a8b386~~",
			[22685] = "0Horde Warbringer#3bf6^464fabe917~Horde Warbringer#3bf6^4fabf90e~6e709946",
			[16563] = "0Windcaller Proudhorn#3b57^465082d618~Windcaller Proudhorn#3b57^50828619~505486f35396854ff6644b86604a068e4706e94256a33b96c13816543726463536c533d6ee32c7235037825806ff",
			[16643] = "0Huum Wildmane#3ba6^46507c4605~Huum Wildmane#3ba6^507c5609~50b93279",
			[5203] = "0Bloodmage Lynnore#1d52^4614815246~~149a05d29976219b04be90c4f5~148b15cd9095fc",
			[1303] = "0Iridescent Shards#oa8d^4604d734f3~Stone of Inner Binding#oa8e^045c9929~044104d5~04aac4c2~04854816",
			[7257] = "0Fallen Hero of the Horde#1d94^4658576a89~Fallen Hero of the Horde#1d94^58577a91~147b649f",
			[1305] = "0Stone of Inner Binding#oa8e^46045c8928~Keystone#oa80^045be94d~0447f7e9",
			[18881] = "0Cersei Dusksinger#42d5^465879d8c4~Cersei Dusksinger#42d5^587b58db@250 25~589b538e~58a733ab~58a0d3d7",
			[1313] = "0Theldurin the Lost#ae1^460c838c44~Shards of Myzrael#o21cfc^04a03565~04a17569",
			[16963] = "0Gorn One Eye#2d23^462da6d06c~Gorn One Eye#2d23^2da6d06c~72b10620~",
			[2643] = "0Krog#133e^46285d2515~Do'gol#13df^285d64f0",
			[2645] = "0Do'gol#13df^46285d64f0~Do'gol#13df^285d54e9~285a53c157537b57737d57737d57637e",
			[2647] = "0Do'gol#13df^46285d74ee~Krog#133e^285d2514",
			[1325] = "0First Mate Nilzlix#acf^460453ed07~First Mate Nilzlix#acf^0453cd06@250 5~043aed83~043bfd99~04343dab~0434cd99",
			[12645] = "0Gordon Wendham#11cc^466c9dd6a7~Michael Garrett#11c7^6ca117b1@25 41",
			[1329] = "0Captain Steelgut#ad1^460456ace9~Captain Steelgut#ad1^0456aceb@250 5~043efddf400dc7402dc03fedce3f6def3b5e2939fe79376e643c5dcd3bbda9~0439ae733a6e5b3b6d9d",
			[8585] = "0Torwa Pathfinder#2593^466bb75c21~Torwa Pathfinder#2593^6bb74c1f~6bcbe7f3",
			[8593] = "0Maxwort Uberglint#2540^4616a6b3ca~Maxwort Uberglint#2540^16a6c3cf~1689f683",
			[1333] = "0Doctor Draxlegauge#ad6^4604566cdd~Doctor Draxlegauge#ad6^04569ce0@350 5~043a4e26363e68327d82407e783f2dce3eedd83a9ebb324d8d3d4e19405e75",
			[1337] = "0Doctor Draxlegauge#ad6^4604569ce0~Shakes O'Breen#a32^0452ad01@75 5",
			[8649] = "~Yuka Screwspigot#2548^16a8d386",
			[1341] = "0Fleet Master Seahorn#9b7^4655456c4c~",
			[12765] = "0Jorn Skyseer#d3b^466172b971~Senani Thunderheart#3198^05bc89d2@25 3e",
			[12789] = "0Foreman Thazz'ril#2c72^462671faf8~Foreman Thazz'ril#2c72^2671faf6@350 a~266fe896",
			[17395] = "0Windcaller Yessendra#3c8a^465084d612~~~44823b34820b3b~4481eb4481cb34~4481cb3481fb3581eb3a~",
			[1347] = "0Tor'gan#a92^4604bf05d3~Tor'gan#a92^04bee5cf@250 a~044bda15",
			[14883] = "0Azj'Tordin#3813^462ec4b5f8~Azj'Tordin#3813^2ec4a5fb@500 24~24000000",
			[12885] = "0Marukai#31af^46051de591~Marukai#31af^051de591@250 a~0521243f21941b23e3db2463b32663a327039a2573cd25f3f926041627241826f3fa25d43b24044222e43722b461",
			[2717] = "0Apothecary Zinge#1454^466c7f0ada~Apothecary Helbrim#d3e^618394d2@62 25",
			[17619] = "0Logistics Task Briefing IX^4650850aec~~~",
			[1361] = "0Korin Fel#ad4^4604bd6550~Korin Fel#ad4^04bd254f@88 25~04309a85",
			[2723] = "~Regthar Deathgate#d3d^6173e48b@7 25",
			[2725] = "0Regthar Deathgate#d3d^466173e48b~Felgur Twocuts#1513^238fb982@6 25",
			[2733] = "0Felgur Twocuts#1513^46238fa981~~",
			[21903] = "0Blood Elf Orphan#5921^464fbc87e8~Blood Elf Orphan#5921^37e2980a~37e27801",
			[21935] = "0Blood Elf Orphan#5921^4651c37cd0~Orphan Matron Mercy#5923^4fbf979d~",
			[1375] = "0Zaruk#ae3^4604be55af~Theldurin the Lost#ae1^0c835c46",
			[17891] = "0Anthion Harmon#3e90^4656456280~~",
			[345] = "0Orphan Matron Battlewail#3873^0d44b5240e~Orcish Orphan#386c^44b5940f",
			[13085] = "0Darn Talongrip#2e2d^4653bb3f2c~Kadrak#2186^617b10de",
			[7573] = "0Bashana Runetotem#237f^4668b50567~Bashana Runetotem#237f^68b50573@250 3e~44820b4b",
			[11055] = "0Rabine Saturna#2e19^463e84072d~Rabine Saturna#2e19^3e84172d~50a1c8d2",
			[5535] = "0Homing Robot OOX-22/FE#1e7f^462e8878e7~Oglethorpe Obnoticus#1cee^55487c31@350 5~2e7446e5",
			[11071] = "0Loh'atu#2d1c^460a1d2c7b~Loh'atu#2d1c^0a1d0c7a~0a233b9c247b80258ba429fb632a5b7c2a6b38~0a221bcd24eb882a1b552d8b192b8abd2d8aac",
			[2779] = "0Magtoor#6f0^465842c505~Magtoor#6f0^5842d507~588e249a8d14c792b40c99c39b9e239d9f13bb",
			[2785] = "0Noboru's Cudgel^4658cc0c34~Magtoor#6f0^5842a508",
			[2787] = "0Galen Goodward#150f^4658a742db~Galen's Strongbox#o7f39^587a865f~588704be",
			[2789] = "0Parqual Fintallas#1188^466c937a63~Dorn Plainstalker#baa^6789e6a5",
			[1397] = "0Dar#15d7^465872791d~Tok'Kar#15d8^58cf9cef@62 25~587bd6897f66368bc5db9a852ba1b53ca7249a88e79893174d",
			[1399] = "0Tok'Kar#15d8^4658cf9cef~Tok'Kar#15d8^58cf7cf0@63 25~58d59b2ed38b56d4ba6ddd98f3d56b2ad6b547",
			[21] = "0Senior Surveyor Fizzledowser#1e2c^4659806463~Senior Surveyor Fizzledowser#1e2c^59807463@250 11~598efb5f",
			[22431] = "0Nazeer Bloodpike#12b7^46285a14e7~Drazzit Dripvalve#5c14^286c1ba7",
			[1407] = "0Rigglefuzz#b01^460c6c4876~Rigglefuzz#b01^0c6c887d@150 5~0c975b179b5b7d1f3b4b9d68e8",
			[18419] = "0Zanza the Restless#3ac2^46758a32ce~~",
			[1411] = "0Rigglefuzz#b01^460c6c4876~Rigglefuzz#b01^0c6ca87e@250 5~5544b4a54264b244044643442245543b40d4964224dd4404d145c437",
			[7689] = "0A Wrecked Raft#o276e1^466ba15aed~A Small Pack#o276e0^6ba15b0b",
			[16565] = "0Noggle Ficklespragg#3b56^465084362b~Noggle Ficklespragg#3b56^5084162b~5071ee97",
			[2845] = "0Tok'Kar#15d8^4658cf9cf0~Katar#15d9^58d5acda",
			[2849] = "0Fel'zerul#5a3^46587a68c8~Fel'zerul#5a3^587a98c6@87 25~58a7883dbdd7aabee8e9b6e978aa3973a7291fa718dea7a849bdb7a8a758d9",
			[713] = "0Deathguard Linnea#5d7^4669a7299e~Deathguard Linnea#5d7^69a789a0~69bfb9dfc319fbc46a05c089bfc17987c38988c4199fc489d0~69c239e2bf799fc00980c3a9b3c449d3c659c3c6d98cc76991",
			[2853] = "0Katar#15d9^4658d5acda~Katar#15d9^58d60cdb@87 25~58daed2bdc9d4edbfd66dbfd6cdb3d7cdbada6d8de2cd2eeadd28edbd33ee2~58db8dbdda3e02d4fe32d54e77d4de7dd2bec9d1cedcd04ebfd7ade0d72daf~58d58e72e1fc58e42c47e81b7be9fae7ebcadcef6a36f06a03f3e846f02842",
			[2855] = "0Katar#15d9^4658d60ce0~Tok'Kar#15d8^58cffce9@63 25",
			[1429] = "0Lotwil Veriatus#b69^460c426733~~",
			[2859] = "0Fel'zerul#5a3^46587ab8c8~Atal'ai Exile#15de^64563c02",
			[2861] = "0Dar#15d7^465872791b~Dar#15d7^5872991c@63 25~58f8a73dee4546efa63eea9518f12766f2f905edca0cda0ffad42fd2efe6ca",
			[11447] = "0Rahauro#2e39^4668b3d4ad~Rahauro#2e39^68b3b4b4@500 3e~458727c38727c3~458727c38727c3",
			[11455] = "0Thrall#1355^4644516609~Thrall#1355^4451960a@19 25~447ee80c",
			[719] = "0Magistrate Sevren#5db^46699c781c~Deathguard Linnea#5d7^69a7499f",
			[721] = "0Deathguard Linnea#5d7^4669a7299e~Magistrate Sevren#5db^699ca821",
			[11527] = "0Roon Wildmane#2e65^4623401b88~Hemet Nesingwary Jr.#2cb^555b31b8",
			[7817] = "0Linken#2221^466b726150~Donova Snowden#2452^724ff736",
			[2889] = "0Atal'ai Exile#15de^4664563c02~Fel'zerul#5a3^587aa8c6@88 25",
			[2891] = "0Fel'zerul#5a3^46587aa8c6~Fel'zerul#5a3^587a78c5@125 25~57b2f875b2f875b2f875b2f875b2f875b2f875b2f875b2f875b2f875b2f875b2f875b2f875b2f875b2f875b2f875",
			[2893] = "0Atal'ai Exile#15de^4664564c04~Atal'ai Exile#15de^64561c00~57b2f875",
			[7845] = "0Wenikee Boltbucket#2464^46617d61cb~Wenikee Boltbucket#2464^617d51c9@250 20~618e416b8e718191416a9011268fd11c8df1488f418e90f16a",
			[7849] = "0Rilli Greasygob#2465^4644c313ea~~",
			[5807] = "0Woodpaw Battle Map#o22b73^462eb748ee~Hadoken Swiftstrider#1ec3^2ebf86cc",
			[9577] = "0Prospector Ironboot#28dc^4659aad3d6~Prospector Ironboot#28dc^59aad3d6~11ffaffa~11ffaffa",
			[17157] = "0Inconspicuous Crate#o2c1a2^4652760dd5~Narain Soothfancy#2e23^59a6e2f7~3d800af8",
			[9617] = "0Tinkee Steamboil#281b^4616a703d9~Felnok Steelspring#28e4^729d662b@75 c",
			[21313] = "0Magistrix Fyalenn#4863^464f73ecf5~Magistrix Fyalenn#4863^4f73ecf5@250 35~",
			[733] = "0Bethor Iceshard#5da^466cd6c2b4~Gunther Arcanus#5d9^69ae56b7@75 41",
			[19331] = "0Emissary Gormok#42b0^4629be1843~~~~~",
			[5871] = "0Apothecary Lydon#8a8^46389d230e~Master Gadrin#c74^268f0bf1@150 a",
			[5875] = "0Master Gadrin#c74^46268efbf2~Apothecary Lydon#8a8^389d4310@125 25~6456fbad",
			[1473] = "~Keeper Bel'dugur#b76^6c8958a7~015c0873~2898e1a3~5579f713",
			[737] = "0Apothecary Johaan#5ee^466998085c~Apothecary Johaan#5ee^6998185c~699d84779d947c9e7494a16472a24483",
			[1475] = "0Keeper Bel'dugur#b76^466c8958a7~Theldurin the Lost#ae1^0c836c44",
			[739] = "0Apothecary Johaan#5ee^466998185c~Apothecary Johaan#5ee^6998085c~69d598d7d957f3dbc7d4dfa7ea",
			[741] = "0Executor Zygand#5eb^46699ae84a~Executor Zygand#5eb^699ac848~6982ead0~6986aab8854ac0~6986aab885db0b815ad5",
			[5931] = "0Sage Truthseeker#f8a^466858678d~Nara Wildmane#168a^68c1b502@10 3e",
			[5935] = "0Uldum Pedestal#o22c07^4659605cff~Nara Wildmane#168a^68c124f6@10 3e",
			[743] = "0Executor Zygand#5eb^46699ac848~Executor Zygand#5eb^699ad848~69c998f9~69cb18f8cb18d9c998f9c8a901",
			[1487] = "0Ruul Eagletalon#ba9^463f7919e5~Ruul Eagletalon#ba9^3f7919e4@250 3e~3f57c6bf55c6e95446c552e6cf5126be5196985016915136be",
			[745] = "0Executor Zygand#5eb^46699ad848~Executor Zygand#5eb^699ae847~69cb4405~69cb4405",
			[1491] = "0Baine Bloodhoof#bb1^463f79999c~Baine Bloodhoof#bb1^3f79a99c@250 3e~3f5b09d55ab9eb5ac9f959aa025449e35409c952a9a45149a5~3f5999e15449e35329b252a9a45149a551598f4c29a6~3f4e69ab4cd9aa4d99d54de9e4",
			[1493] = "0Baine Bloodhoof#bb1^463f79999c~Baine Bloodhoof#bb1^3f79a99c@250 3e~3f4fd7f24fe7f14fe7f14fe7f14fe7f1",
			[1495] = "0Grull Hawkwind#ba4^463f72dc54~Grull Hawkwind#ba4^3f72bc53~3f7c9ca67d9cce875d17863d5c892d428abd9c891de0~3f7c9ca67d9cce85ecee863d5c892d428a7ddb891de0",
			[749] = "0Deathguard Burgess#674^46699b984f~Deathguard Burgess#674^699b9851~6986aabc82eace82dacf85db0b82ab1a7cda9c889ae9836a877b0a99866b07",
			[23951] = "0Blood Elf Orphan#5921^4637e27809~Blood Elf Orphan#5921^51c37cd0",
			[8045] = "0Cyrus Therepentous#24f3^4616f2b50f~~~",
			[17861] = "0Mokvar#3e8c^464458f613~Anthion Harmon#3e90^56456280",
			[9969] = "0Mulgris Deepriver#29f3^466f893a57~Mulgris Deepriver#29f3^6f895a57~6f84db4e6d37b46967dd79e7637235117b944e7834887804b8",
			[1505] = "0Chief Hawkwind#ba5^463f711c29~Greatmother Hawkwind#baf^3f7fccf6",
			[22017] = "0Sky Sergeant Doryn#5a08^4660a51aa4~Sky Sergeant Doryn#5a08^60a50aa3~60bc8cdac19cd2c21cfcc25d05bded7dbdde48b94e2eba3db3b89d01b35c1cb38cc7bc5ccfbc8cc5c1dccac32d06",
			[17957] = "0Mux Manascrambler#3e8e^465986245b~Mokvar#3e8c^44595613",
			[1511] = "0Chief Hawkwind#ba5^463f711c28~Seer Graytongue#ba6^3f6cdeb9",
			[14133] = "0Zaetar's Spirit#2fce^463c4d9a57~Keeper Remulos#2e38^3e5cf6b3",
			[1515] = "0Seer Graytongue#ba6^463f6cdeb9~Chief Hawkwind#ba5^3f714c2c~3f9a4d189a0ce8990cb7990c9897ac8697ec7b978c8095dc889e5d5b9f1d039f7cb9a55c70",
			[22161] = "0Chu'a'lor#5ac1^461349a92e~Chu'a'lor#5ac1^1349892c~134a4782",
			[8125] = "0Hierophant Theodora Mulvadania#2377^460c0807a2~Lotwil Veriatus#b69^0c425735",
			[10113] = "0Storm Shadowhoof#283f^46729e3621~Storm Shadowhoof#283f^729e4620~727ef18c",
			[1523] = "0Harken Windtotem#b83^463f7c597b~Harken Windtotem#b83^3f7c697c@158 3e~3f6319365cb95d64ab41694a9d66d9fc68896466f8cd633892",
			[1527] = "0Chief Hawkwind#ba5^463f714c2c~Baine Bloodhoof#bb1^3f7979a0",
			[8165] = "0KILL ON SIGHT#o28404^460c0a877b~~~~",
			[6127] = "0Talo Thornhoof#1e60^462ec2b6ff~Talo Thornhoof#1e60^2ec2a6ff~2e6bd20269a1cd66b1ad669204~2e64b1c365f22a65824a67825c~2e63722d62e23a62e23d62e242~2e6a71e466f1b264b1d865f1f3",
			[1535] = "0Baine Bloodhoof#bb1^463f79999c~Zarlman Two-Moons#bee^3f7a2933@25 3e",
			[16363] = "0Prospector Ironboot#28dc^4659aad3d6~Yeh'kinya#2183^59ab2393",
			[18421] = "0Zanza the Restless#3ac2^46758a32ce~~",
			[1543] = "0Zarlman Two-Moons#bee^463f7a2934~Zarlman Two-Moons#bee^3f7a292f@250 3e~3f708738708738~3f6bc903636b67",
			[1545] = "0Zarlman Two-Moons#bee^463f7a292f~Seer Wiserunner#ba8^3f53d5c6",
			[10305] = "0Pamela Redpath#2aae^4629534d63~Marlene Redpath#2aaf^6f7dbc8b",
			[10313] = "0Taronn Redfeather#2aa9^462d824d0e~Taronn Redfeather#2aa9^2d824d0c~2d6966f2~2d6876fb69b6e4~2d6666e175e628",
			[16567] = "0Wanted Poster: Deathclasp#o2c0e0^465082f61a~Vish Kozus#3b4e^5081b566~50733ea9",
			[1551] = "0Ancestral Spirit#bb2^463f9d235c~Cairne Bloodhoof#bf1^6898e844",
			[1553] = "0Cairne Bloodhoof#bf1^466898a843~Cairne Bloodhoof#bf1^6898c840~3f7db2f8",
			[16631] = "0Geologist Larksbane#3b4f^46507ee5f7~Geologist Larksbane#3b4f^507f15f6~507ad90e",
			[10409] = "0Jessir Moonbow#2b0b^462d834d1e~Remains of Trey Lightforge#2b0c^2d625810~2d618816",
			[1561] = "0Grull Hawkwind#ba4^463f72dc54~Grull Hawkwind#ba4^3f72bc52~3f867c96866c88877c5b884c388bec3b8d4c128ebc788dece5~3f866c88884c388bec3b8ccc2f8d4c128ebc788dece58bbcf4",
			[6251] = "0Witch Doctor Uzer'i#1fb3^462ebe46ed~Witch Doctor Uzer'i#1fb3^2ebe56ef~2eb43769b2e76eb0e74ab10732afa71db1c75fb2c775b3076d",
			[6255] = "0Witch Doctor Uzer'i#1fb3^462ebe56ef~Witch Doctor Uzer'i#1fb3^2ebe46ee~2e69d4186993f768f3ea66b3e764f3d164a3d662d3da",
			[18869] = "0Wizlo Bearingshiner#2abd^466736b531~Magistrix Elosai#42c5^6775f80c@250 25",
			[8491] = "0A-Me 01#2597^466bacf2aa~Karna Remtravel#2592^6b76d226~6b76d226",
			[21107] = "0Khadgar#46f6^464f8c0704~Voren'thal the Seer#4862^4f6cfe99@10 35",
			[1579] = "0Gornek#c47^46266b8aee~Gornek#c47^266b8aeb@250 a~2672db58706bbb69cb4768bb4d692a3b661a30652a086559cd6679d76839fa",
			[1581] = "0Hana'zua#cd7^462667da02~Hana'zua#cd7^2667da03@250 a~26677aa0",
			[17079] = "0Combat Task Briefing V^46507e65eb~~5050a94151294a4fb9024cb8e43cc9063dc9f43dd9e43e19f831a8e841a9fd428a234b7ad3567a06578a0c560a49",
			[12647] = "0Karos Razok#8b2^46527486ce~Gordon Wendham#11cc^6c9da6b2@75 41",
			[8579] = "0Torwa Pathfinder#2593^466bb72c1f~Torwa Pathfinder#2593^6bb72c1f~6ba192c09e52c8~6ba562a4a79290~6ba4329bace272",
			[8587] = "~Chemist Fuely#2798^6c795b9f@63 25~6c79eba779eba779eba779eba779eba7",
			[1589] = "0Zureetha Fargaze#c49^46266d8b08~Zureetha Fargaze#c49^266dab09@500 a~266d4873",
			[797] = "0Wanted!#o2c7^46699b3840~Executor Zygand#5eb^699ac846~699604ef",
			[199] = "0Dalar Dawnweaver#792^4652710660~Dalar Dawnweaver#792^5270f65f@250 41~527adbbb7aebb876db9a76fb94764b76764b76",
			[17463] = "0Windcaller Kaldon#3cb4^46507fa5d2~Windcaller Kaldon#3cb4^507fd5d3~50853aef856af4854aef",
			[1609] = "0Hana'zua#cd7^462667da03~Gornek#c47^266baaec@25 a",
			[1611] = "0Zureetha Fargaze#c49^46266dab09~Master Gadrin#c74^268f0bee@75 a",
			[6443] = "0High Executor Hadrec#7a0^46526ed687~Apothecary Renferrel#791^526da687@3 25",
			[17575] = "0Logistics Task Briefing VII^465077f67e~Merok Longstride#3cfd^50847ae3~5084360c~5084360c",
			[4405] = "0Jarkal Mossmeld#1ad4^460c06a75d~Jarkal Mossmeld#1ad4^0c06875c@63 25~6a71b1f471b1f471b1f471b1f471b1f471b1f4",
			[21891] = "0Blood Elf Orphan#5921^464fbc87e8~Hch'uu#5927^73317832~73317832",
			[21907] = "0Blood Elf Orphan#5921^464fbc87e8~Elementalist Sharvak#4698^409b0388~4098f37f",
			[17847] = "0Mokvar#3e8c^464458b611~Mux Manascrambler#3e8e^5986045c",
			[6523] = "0Sergra Darkthorn#d0a^46618574f5~Jorn Skyseer#d3b^6172a972@10 3e",
			[13047] = "0Kaya Flathoof#2e50^4653bbedae~Makaba Flathoof#2e51^615a0472~53c50e84",
			[817] = "0Magistrate Sevren#5db^46699c781c~Magistrate Sevren#5db^699c7820~6982f4d58344ae84548785a45b85d43285d44b84744d84d422~6985d43286843e85d44b84744d84d422864440~6986d435",
			[13087] = "0Kadrak#2186^46617b10de~Kadrak#2186^617b10de@87 25~05b5aae7~051f4575~05d018a5",
			[11049] = "0Argent Quartermaster Hasana#2a68^4669d4aae3~~~",
			[9011] = "0Winna Hazzard#270c^462d57885e~Winna Hazzard#270c^2d57885b@62 25~2d52daa4",
			[9019] = "0Alchemist Pestlezugg#15da^465982344f~Zilzibin Drumlore#1b62^4490a76f@10 a",
			[11073] = "0Loh'atu#2d1c^460a1d2c7b~Loh'atu#2d1c^0a1d0c7a~0a31aa1d32d9bb3599cb3579c432d9e435d9ba~0a30ba3c3199ff~0a305a4031a9e6",
			[13127] = "0Je'neu Sancrea#31c0^46051db57a~Je'neu Sancrea#31c0^051db57b@62 25~0e238257238257238257238257238257",
			[9043] = "0Trull Failbane#2842^462d58b86e~Trull Failbane#2842^2d58c86f@63 25~7296e4779804799b24c28fe4cd9104a494c54e8d15359a44c09ab4c290c4bc8fd47a9604729894678cd52d9aa4c2~7263d63b5e15c46216096785fe6ca5ed72d60f7526007b15a97cf59a7e159d6b462f60666973d6dc78c6f57986d7",
			[1645] = "0Brewmaster Drohn#cdc^46619f4620~Brewmaster Drohn#cdc^619f4620~617a0c247cac8d788cb6728c55742c0b~6177dbc5~617d1936",
			[823] = "0Gunther Arcanus#5d9^4669ae56b7~Bethor Iceshard#5da^6cd6e2c9@250 41",
			[22259] = "0Ahab Wheathoof#5c42^463f7b6886~Ahab Wheathoof#5c42^3f7b6887@63 25~3f782992",
			[6603] = "0Tonga Runetotem#d78^466185851a~Mura Runetotem#20c1^526de6b3@250 3e",
			[4569] = "0Dran Droffers#1b4a^464497b5e1~Remains of a Paladin#1b00^6a71a1f1@125 25",
			[3313] = "0Antur Fallow#1a77^463f626d0b~Innkeeper Kauth#1a5b^3f7749bf",
			[13255] = "0Braug Dimspirit#1189^4653c93749~Braug Dimspirit#1189^53c9374b~53c9374b",
			[22451] = "0Draz'Zilb#1195^46285ed547~\"Swamp Eye\" Jarl#12b8^288dc435",
			[20437] = "0Cryo-Engineer Sha'heen#4cd7^4607657934~~",
			[18423] = "0Mataus the Wrathcaster#3f05^4629c1485f~~",
			[4637] = "0Remains of a Paladin#1b00^466a71a1f1~Jarkal Mossmeld#1ad4^0c06675e@63 25",
			[16569] = "0Geologist Larksbane#3b4f^46507ed5f9~Geologist Larksbane#3b4f^507f05f5~503713813861af3a015a38a15837213b3741813771a236d1b3",
			[15461] = "0Hadoken Swiftstrider#1ec3^462ebf86cc~Hadoken Swiftstrider#1ec3^2ebf76cc~2ec159d1c019e2c009ebbed9fdbd89f8bc8a0ebc3a14bc5a4bbd3a53be4a56be1a5abe6a5eb9da50b88a3cb86a3a",
			[4677] = "0Jarkal Mossmeld#1ad4^460c06675e~Jarkal Mossmeld#1ad4^0c06875c@2 25",
			[6739] = "0Falla Sagewind#20e2^46617b253e~Arch Druid Hamuul Runetotem#1689^68c8748f@250 3e",
			[11449] = "0Maur Grimtotem#2e3a^46458727c3~Rahauro#2e39^68b3b4b4@500 3e",
			[845] = "0Dalar Dawnweaver#792^4652712660~Dalar Dawnweaver#792^5271465a@250 41~5287048e",
			[1691] = "0Sergra Darkthorn#d0a^0e618594f3~~",
			[9443] = "0Trull Failbane#2842^462d58b86d~Trull Failbane#2842^2d58a86b~72a4d3f7a73397a6237ea5c36ea45364a2f379a293a7a6e31da7b334a5a387",
			[18887] = "0Mehlar Dawnblade#42cb^4669d4ab66~~",
			[849] = "0Dalar Dawnweaver#792^4652713660~Dalar Dawnweaver#792^52710660@250 41~5295872b",
			[9483] = "0Trull Failbane#2842^462d58c86c~Trull Failbane#2842^2d58b86d~72a3f3b1a273a9a3337fa972f6a97362aa93b3a66379a72320a84343a57351a5137aa41392a1e3b2",
			[1701] = "0Regthar Deathgate#d3d^466173e48b~Regthar Deathgate#d3d^6173e48b@37 25~616d83c4",
			[851] = "0Rane Yorick#79e^4652886227~Rane Yorick#79e^52888229@38 25~5283d23a",
			[1703] = "0Regthar Deathgate#d3d^466173e48b~Regthar Deathgate#d3d^6173f489@37 25~618746ac",
			[1705] = "0Regthar Deathgate#d3d^466173f48a~Regthar Deathgate#d3d^6173e48b@38 25~61755699",
			[853] = "0Deathguard Dillinger#5d8^466994f838~Deathguard Dillinger#5d8^6994c837~697855a073b5a57025a56fe53375157d~697965c372c5c371960d",
			[855] = "0Executor Zygand#5eb^46699ad848~Executor Zygand#5eb^699ae84a~695c679b5727ba5617b756079f56e79b5407b052278e52577a514760",
			[1711] = "0Regthar Deathgate#d3d^466173e48b~Regthar Deathgate#d3d^6173e48b@88 25~616df3c06f13c36f63bf7293e275141274d41f74a4207484196f64386bb4006b63f36b83f26d73c36df3c06d73c3",
			[857] = "0High Executor Hadrec#7a0^46526ee688~Rane Yorick#79e^5288a229@25 41",
			[9619] = "0Felnok Steelspring#28e4^46729d662b~Felnok Steelspring#28e4^729d762c@250 c~7296f7139a973a9d47089ed87d9aa9899bf9aea2578294a70a",
			[23331] = "0Old Man Barlo#63ec^4660630209~Old Man Barlo#63ec^6063020e~44601cd95fbccc602cdd602cdd604cdbaf6591",
			[859] = "0Rane Yorick#79e^465288a229~Apothecary Renferrel#791^526db685@75 41~528082d07db3888fe1d49271869bf1739ed17c",
			[17241] = "0Narain Soothfancy#2e23^4659a6d2f7~~",
			[4837] = "0Rigglefuzz#b01^460c6c4876~Rigglefuzz#b01^0c6c887d@250 5~0c7861c677b1f777f21675d1fa7301ec7321dd7351bc73d1ad~0c7861c677b1f777f21675d1fa7301ec7321dd7351bc73d1ad",
			[6895] = "0Marvon Rivetseeker#1e5b^465986d757~Idol of Hakkar#o24566^57b2f875",
			[1731] = "~~617ba1c9",
			[1735] = "0Darsok Swiftdagger#d79^46618404ef~Darsok Swiftdagger#d79^6183f4f1@63 25~616643116643046743016732e06a43016a13126b030b695320",
			[1737] = "0Korran#d64^466182a4bc~Korran#d64^6182a4bb@250 a~61794b2b7a8b5a7adb597c5b28734b8d",
			[17545] = "0Combat Task Briefing VI^46507e65eb~~5050794c4f596b4409843e28da4298c73df9f53be9f23c79ab43ea42531a3955fa235569ec58ba3b43c985456a71",
			[871] = "0Deathstalker Erland#7ba^46528fc177~Rane Yorick#79e^52886227@62 25~5289e226",
			[9843] = "0Mankrik#d68^0e6184e50d~Mankrik#d68^6184e50a@38 25~617e180b",
			[1747] = "0Mahren Skyseer#d3c^4661a86703~Mahren Skyseer#d3c^61a85700@350 3e~61a27899",
			[1749] = "0Jorn Skyseer#d3b^466172a971~Mahren Skyseer#d3c^61a85702@25 3e",
			[875] = "0High Executor Hadrec#7a0^46526ee689~High Executor Hadrec#7a0^526ed688@250 41~5276a39c~52744362",
			[1751] = "0Darsok Swiftdagger#d79^466183f4f1~Darsok Swiftdagger#d79^618404f0@62 25~6166a28b66727165f28964f2916522a162b2be",
			[7003] = "0Kum'isha the Collector#1cc3^46148495b3~~",
			[1753] = "0Darsok Swiftdagger#d79^46618404f0~Darsok Swiftdagger#d79^6183f4f0@88 25~616421f1",
			[7011] = "0Ag'tor Bloodfist#2180^460a391838~Kaldorei Tome of Summoning#o24ef6^0a9854fe@37 25~0a9894f8~0a8e44cc8e44c58f14c19144d28db49f8d446490c49c94648894146a961485~0a8e44ce8ed4bc9074c28d54548ea4e49004ae94a4689614769564f596d4bd",
			[7015] = "0Ag'tor Bloodfist#2180^460a391839~Belgrom Rockmaul#1185^44bff577@88 25",
			[17833] = "0Mokvar#3e8c^4644592611~Mokvar#3e8c^44592612~508fb54c927563a484d0a7249ba4a4429774689713ec9963599a62f19d12d594220591e1d484c2b98792da9d828f~",
			[17849] = "0Mux Manascrambler#3e8e^465986245c~Mux Manascrambler#3e8e^5986245c~50a26870a1b85ea1b85ea1c863a1e864a1c866a1a85fa1a85ea1985fa1c867a1a858a1b85d~7286669a87469d86c6a386c6a486869986f6a68706a28706a38706a28706a286d6a386f6ba~29b58706b54711b53713b54712b5a70d8c79ec8c69ee8c39ef8c49ef8c49ef8cb9e68cb9e5",
			[9971] = "0Mulgris Deepriver#29f3^466f895a57~Mulgris Deepriver#29f3^6f894a54~6f8f995892896d8e689491c87692687595384892782494c9a2",
			[881] = "0High Executor Hadrec#7a0^46526ec688~Magistrate Sevren#5db^699c781c@18 25",
			[7055] = "0Yeh'kinya#2183^4659ab3394~Yeh'kinya#2183^59ab3395~7463032e~7463032e",
			[883] = "0Magistrate Sevren#5db^46699c781c~Raleigh Andrean#802^6c9fa6e8@19 25",
			[1767] = "0Hoof of Lakota'mani^46617f5882~Jorn Skyseer#d3b^6172b971",
			[14135] = "0Centaur Pariah#3595^4623722db9~~",
			[885] = "0High Executor Hadrec#7a0^46526ed688~High Executor Hadrec#7a0^526ed688@88 25~52a7c3cd",
			[221] = "0Senior Surveyor Fizzledowser#1e2c^4659807463~Alchemist Pestlezugg#15da^5982344f@10 11",
			[887] = "0High Executor Hadrec#7a0^46526ee687~Apothecary Renferrel#791^526dc686@250 41~52a963e5a813bba863c1a7c3d3a703eea8e3eaa7d3cca663b8",
			[10099] = "0Royal Overseer Bauhaus#2a1d^466cb1d6f8~Jeremiah Payson#20d3^6cac56f8@63 25",
			[1777] = "0Gazlowe#d3f^4661a035cc~Gazlowe#d3f^61a035cb@250 20~61a017ed~61a297e0",
			[889] = "0Apothecary Renferrel#791^46526dc686~Bethor Iceshard#5da^6cd752cb@6 25",
			[10131] = "0Prospector Ironboot#28dc^4659aae3d7~Prospector Ironboot#28dc^59aad3d6~29ab116b~29abf1d6",
			[7123] = "0Jediga#218b^460a39a839~Archmage Xylem#20bb^0a4ae66b",
			[7131] = "0Archmage Xylem#20bb^460a4ae66b~Jediga#218b^0a39b835",
			[22373] = "0Sealed Letter^462878677c~Nazeer Bloodpike#12b7^285a34e8",
			[7139] = "0Chemist Cuely#20c6^466c7bab73~Thersa Windsong#20c9^6c7c3b55",
			[895] = "0Apothecary Renferrel#791^46526da687~Master Apothecary Faranell#807^6c7c5b12@62 25~526a12c96882d564a28559c3215e12ed6162b7~525ed27d5c62695a223f5c52415a51ff5a71a8",
			[12265] = "0Melizza Brimbuzzle#2ff5^462356c88f~Hornizz Brimbuzzle#1783^237a49dc",
			[16365] = "0Prospector Ironboot#28dc^4659aae3d6~Molthor#3a1b^5526a26c",
			[897] = "0Apothecary Renferrel#791^46526db686~High Executor Hadrec#7a0^526ed688@19 25",
			[8205] = "0Maybess Riverbreeze#2539^462d77cd4a~Maybess Riverbreeze#2539^2d779d49~2d8ca2908e92b28e92b38e02b28de2bf8ed2cc9062d69142c89202c09222d594333f92233891f33f92137292236f",
			[899] = "0Rane Yorick#79e^4652886227~High Executor Hadrec#7a0^526ed687@18 25",
			[1799] = "0Mankrik#d68^0e6184e50d~~",
			[10299] = "0Pamela Redpath#2aae^462952ed5d~Pamela Redpath#2aae^29533d61~295a9da9",
			[10307] = "0Marlene Redpath#2aaf^466f7dbc8b~~",
			[1803] = "0Control Console#o102d^46618601dc~Control Console#o102d^618601dc@150 20~618711aa",
			[16555] = "0Beetix Ficklespragg#3b55^465084562a~Beetix Ficklespragg#3b55^5084262b~5090a4d39bc3fd9dd3bda1933da463aca7b4cf9a954ea793c7~509474a2a563b7a62400a4f5179e54369ec436a4f3c79723e3",
			[16571] = "0Geologist Larksbane#3b4f^46507f05f5~Hermit Ortell#3b5a^50abbb25",
			[16619] = "0Rutgar Glyphshaper#3b42^4650697e1f~Rutgar Glyphshaper#3b42^50696e21~50819437~505ec9ed~5083effa",
			[905] = "0Deathstalker Faerleia#80a^465276dbe1~Deathstalker Faerleia#80a^5276dbe0@63 25~5276dbcc",
			[1811] = "0Sergra Darkthorn#d0a^46618584f3~Sergra Darkthorn#d0a^618574f5@62 25~6186675e~6184f76c~61861771",
			[7243] = "0Loramus Thalipedes#1e67^460a9b6a9b~Galvan the Ancient#1e7a^55817342",
			[16683] = "0Aurel Goldleaf#3bb2^465084a613~Aurel Goldleaf#3bb2^5084a612~~5061d72762a72a616725",
			[7251] = "0Galvan the Ancient#1e7a^4655817343~Galvan the Ancient#1e7a^55817343~55817343",
			[1815] = "0Jorn Skyseer#d3b^466172a971~Jorn Skyseer#d3b^6172b971@350 3e~617268737cc9ea7bd9f0",
			[10427] = "0Betina Bigglezink#2b1b^4629c16897~~",
			[227] = "0Alchemist Pestlezugg#15da^465982344f~Senior Surveyor Fizzledowser#1e2c^59806462@10 11",
			[1821] = "0Orcish Orphan#386c^0d44b5a412~Orcish Orphan#386c^61a0f614~61a0e615a0e613",
			[1823] = "0Orcish Orphan#386c^0d44b5a412~Orcish Orphan#386c^617a90dd~617a30d57a70e0",
			[10483] = "0Pamela Redpath#2aae^4629534d63~Carlin Redpath#2b37^29c1889d",
			[23013] = "0Exorcist Vaisha#6136^46607f9779~Exorcist Vaisha#6136^607f6776~60677c7d675c7a7d39a67cf9a57d19a2",
			[1827] = "0Jorn Skyseer#d3b^466172b971~Jorn Skyseer#d3b^6172a971@350 3e~6174d876",
			[12569] = "0Wanted Poster: Besseleth#o2b6f0^4653971c14~Maggran Earthbinder#2e54^537899c2@250 3e~538bbb7e",
			[16971] = "0Gorn One Eye#2d23^462da6d06c~Thrall#1355^4451660a~",
			[12649] = "0Michael Garrett#11c7^466ca117b1~Deathguard Podrig#18f5^526f16a3@350 41",
			[8581] = "0Torwa Pathfinder#2593^466bb72c1f~Torwa Pathfinder#2593^6bb75c21~6bafc903",
			[8589] = "~Chemist Fuely#2798^6c795b9f@62 25~6c79bbb179bbb179bbb179eba779eba7",
			[23333] = "0Old Man Barlo#63ec^466063120f~Old Man Barlo#63ec^6062e20b~60637384",
			[1851] = "0Orcish Orphan#386c^0d6ca8d5d7~Orcish Orphan#386c^6898b843~6898c84398b843",
			[10723] = "0Cliffwatcher Longhorn#2929^466774f812~Nataka Longhorn#2bfb^238dc8e8@150 3e",
			[10763] = "0Taiga Wisemane#2d68^462341dae5~Taiga Wisemane#2d68^2341fae7@250 3e~238c6444",
			[10771] = "0Remains of Trey Lightforge#2b0c^462d625810~Jessir Moonbow#2b0b^2d833d1d",
			[17467] = "0Malfurion Stormrage#3c02^4657b2f875~Forest Wisp#3d08^5a6017a3",
			[847] = "0Dalar Dawnweaver#792^465271465a~Dalar Dawnweaver#792^52713660@250 41~526f75006f25166ec4976e449f74049e65847c~526e25036eb5196f1520",
			[17547] = "0Combat Task Briefing IV^4650814601~Commander Mar'alith#3b4d^507dc579~5042e97640c91a3f29443da8df3eaa1d3a49e43bd9833618c93fc9b8424a1944ea6148fab44feaac558a245949fc",
			[1795] = "0Harvester's Head^46616d4b49~Jorn Skyseer#d3b^6172b970",
			[23339] = "0Old Man Barlo#63ec^466063020d~~",
			[8805] = "0Galgar#2644^46266d3ac1~Galgar#2644^266d5ac1@500 a~2670bab670bab670fb416ffb9174aa5374ea4f701a096faa0e6f5a09759a14",
			[8127] = "0Lotwil Veriatus#b69^460c428733~~~",
			[8123] = "0Hierophant Theodora Mulvadania#2377^460c0817a5~Hierophant Theodora Mulvadania#2377^0c07f7a1@125 25~16a955f3abd6a7ae95feb06604a2b6c997c60390562d8746229c759c9f053b",
			[5043] = "0Kum'isha the Collector#1cc3^46148495b3~~",
			[10883] = "0Foreman Thazz'ril#2c72^462671eaf9~Foreman Thazz'ril#2c72^2671faf8@350 a~2671fba9730b096c4bb1698b9c720ba8",
			[5171] = "0Bloodmage Drazial#1d51^4614815246~~1473834072640b7742f8~148b15cd9095fc~1495d5b2",
			[5167] = "0Bloodmage Drazial#1d51^4614815246~~1495d5b293d4d1~1473834072640b~149a05d2",
			[7255] = "0Fallen Hero of the Horde#1d94^465857ba87~Fallen Hero of the Horde#1d94^58576a89~14aaa4ab~146e1226~146814c5",
			[7253] = "0Galvan the Ancient#1e7a^4655817343~Fallen Hero of the Horde#1d94^5857ba87",
			[1501] = "0Grull Hawkwind#ba4^463f72bc53~Grull Hawkwind#ba4^3f72dc54~3f6b4d906a5d7c6d1daf6ebe146c2e506e2e7a70de6a730e84706e5e752e31",
			[7205] = "0Loramus Thalipedes#1e67^460a9b9a9b~Loramus Thalipedes#1e67^0a9b6a9b~0a8f6d54985e5e9c2e4c980d8f98bd8c902e2f8d0e72877e52878d8f85eda1825d4e7f4db9802dee78ede378ede3",
			[22367] = "0Mordant Grimsby#5d23^46288e0430~Mordant Grimsby#5d23^288e142e~288da439",
			[5163] = "0Bloodmage Drazial#1d51^4614815246~Bloodmage Drazial#1d51^14817247~1479431172a4637e95db~1495d5b293d4d1~14738340",
			[877] = "0High Executor Hadrec#7a0^46526ed688~Corpse Laden Boat#o639^5294f591@150 41",
			[10963] = "0Gordo#29aa^466984c8a3~Junior Apothecary Holland#29a9^6992e7cd~6981080983984e85783a",
			[21927] = "0Blood Elf Orphan#5921^4637e27809~Blood Elf Orphan#5921^59a2a933~599ae925~59a2a933",
			[17851] = "0Mux Manascrambler#3e8e^465986245c~Mux Manascrambler#3e8e^5986145c~165c492b",
			[1739] = "~~617ba1c988a4a0",
			[1689] = "~Sergra Darkthorn#d0a^618594f3@250 1f~6184347086348b8924a48bc5098a151489054d",
			[11003] = "0Bibbly F'utzbuckle#2cae^46239f2637~Bibbly F'utzbuckle#2cae^239f763a@150 20~238a496b8a094e8789268869bf8ac9fe8b8a2b8b19b07d696b7f1929823969",
			[7057] = "0Yeh'kinya#2183^4659ab3394~Yeh'kinya#2183^59ab2394~57b2f875",
			[8993] = "0Alchemist Pestlezugg#15da^4659823450~Alchemist Pestlezugg#15da^5982244f@250 11~6b6e0d13~",
			[10405] = "0Blood Red Key^462d5d68d4~Captured Arko'narin#2b08^2d5c88e0",
			[11035] = "0Quartermaster Miranda Breechlock#2d10^4629c1b8a2~~~",
			[8489] = "0A-Me 01#2597^466bacd2ae~A-Me 01#2597^6bacf2aa~4f809407",
			[22103] = "0Kronk#5ad5^461349e93b~Kronk#5ad5^134a1941~134c4d4f4cfd434bbd554cad4b4ced474bed4952d66e52d66e52e66653567d53767f52e6635d86155d66155d361b",
			[9013] = "0Winna Hazzard#270c^462d57885c~Winna Hazzard#270c^2d57985d@63 25~2d57e865",
			[22339] = "0Apprentice Garion#5c31^4628759921~Apprentice Garion#5c31^2875a925~2877289b76d89a7e89297e992a7ea929",
			[893] = "0Bethor Iceshard#5da^466cd772bf~Apothecary Renferrel#791^526db686@6 25",
			[723] = "0A Letter to Yvette^46699aa86f~Yvette Farthing#618^699d8866",
			[2857] = "0Katar#15d9^4658d5bcdb~Katar#15d9^58d5dcda@62 25~58decce1dffcd3ddfd13dd4d34dccd51dc4de9da1e1dd42ea8dc3da3df8cfb~58d3ee70a96c3da8ec95a5fcffa49ceda34d52a23d86a23d8aa24dc0a30def~58f1b997a30e9fa1cdf39f8deba30e96a35cf2a08e28a05e1e9b8d999f4d56",
			[6753] = "0Brave Windfeather#c89^463f735c3a~Brave Windfeather#c89^3f720c40~3fa58c67",
			[4679] = "0Jarkal Mossmeld#1ad4^460c06b75d~~~~~",
			[10043] = "0Janice Felstone#2a1a^466f6218a3~Janice's Parcel#o2af16^6f6318d3",
			[1427] = "0Lotwil Veriatus#b69^460c424733~Lotwil Veriatus#b69^0c426733~448d0a4f",
			[1507] = "0Greatmother Hawkwind#baf^463f7fccf6~Chief Hawkwind#ba5^3f711c28~3f803d02",
			[1533] = "0Maur Raincaller#bef^463f78491d~Maur Raincaller#bef^3f78591e@250 3e~3f634938~3f6ba754~3f5c4917~3f631936",
			[1287] = "0Zengu#a8f^4604bcc56a~Zengu#a8f^04bcb567@250 a~0470281d",
			[10965] = "0Junior Apothecary Holland#29a9^466992e7cd~Junior Apothecary Holland#29a9^699457aa~699256c190d6b68dd6968d566e8ea63c8f263391e65991160d91b60f903681",
			[11163] = "0Taiga Wisemane#2d68^462341fae7~Taiga Wisemane#2d68^2341fae8@350 3e~23806be37f4c5881ccfa863d1587cd6887bcd4",
			[955] = "0Shadow Priest Allister#849^4652709688~Dalaran Crate#o65b^527fa9a4@250 41",
			[8293] = "0Liv Rizzlefix#2130^46619fb62f~Larion#239e^6b747163~57b2f875b2f875b2f875b2f875b2f875",
			[7643] = "0Thal'trak Proudtusk#237a^460c08e7ad~Sha'ni Proudtusk#23b0^16ccd745@250 a",
			[7645] = "0Sha'ni Proudtusk#23b0^4616cc8742~Thal'trak Proudtusk#237a^0c08e7a9@62 25~16cdc68d",
			[11203] = "0Jessica Redpath#2d6d^46729ca639~",
			[13257] = "0Parqual Fintallas#1188^466c937a63~Parqual Fintallas#1188^6c937a63~6c937a63",
			[901] = "0Master Apothecary Faranell#807^466c7c5b12~Apothecary Renferrel#791^526da685@62 25~526debb4",
			[1035] = "~Apothecary Lydon#8a8^389d230d@75 41~38b6fcee",
			[959] = "0Shadow Priest Allister#849^465270a686~Shadow Priest Allister#849^5270b68a@250 41~5298d9f49709e296b9e89419fa96aaaf9a8a469fca49a01a5f",
			[1291] = "0Zengu#a8f^4604bc9568~Trollbane's Tomb#oa8f^044a1988@25 a",
			[1033] = "0Shadow Priest Allister#849^4652708688~Shadow Priest Allister#849^5270868c@150 41~529afb959b4b99991b8298cb7596fb3c~5298cb7498eb73986b2d96cb54961b6c",
			[1289] = "0Zengu#a8f^4604bcb567~Zengu#a8f^04bc9568@250 a~0447d949",
			[961] = "0Shadow Priest Allister#849^465270b68a~Shadow Priest Allister#849^5270c68c@237 41~52a26a45",
			[17097] = "0Vargus#3b48^465082c634~~~~~",
			[7691] = "0A Small Pack#o276e0^466ba15b0b~Linken#2221^6b726150~6ba15b0b~6ba15b0b~6ba15b0b",
			[1925] = "0Apothecary Zamah#d5b^46683af35b~Apothecary Zamah#d5b^683a934c@62 25~6d7585ce7585ce7585ce7585ce7585ce7585ce7585ce7585ce7585ce7585ce",
			[963] = "0Shadow Priest Allister#849^465270868c~Dalar Dawnweaver#792^52710660@10 41",
			[9023] = "0Zilzibin Drumlore#1b62^464490a76f~Karus#ced^447efb15",
			[10331] = "0Greta Mosshoof#2aaa^462d830d1b~Greta Mosshoof#2aaa^2d831d21~2d5ca8fa~2d606870~2d5df885~2d5d68d4",
			[965] = "0Dalar Dawnweaver#792^4652710660~Shadow Priest Allister#849^5270a686@10 41",
			[16509] = "~Ogtinc#20d5^0a6c46d3",
			[879] = "0Corpse Laden Boat#o639^465294f591~High Executor Hadrec#7a0^526ee687@25 41",
			[22679] = "0Horde Warbringer#3bf6^464fab4919~~",
			[16557] = "0Beetix Ficklespragg#3b55^465084462c~Beetix Ficklespragg#3b55^5084662d~507f6ac1749b447cfaef~507e49d77e794985da41~50774b25728ba55f6ce5",
			[9765] = "0Blue-feathered Necklace^4672a4e3f6~Trull Failbane#2842^2d58a86b",
			[15463] = "0Hadoken Swiftstrider#1ec3^462ebf86cc~Hadoken Swiftstrider#1ec3^2ebf76cc~2ec009eb",
			[22743] = "0Nether-Stalker Mah'duun#5f32^464fc0e5fc~~",
			[16621] = "0Frankal Stonebridge#3b43^4650686e2e~Frankal Stonebridge#3b43^50686e2c~5070b3e8~5050a8f0~5086dce6",
			[9285] = "0Chemist Fuely#2798^466c795b9f~Chemist Fuely#2798^6c793ba2@88 25~6b95871a",
			[1939] = "0Witch Doctor Mau'ari#2843^46729e3620~Witch Doctor Mau'ari#2843^729e361f@63 25~729cbafc9e7af89eeb12a0bb16",
			[10319] = "0Islen Waterseer#170d^4661a85701~Greta Mosshoof#2aaa^2d830d1b",
			[11453] = "0Thrall#1355^464451660b~Thrall#1355^4451360a@62 25~2689b182",
			[15453] = "0Zorbin Fandazzle#392d^462e72a6ef~Zorbin Fandazzle#392d^2e72a6ef~2e77e88379785e79485e7f585f7af7e475385972c7fa76786c79b8867d583f7317bf71663c",
			[11457] = "0Thrall#1355^464451960a~Thrall#1355^4451760a@125 25~458737d0~458737d0",
			[20825] = "0Magistrix Fyalenn#4863^464f743cf5~Magistrix Fyalenn#4863^4f743cf5@250 35~",
			[2719] = "0Apothecary Renferrel#791^46526db687~Apothecary Zinge#1454^6c7f0ada@3 25",
			[11459] = "0Thrall#1355^464451760a~Neeru Fireblade#c90^447ee80e",
			[11445] = "0Rahauro#2e39^4668b3d4ad~Maur Grimtotem#2e3a^458727c3",
			[21885] = "0Orphan Matron Mercy#5923^464fbf07a4~Blood Elf Orphan#5921^4fbc87e8",
			[1951] = "0Witch Doctor Mau'ari#2843^46729e361f~Witch Doctor Mau'ari#2843^729e3621",
			[18875] = "0Balandar Brightstar#42c7^46285bc50d~Balandar Brightstar#42c7^285bd50f~287743e4~287723e5",
			[9453] = "0Tinkee Steamboil#281b^4616a6d3cf~Tinkee Steamboil#281b^16a703d9~169484057f5470c9c473c504c8ccf473d1040addb509e274b6",
			[22999] = "0p^464fae193f~Wind Trader Zhareem#5f31^4fbfa5e2~789cc4f4",
			[9469] = "0Tinkee Steamboil#281b^4616a723d9~~",
			[6259] = "0Witch Doctor Uzer'i#1fb3^462ebe46ee~Witch Doctor Uzer'i#1fb3^2ebe56ef",
			[9485] = "0Vaelan#283b^4611ffaffa~Vaelan#283b^11ffaffa~11ffaffa~11ffaffa~11ffaffa~",
			[16613] = "0Commander Mar'alith#3b4d^46507dd57b~Commander Mar'alith#3b4d^507dc57a~5083effa",
			[1331] = "0Professor Phizzlethorpe#ad0^4604568ce0~Doctor Draxlegauge#ad6^04566cdd@250 5~04565ce2",
			[23095] = "0Astromancer Darnarian#622d^467779a5a7~Astromancer Darnarian#622d^777965a5~777be70b~779c59ee~776c95cd",
			[1587] = "0Gorn#42c^460c077746~Gorn#42c^0c07974a@87 25~0cce782d~0ccd4842",
			[7203] = "0Kim'jael#20e4^460a88837b~Kim'jael#20e4^0a88a37a@350 5~0a9114bd~0a95949e~0a8f64b4~0a9124bb",
			[8603] = "0Torwa Pathfinder#2593^466bb72c1f~Torwa Pathfinder#2593^6bb70c27~6baf5200",
			[7843] = "0Sputtervalve#d72^4661a0f5f1~Wenikee Boltbucket#2464^617d61cb@75 20",
			[7847] = "0Wenikee Boltbucket#2464^46617d51c9~Rilli Greasygob#2465^44c313ea@25 20",
			[5805] = "0Hadoken Swiftstrider#1ec3^462ebf96cd~Woodpaw Battle Map#o22b73^2eb748ee",
			[18459] = "0Korfax, Champion of the Light#3ef0^4629c2285b~~",
			[16629] = "0Rutgar Glyphshaper#3b42^4650694e26~Geologist Larksbane#3b4f^507ee5f7",
			[1831] = "0Orcish Orphan#386c^0d6ca8d5d7~Orcish Orphan#386c^44860b18~44860b14",
			[11643] = "0Cork Gizelton#2d69^4623aa4601~Smeed Scrabblescrew#2d4c^239bb9e6@250 20~23abd90d",
			[13689] = "0Layo Starstrike#33a4^4650d13303~Umber#2ea3^3e725611",
			[985] = "0Apothecary Johaan#5ee^466998085c~Captured Mountaineer#8a3^699e3836",
			[17149] = "0Vargus#3b48^465082c634~~~~~~",
			[9621] = "0Felnok Steelspring#28e4^46729d762c~Tinkee Steamboil#281b^16a6e3d2",
			[2131] = "0Apothecary Zamah#d5b^46683a934c~Apothecary Lydon#8a8^389d330e@250 3e",
			[1339] = "0Shakes O'Breen#a32^4604528d06~Fleet Master Seahorn#9b7^55458c4c@250 5",
			[5909] = "0Stone Watcher of Norgannon#1eee^4659603cfe~Uldum Pedestal#o22c07^59605cff~59605d03",
			[8989] = "0Zilzibin Drumlore#1b62^464490576b~Alchemist Pestlezugg#15da^59823450@3 25",
			[1547] = "0Seer Wiserunner#ba8^463f53d5c6~Ancestral Spirit#bb2^3f9d235c",
			[17375] = "0Combat Task Briefing VII^46507e65eb~~503df9f536b9ee3618c942d968490acf534a3455fa235d3a3f538a2c3d0b24",
			[14979] = "0Talo Thornhoof#1e60^462ec2b6ff~Talo Thornhoof#1e60^2ec2a6ff~24972736",
			[5869] = "~Apothecary Lydon#8a8^389d230e@250 41~644f5b37",
			[5873] = "0Master Gadrin#c74^46268f0bf1~Master Gadrin#c74^268efbf2@500 a~7463132e",
			[5877] = "0Apothecary Lydon#8a8^46389d3310~Master Apothecary Faranell#807^6c7c2b18@125 25",
			[18867] = "0Wizlo Bearingshiner#2abd^466736f531~Wizlo Bearingshiner#2abd^6736b531@150 3e~2ee77768",
			[1359] = "0Drum Fel#ad3^4604bdb568~Drum Fel#ad3^04bda568@62 25~04376ab632da5c301a8931baae323ad2331b01364aee~04329a68317a85320acb",
			[10327] = "0Umi Rumplesnicker#2841^46729bc604~Umi Rumplesnicker#2841^729bc605@350 c~729d4627~5982b44b~6b6fc17b",
			[9733] = "0Ragged John#255b^4616a673c8~~",
			[7565] = "0Arch Druid Hamuul Runetotem#1689^4668c8748f~Bashana Runetotem#237f^68b58561@10 3e",
			[1385] = "0Theldurin the Lost#ae1^460c835c46~Theldurin the Lost#ae1^0c837c48~0c8ecda1~0c8aed5f~0c87fdbd",
			[11803] = "0Mickey Levine#2d5f^4669d4db8e~~",
			[17469] = "0Forest Wisp#3d08^465a6027a3~Keeper Remulos#2e38^3e5cd6af",
			[819] = "0Gunther Arcanus#5d9^4669ae56b7~Gunther Arcanus#5d9^69ae56b7@150 41~69aa3734",
			[7963] = "0Galamav the Marksman#2379^460c0ef79d~",
			[1293] = "0Trollbane's Tomb#oa8f^46044a1988~Zengu#a8f^04bcc569@350 a",
			[861] = "0Apothecary Renferrel#791^46526db685~Quinn Yorick#79f^5288b207@150 41",
			[17145] = "0Vargus#3b48^465082c634~~~~~",
			[5933] = "0Nara Wildmane#168a^4668c1b502~Uldum Pedestal#o22c07^59605cff@250 3e",
			[5937] = "0Nara Wildmane#168a^4668c124f6~Sage Truthseeker#f8a^6858978a@250 3e",
			[715] = "~Bethor Iceshard#5da^6cd6c2b4@150 41~69adf6ba",
			[17147] = "0Vargus#3b48^465082c634~~~~~~",
			[13691] = "0Umber#2ea3^463e725611~Rabine Saturna#2e19^3e84172d",
			[957] = "0Dalaran Crate#o65b^46527fa9a4~Shadow Priest Allister#849^5270868c@150 41",
			[3601] = "0Orcish Orphan#386c^0d44b5a412~Orcish Orphan#386c^6ca8d5d7~6ca6a613a8d59e",
			[5683] = "0Nogg#d54^4644c21404~~~",
			[1791] = "0WANTED#of84^4661a015fe~Gazlowe#d3f^61a035cc@250 20~61a017f2",
			[10407] = "0Captured Arko'narin#2b08^462d5ca8df~Jessir Moonbow#2b0b^2d834d1e~2d5a996d",
			[1433] = "0Lucien Tosselwrench#b68^460c42271a~~",
			[843] = "0Dalar Dawnweaver#792^465271365f~Dalar Dawnweaver#792^52712660@250 41~5286143986d43688744587047b86346f",
			[21849] = "0Sab'aoth#57cf^4642a9aabe~Sab'aoth#57cf^42a9aabc~428d5a258b49c68bc9a58ae99b8909a089c99b8b39528aa936",
			[891] = "0Apothecary Johaan#5ee^466998085c~Apothecary Renferrel#791^526db685",
			[17857] = "0Mux Manascrambler#3e8e^465986145c~Mux Manascrambler#3e8e^5986245b~",
			[17881] = "0Mokvar#3e8c^464458f613~Mokvar#3e8c^4458f613~~",
			[8043] = "0Regthar Deathgate#d3d^466173e48b~Regthar Deathgate#d3d^6173e48b@87 25~6171847d",
			[5207] = "0Bloodmage Lynnore#1d52^4614815246~~148b15cd9095fc~1479431172a463",
			[15451] = "0Zorbin Fandazzle#392d^462e72a6ed~Zorbin Fandazzle#392d^2e7296ed~2e71180d73384d7147f071e77a7177ff71b7e073e85c7247737167e371780674385e77f938766933",
			[5533] = "0OOX-22/FE Distress Beacon^462e7b47cd~Homing Robot OOX-22/FE#1e7f^2e8878e7@250 5",
			[735] = "0Apothecary Johaan#5ee^466998085c~Apothecary Johaan#5ee^6998085c~699509939389ed9529f997d9f6972997",
			[1765] = "0Jorn Skyseer#d3b^466172a972~Jorn Skyseer#d3b^6172a971@350 3e~619944de",
			[1377] = "0Keystone#oa80^46045be94d~Zaruk#ae3^04be55af",
			[2241] = "0Kravel Koalbeard#1164^4667c6ec53~Gnome Pit Boss#118f^67c65c50",
			[20833] = "0Voren'thal the Seer#4862^464f6d2e9c~Voren'thal the Seer#4862^4f6d2e9c~",
			[2243] = "0Kravel Koalbeard#1164^4667c6ec53~",
			[17843] = "0Mux Manascrambler#3e8e^465986045c~Mux Manascrambler#3e8e^5986245b~~~~1685d80e8536c47f76dd7d26e676d6ee70a6f86f472a6d571e6b47176ef6b56aa6dc680702",
			[1639] = "0Chen's Empty Keg^46618e9334~Brewmaster Drohn#cdc^619f4621",
			[22195] = "0Commander Hobb#5b8a^464e90895b~Overlord Mor'ghor#5a63^4ea92db3~4e91a94a",
			[14137] = "~Uthel'nay#1c8f^44641dc6@500 a~2349691a4798be47a8bd47991b46994f",
			[1805] = "0Control Console#o102d^46618601dc~Sputtervalve#d72^61a0f5f1@250 20",
			[1061] = "0Raleigh Andrean#802^466c9fa6e8~Raleigh Andrean#802^6c9f86ea@63 25~52757da7",
			[1643] = "0Brewmaster Drohn#cdc^46619f4621~Brewmaster Drohn#cdc^619f4622~6195669396168f95b68597e69597c687~617f775e7f977a88f80a89683589d83a~617af9b0",
			[22047] = "0Sky Sergeant Vanderlip#5a50^4613469870~Sky Sergeant Vanderlip#5a50^13466870~134b4c32462bf2467c144bfd284d6d584bed6d4c2d545406a354369c54e6b95516c551971f50e71252d6d55186c7",
			[22133] = "0Skyguard Khatie#5b27^4613478838~Skyguard Khatie#5b27^13476838~1350f91a4d87cd4d87ce4e683c534986",
			[22747] = "0Wind Trader Zhareem#5f31^464fbf85e9~~",
			[10101] = "0Jeremiah Payson#20d3^466cac76fe~Janice Felstone#2a1a^6f6218a5",
			[22249] = "0Krog#133e^46285d0515~Inspector Tarem#5c0f^284c179b",
			[903] = "0Apothecary Renferrel#791^46526da685~Master Apothecary Faranell#807^6c7bdb22@125 25~52bcb5a1ba55c6b825dfb7d595b4959eb40600~52bf834bc45384c45384c533fcc433c1c863a4~5299e2be",
			[14003] = "0Frostwolf Stable Master#3530^460291ed2d~~",
			[16609] = "0Commander Mar'alith#3b4d^46507de57b~Commander Mar'alith#3b4d^507dc57b~50686e2c~50698e1e",
		},
		["Version"] = 0.42,
		["NPC"] = {
			["?~Ontok Shatterhorn"] = "79^bbc900^1^M0",
			["?~Yugrek"] = "114^9aa5ce^1^G",
			["?~Shyn"] = "46^c0d713^1^G",
			["?~Himmik"] = "114^9cd640^1^M0",
			["?~Gahroot"] = "97^72797c^1^M0",
			["?~Patrice Dwyer"] = "82^6de6b3^1^M0",
			["?~Tonga Runetotem"] = "97^85851a^1^G",
			["?~Fantei"] = "79^a2eb0b^1^M0",
			["?~Loh'atu"] = "10^1d0c7a^1^G",
			["?~Innkeeper Abeqwa"] = "103^75c839^1^M0",
			["?~Lizzarik"] = "97^85f4e8^1^M1",
			["?~Doctor Gregory Victor"] = "4^bba5e0^1^G",
			["?~Kaja"] = "68^85a9f4^1^M1",
			["?~Raliq the Drunk"] = "79^bf9507^1^G",
			["?~Vhulgra"] = "5^bb19d5^1^G",
			["?~Eunice Burch"] = "108^a00719^1^T",
			["?~Shelene Rhobart"] = "105^a7599a^1^T",
			["?~Cersei Dusksinger"] = "88^79e8bf^1^G",
			["?~Bragok"] = "97^a145ef^1^G",
			["?~Michael Garrett"] = "108^a177b5^1^G",
			["?~Huklah"] = "38^67fad7^1^M1",
			["?~Donova Snowden"] = "114^501736^1^G",
			["?~Zapetta"] = "105^9b3963^1^G",
			["?~Seril Scourgebane"] = "114^9cd5f1^1^G",
			["?~Zansoa"] = "38^8f8bba^1^M0",
			["?~Urda"] = "4^bb0539^1^G",
			["?~Jinar'Zillen"] = "35^397ba8^1^G",
			["?~Blixxrak"] = "114^9da610^1^M1",
			["?~Regthar Deathgate"] = "97^73e48b^1^G",
			["?~Precious"] = "107^863b24^1^G",
			["?~Lui'Mala"] = "35^3a4b92^1^T",
			["?~Gornek"] = "38^6baaec^1^G",
			["?~Umber"] = "62^7285e0^1^G",
			["?~Ronald Burch"] = "108^9f36fb^1^M0",
			["?~Hekkru"] = "88^7448c3^1^G",
			["?~Varimathras"] = "108^904ead^1^G",
			["?~Father Inigo Montoy"] = "41^c18861^1^G",
			["?~Torwa Pathfinder"] = "107^b70c27^1^G",
			["?~Altar of Hakkar"] = "87^b2f875^1^G",
			["?~Warden Haro"] = "80^82a635^1^G",
			["?~Larion"] = "107^747160^1^G",
			["?~Trayexir"] = "38^905bb2^1^M1",
			["?~Brumn Winterhoof"] = "4^488740^1^G",
			["?~Geenia Sunshadow"] = "62^84d543^1^M1",
			["?~Deathmaster Dwire"] = "4^bb74bf^1^G",
			["?~Tajarri"] = "62^5d766d^1^G",
			["?~Turhaw"] = "103^744829^1^M0",
			["?~Karos Razok"] = "82^74a6cf^1^G",
			["?~Sanuye Runetotem"] = "97^73496e^1^M1",
			["?~Cavindra"] = "60^4daa58^1^G",
			["?~Greta Mosshoof"] = "45^82bd1e^1^G",
			["?~K'waii"] = "38^901bba^1^M0",
			["?~Kilram"] = "114^9cb5ee^1^G",
			["?~Elder Torntusk"] = "100^987c70^1^G",
			["?~Officer Dawning"] = "81^a5fc70^1^G",
			["?~Sovik"] = "68^c14402^1^M0",
			["?~Deathguard Dillinger"] = "105^94c837^1^G",
			["?~Witch Doctor Mau'ari"] = "114^9e361f^1^G",
			["?~Wixxrak"] = "114^9da612^1^M1",
			["?~Zjolnir"] = "38^8d2c13^1^G",
			["?~Kayren Soothallow"] = "56^9fb32e^1^M0",
			["?~Gruna"] = "22^a7a3d2^1^M0",
			["?~Spirit of Olum"] = "13^b58777^1^G",
			["?~Hgarth"] = "83^7dc924^1^T",
			["?~Clyde Kellen"] = "105^ab7822^1^T",
			["?~Mai'Lahii"] = "35^3a0b84^1^M0",
			["?~Montarr"] = "103^73a81e^1^M0",
			["?~Thultazor"] = "88^752877^1^M0",
			["?~Innkeeper Jayka"] = "83^7969ec^1^M0",
			["?~Barg"] = "97^8404cb^1^M0",
			["?~Rohan the Assassin"] = "41^c19868^1^G",
			["?~Jun'ha"] = "4^b9e5d4^1^M0",
			["?~Warsong Runner"] = "5^1f3574^1^G",
			["?~Korfax, Champion of the Light"] = "41^c2285b^1^G",
			["?~Rayne"] = "41^c0f87f^1^G",
			["?~Beaten Corpse"] = "97^7e180b^1^G",
			["?~Zaetar's Spirit"] = "60^4d9a57^1^G",
			["?~Tydormu"] = "23^9227f6^1^M1",
			["?~Qia"] = "114^9c95f0^1^M0",
			["?~Wrahk"] = "97^858511^1^M0",
			["?~Smith Hauthaa"] = "119^811685^1^M1",
			["?~Screecher Spirit"] = "46^939786^1^G",
			["?~Tablet of Theka"] = "116^63132e^1^G",
			["?~My'lanna"] = "62^721573^1^M0",
			["?~Starn"] = "103^730819^1^M1",
			["?~Ragged John"] = "22^a673c8^1^G",
			["?~Bar Talet"] = "96^7dc746^1^M1",
			["?~Jessir Moonbow"] = "45^834d1d^1^G",
			["?~Arch Druid Hamuul Runetotem"] = "104^c8648e^1^G",
			["?~Gordon Wendham"] = "108^9dd6a7^1^M1",
			["?~Xizzer Fizzbolt"] = "114^9b862a^1^M0",
			["?~Uthel'nay"] = "68^641dc6^1^G",
			["?~Bluffwatcher"] = "104^6d2902^1^G",
			["?~Zarise"] = "56^99f2f8^1^G",
			["?~Abe Winters"] = "105^9a187e^1^M1",
			["?~Omusa Thunderhorn"] = "97^71b972^1^G",
			["?~Tari'qa"] = "97^8424cd^1^M0",
			["?~Nargal Deatheye"] = "97^8304ab^1^M1",
			["?~Coreiel"] = "64^6d86cb^1^M1",
			["?~Osrok the Immovable"] = "64^8f55fb^1^M1",
			["?~Guillaume Sorouy"] = "82^6e568a^1^T",
			["?~Technician Halmaha"] = "79^47e78c^1^M1",
			["?~Tukk"] = "35^3ffb7b^1^M0",
			["?~Hemet Nesingwary Jr."] = "85^5b31b8^1^G",
			["?~Tawny Grisette"] = "108^9e56e8^1^M0",
			["?~Nakodu"] = "79^9eeb0d^1^M0",
			["?~Dirge Quikcleave"] = "89^86647d^1^M0",
			["?~Senani Thunderheart"] = "5^bc89d2^1^G",
			["?~Mankrik"] = "97^84e50a^1^G",
			["?~Mrs. Winters"] = "105^9c586c^1^M0",
			["?~Aranae Venomblood"] = "56^9db325^1^T",
			["?~Denni'ka"] = "83^bbff3f^1^M0",
			["?~Evie Whirlbrew"] = "114^9b5609^1^M0",
			["?~Innkeeper Bates"] = "82^6ea69a^1^G",
			["?~Tarban Hearthgrain"] = "97^8cf520^1^M0",
			["?~Deathstalker Mortis"] = "4^bbe4c5^1^G",
			["?~Hamlin Atkins"] = "105^98c846^1^M0",
			["?~Darnall"] = "62^83d551^1^M0",
			["?~Narianna"] = "62^8806d7^1^M1",
			["?~Fyr Mistrunner"] = "104^68e895^1^M0",
			["?~Northern Crystal Pylon"] = "107^9071f6^1^G",
			["?~Vehena"] = "68^60adfd^1^G",
			["?~Breyk"] = "88^75b8b9^1^G",
			["?~Krond"] = "83^764958^1^M0",
			["?~Jorn Skyseer"] = "97^72a971^1^G",
			["?~Packmaster Stonebruiser"] = "41^bee854^1^G",
			["?~Dargon"] = "62^7c6647^1^M0",
			["?~Tharm"] = "83^738990^1^G",
			["?~Hae'Wilani"] = "35^41db56^1^M1",
			["?~Tinkerwiz"] = "97^a055ce^1^T",
			["?~Nez'raz"] = "85^5054c9^1^G",
			["?~Andruk"] = "5^1f2569^1^G",
			["?~Mor'rogal"] = "83^78aa40^1^G",
			["?~Karus"] = "68^7efb15^1^G",
			["?~Vindicator Moorba"] = "121^711752^1^G",
			["?~Thultash"] = "88^76c8a0^1^M0",
			["?~Hin Denburg"] = "105^9e0971^1^G",
			["?~Watcher Du'una"] = "85^52a49d^1^G",
			["?~Kroum"] = "10^3827f0^1^G",
			["?~Gharash"] = "88^740838^1^M1",
			["?~Serge Hinott"] = "56^9d3310^1^T",
			["?~Craftsman Wilhelm"] = "41^c04894^1^M1",
			["?~Georgia"] = "41^be5833^1^G",
			["?~Bloodmage Lynnore"] = "20^81b246^1^G",
			["?~Advisor Sorrelon"] = "82^6ec686^1^G",
			["?~Garul"] = "79^45a800^1^M0",
			["?~Yeh'kinya"] = "89^ab2394^1^G",
			["?~Western Crystal Pylon"] = "107^3da972^1^G",
			["?~Tatternack Steelforge"] = "97^736938^1^G",
			["?~Rabine Saturna"] = "62^84172d^1^G",
			["?~Alchemist Pestlezugg"] = "89^82344f^1^M0",
			["?~Jediga"] = "10^39b835^1^G",
			["?~Jim Saltit"] = "79^a23af6^1^M0",
			["?~Innkeeper Fizzgrimble"] = "89^864477^1^G",
			["?~Spirit of Udalo"] = "13^b58777^1^G",
			["?~Field Repair Bot 110G"] = "121^711752^1^M1",
			["?~G'eras"] = "79^8146bb^1^M0",
			["?~Zachariah Post"] = "105^991866^1^M0",
			["?~Rutherford Twing"] = "4^bb74c2^1^M1",
			["?~Okuno"] = "13^b58777^1^M1",
			["?~Nyse"] = "103^7367dd^1^G",
			["?~Garon Hutchins"] = "80^860629^1^G",
			["?~Rand Rhobart"] = "105^a77997^1^T",
			["?~Nixxrak"] = "114^9da610^1^M1",
			["?~Warlord Goretooth"] = "12^07e7a4^1^G",
			["?~Deathguard Burgess"] = "105^9b9853^1^G",
			["?~Innkeeper Sikewa"] = "35^3daae6^1^M0",
			["?~Windcaller Proudhorn"] = "80^82f619^1^G",
			["?~Bloodmage Drazial"] = "20^818245^1^G",
			["?~Jazzrik"] = "12^6c9868^1^M1",
			["?~Vizzklick"] = "89^82845d^1^M0",
			["?~Karang Amakkar"] = "5^1e8583^1^G",
			["?~Naal Mistrunner"] = "104^828858^1^M0",
			["?~Tinkee Steamboil"] = "22^a703d9^1^G",
			["?~Je'neu Sancrea"] = "5^1dc57a^1^G",
			["?~Innkeeper Gryshka"] = "68^8abae7^1^G",
			["?~Thalon"] = "35^374bd6^1^G",
			["?~Stone Watcher of Norgannon"] = "89^605cff^1^G",
			["?~Archmage Angela Dosantos"] = "41^c18862^1^G",
			["?~Greth"] = "12^09879f^1^G",
			["?~Daio the Decrepit"] = "20^574807^1^G",
			["?~Lauren Newcomb"] = "108^a43617^1^M1",
			["?~Gruul Darkblade"] = "10^39082c^1^M1",
			["?~Haldor the Compulsive"] = "79^7a1439^1^M0",
			["?~Rahauro"] = "104^b3b4b4^1^G",
			["?~Testing Equipment"] = "108^79eba7^1^G",
			["?~Innkeeper Shay"] = "56^a0630a^1^G",
			["?~Buzzek Bracketswing"] = "89^85b471^1^T",
			["?~Sranda"] = "12^076790^1^M1",
			["?~Ag'tor Bloodfist"] = "10^391839^1^G",
			["?~Doctor Martin Felben"] = "108^76abec^1^G",
			["?~Lilith the Lithe"] = "114^9cd5f1^1^G",
			["?~Silvermoon City Guardian"] = "81^976418^1^G",
			["?~Sebastian Meloche"] = "82^6ea69a^1^M1",
			["?~Zilzibin Drumlore"] = "68^90a76f^1^G",
			["?~Liv Rizzlefix"] = "97^9fb62f^1^G",
			["?~Jandia"] = "103^75f838^1^M0",
			["?~Rumstag Proudstrider"] = "104^6e36df^1^G",
			["?~Yuka Screwspigot"] = "22^a8b386^1^M1",
			["?~Witch Doctor Uzer'i"] = "46^be66ee^1^G",
			["?~Quartermaster Miranda Breechlock"] = "41^c1b8a2^1^G",
			["?~Aurel Goldleaf"] = "80^84d614^1^G",
			["?~Aaron Hollman"] = "79^a3bb6c^1^M1",
			["?~Layo Starstrike"] = "80^d13307^1^G",
			["?~Doras"] = "68^741a3a^1^G",
			["?~Dispatch Commander Metz"] = "41^c05847^1^G",
			["?~Daniel Bartlett"] = "108^a4760a^1^M0",
			["?~Karna Remtravel"] = "107^76d226^1^G",
			["?~Lorelae Wintersong"] = "62^7b9662^1^M0",
			["?~Tai'tasi"] = "38^902bc7^1^M0",
			["?~Centaur Pariah"] = "35^722db9^1^G",
			["?~Zaralda"] = "81^d86c9a^1^M0",
			["?~Grawl"] = "12^082760^1^M0",
			["?~Mangletooth"] = "97^71e976^1^G",
			["?~Windcaller Yessendra"] = "80^84d614^1^G",
			["?~Felicia Doan"] = "108^a467f6^1^M0",
			["?~Linken"] = "107^726150^1^G",
			["?~Kosco Copperpinch"] = "4^bd84ac^1^M0",
			["?~Gryfe"] = "107^7370f2^1^G",
			["?~Marvon Rivetseeker"] = "89^86d757^1^G",
			["?~Kuna Thunderhorn"] = "104^77b75d^1^M1",
			["?~Innkeeper Norman"] = "108^ad361f^1^M0",
			["?~Zannok Hidepiercer"] = "80^d172d7^1^M0",
			["?~Tal"] = "104^7797f5^1^G",
			["?~Masat T'andr"] = "88^43450b^1^M0",
			["?~Aendel Windspear"] = "80^a017f5^1^G",
			["?~Steward of Time"] = "89^a8e7f2^1^G",
			["?~Gregor Greystone"] = "114^9cc638^1^G",
			["?~Jeremiah Payson"] = "108^abe704^1^M0",
			["?~Alessandro Luca"] = "108^9518d5^1^M0",
			["?~Bulkrek Ragefist"] = "89^840413^1^G",
			["?~Koma"] = "68^7fbaf3^1^G",
			["?~Doctor Herbert Halsey"] = "108^79cbb1^1^T",
			["?~Aluyen"] = "13^b58777^1^M0",
			["?~Simone the Inconspicuous"] = "107^867b2e^1^G",
			["?~Horthus"] = "68^74a915^1^M0",
			["?~Tharlidun"] = "4^bd254f^1^G",
			["?~Jawn Highmesa"] = "103^758839^1^M0",
			["?~Spraggle Frock"] = "107^6f8156^1^G",
			["?~Bashana Runetotem"] = "104^b52561^1^M0",
			["?~Innkeeper Vizzie"] = "114^9cc634^1^M0",
			["?~Mishiki"] = "38^8dcbff^1^T",
			["?~Vargus"] = "80^82a635^1^M1",
			["?~Thysta"] = "85^5334af^1^G",
			["?~Aboda"] = "35^3fbafe^1^G",
			["?~Gorrik"] = "12^0a7727^1^G",
			["?~Wizlo Bearingshiner"] = "103^36b531^1^G",
			["?~Undercity Guardian"] = "108^9c177d^1^G",
			["?~Ralston Farnsley"] = "108^b7e49a^1^G",
			["?~Eastern Crystal Pylon"] = "107^c5a7fd^1^G",
			["?~Maggran Earthbinder"] = "83^7899c2^1^G",
			["?~Awenasa"] = "103^74f824^1^G",
			["?~Chemist Fuely"] = "108^793ba2^1^G",
			["?~Keyl Swiftclaw"] = "80^84664b^1^G",
			["?~Gorrim"] = "45^83ad23^1^G",
			["?~Thrumn"] = "104^6029ff^1^M0",
			["?~Nergal"] = "107^6ec139^1^M0",
			["?~Cyrus Therepentous"] = "22^f2b50f^1^G",
			["?~Huntsman Leopold"] = "41^c1a867^1^G",
			["?~Daeolyn Summerleaf"] = "62^733586^1^M0",
			["?~Officer Gothena"] = "108^9ec730^1^G",
			["?~Lunnix Sprocketslip"] = "114^9df62b^1^M0",
			["?~Keeper Remulos"] = "62^5ce6b0^1^G",
			["?~Andrew Hilbert"] = "82^6e6682^1^M0",
			["?~Vahgruk"] = "22^a7b3dd^1^G",
			["?~Squibby Overspeck"] = "85^5094b3^1^G",
			["?~Thorkaf Dragoneye"] = "12^a00932^1^G",
			["?~Devrak"] = "97^83a4d8^1^G",
			["?~Sha'ni Proudtusk's Remains"] = "22^cc8744^1^G",
			["?~Nyrill"] = "10^43a761^1^G",
			["?~Tablet of the Seven"] = "22^89f683^1^G",
			["?~Wind Trader Lathrai"] = "79^b8e4e9^1^M0",
			["?~Almaador"] = "79^8316b4^1^M0",
			["?~Zephyr"] = "79^bf7508^1^G",
			["?~Officer Thunderstrider"] = "104^6cc917^1^G",
		},
	},
	["NXQOpts"] = {
		["NXWPriDist"] = 1,
		["NXWHideDist"] = 20000,
		["NXWPriGroup"] = -100,
		["NXWWatchParty"] = true,
		["NXWHideUnfinished"] = false,
		["NXShowHeaders"] = true,
		["NXWPriComplete"] = 50,
		["NXWHideNotInZone"] = false,
		["NXWHideGroup"] = false,
		["NXShowObj"] = false,
		["Version"] = 0.12,
		["NXWPriLevel"] = 20,
		["NXWVisMax"] = 10,
		["NXWHideNotInCont"] = false,
		["NXSortWatchMode"] = 1,
		["NXWShowOnMap"] = true,
	},
	["NXFav"] = {
		{
			{
				"N~#~?~$134ab6c5", -- [1]
				"N~#~?~$134b772d", -- [2]
				"N~#~?~$1349b796", -- [3]
				"N~#~?~$13497809", -- [4]
				"N~#~?~$13490861", -- [5]
				"N~#~?~$134bb8da", -- [6]
				"N~#~?~$1352c910", -- [7]
				"N~#~?~$13465921", -- [8]
				"N~#~?~$134a79a5", -- [9]
				"N~#~?~$13480a75", -- [10]
				"N~#~?~$13497ad3", -- [11]
				"N~#~?~$134d6b1a", -- [12]
				"N~#~?~$13480b5c", -- [13]
				"N~#~?~$134caba9", -- [14]
				"N~#~?~$138fa5ba", -- [15]
				"N~#~?~$1391b586", -- [16]
				"N~#~?~$13909529", -- [17]
				"N~#~?~$138d54db", -- [18]
				"N~#~?~$138bf493", -- [19]
				"N~#~?~$138b441c", -- [20]
				"N~#~?~$13a632ea", -- [21]
				"N~#~?~$13a8531e", -- [22]
				"N~#~?~$13a9b366", -- [23]
				"N~#~?~$13ab139a", -- [24]
				"N~#~?~$13ab8411", -- [25]
				"N~#~?~$13acb455", -- [26]
				"N~#~?~$136257ea", -- [27]
				"N~#~?~$1366381d", -- [28]
				"N~#~?~$13646856", -- [29]
				"N~#~?~$136518a4", -- [30]
				"N~#~?~$13630901", -- [31]
				"N~#~?~$13600964", -- [32]
				"N~#~?~$13693d60", -- [33]
				"N~#~?~$136b1d32", -- [34]
				"N~#~?~$136f3d18", -- [35]
				"N~#~?~$1372acb0", -- [36]
				"N~#~?~$1376ccb5", -- [37]
				"N~#~?~$13740d13", -- [38]
				["ID"] = 3001,
				["Name"] = "Blade's Edge Mountains",
			}, -- [1]
			{
				"N~#~?~$374ec5b5", -- [1]
				"N~#~?~$37492667", -- [2]
				"N~#~?~$3741f731", -- [3]
				"N~#~?~$373fe7d9", -- [4]
				"N~#~?~$373cd89d", -- [5]
				"N~#~?~$373de921", -- [6]
				"N~#~?~$373ea9bd", -- [7]
				"N~#~?~$3741ba6a", -- [8]
				"N~#~?~$37492aaa", -- [9]
				"N~#~?~$374d0b1d", -- [10]
				"N~#~?~$37501aaa", -- [11]
				"N~#~?~$37536a19", -- [12]
				"N~#~?~$375a19ac", -- [13]
				"N~#~?~$375ca92d", -- [14]
				"N~#~?~$37610891", -- [15]
				"N~#~?~$3766a840", -- [16]
				"N~#~?~$376e1869", -- [17]
				"N~#~?~$37737863", -- [18]
				"N~#~?~$37774801", -- [19]
				"N~#~?~$377688dc", -- [20]
				"N~#~?~$37818852", -- [21]
				"N~#~?~$37659a14", -- [22]
				"N~#~?~$3766aa98", -- [23]
				"N~#~?~$376a3aef", -- [24]
				"N~#~?~$3772fae3", -- [25]
				"N~#~?~$37770a53", -- [26]
				"N~#~?~$377b6ae9", -- [27]
				"N~#~?~$37808b74", -- [28]
				"N~#~?~$37846ae9", -- [29]
				"N~#~?~$378b8b74", -- [30]
				"N~#~?~$37923ad2", -- [31]
				"N~#~?~$37958b5d", -- [32]
				"N~#~?~$379b7b00", -- [33]
				"N~#~?~$379ecb8b", -- [34]
				"N~#~?~$377236c9", -- [35]
				"N~#~?~$37759724", -- [36]
				"N~#~?~$377687a7", -- [37]
				"N~#~?~$37ab4b7b", -- [38]
				"N~#~?~$37acdbf4", -- [39]
				"N~#~?~$37ad8c68", -- [40]
				"N~#~?~$37a90c96", -- [41]
				"N~#~?~$37a4bc36", -- [42]
				"N~#~?~$37a28bd1", -- [43]
				"N~#~?~$377c5849", -- [44]
				["ID"] = 3002,
				["Name"] = "Hellfire Peninsula",
			}, -- [2]
			{
				"N~#~?~$40925411", -- [1]
				"N~#~?~$408da475", -- [2]
				"N~#~?~$4093d4ec", -- [3]
				"N~#~?~$4099f475", -- [4]
				"N~#~?~$409a951a", -- [5]
				"N~#~?~$4064c695", -- [6]
				"N~#~?~$4063c711", -- [7]
				"N~#~?~$4068179d", -- [8]
				"N~#~?~$406ac634", -- [9]
				"N~#~?~$4070868f", -- [10]
				"N~#~?~$4074573c", -- [11]
				"N~#~?~$4070479d", -- [12]
				"N~#~?~$404fe7c3", -- [13]
				"N~#~?~$405c2737", -- [14]
				"N~#~?~$4056679d", -- [15]
				"N~#~?~$405ba82f", -- [16]
				"N~#~?~$4052886a", -- [17]
				"N~#~?~$404d884a", -- [18]
				"N~#~?~$40c01c1f", -- [19]
				"N~#~?~$40c1fc85", -- [20]
				"N~#~?~$40c3ecf7", -- [21]
				["Name"] = "Nagrand",
				["ID"] = 3003,
			}, -- [3]
			{
				"N~#~?~$4245e622", -- [1]
				"N~#~?~$4245068b", -- [2]
				"N~#~?~$424716da", -- [3]
				"N~#~?~$4249b643", -- [4]
				"N~#~?~$42952a1a", -- [5]
				"N~#~?~$42985a27", -- [6]
				"N~#~?~$4294da83", -- [7]
				"N~#~?~$429afa8a", -- [8]
				"N~#~?~$429c6a27", -- [9]
				"N~#~?~$4296ead8", -- [10]
				"N~#~?~$427bcd82", -- [11]
				"N~#~?~$42797d40", -- [12]
				"N~#~?~$427aacd8", -- [13]
				"N~#~?~$42751d0c", -- [14]
				"N~#~?~$42785c8f", -- [15]
				"N~#~?~$42723c89", -- [16]
				"N~#~?~$42715c4e", -- [17]
				"N~#~?~$423d064b", -- [18]
				"N~#~?~$423d36a6", -- [19]
				"N~#~?~$423f36c4", -- [20]
				"N~#~?~$424376ed", -- [21]
				"N~#~?~$429495e1", -- [22]
				"N~#~?~$42939661", -- [23]
				"N~#~?~$429576f5", -- [24]
				"N~#~?~$42994742", -- [25]
				"N~#~?~$42a2e765", -- [26]
				"N~#~?~$42a9471c", -- [27]
				"N~#~?~$42a9163b", -- [28]
				"N~#~?~$42a5d5ab", -- [29]
				"N~#~?~$429c8565", -- [30]
				"N~#~?~$4297058c", -- [31]
				"N~#~?~$427eb2c3", -- [32]
				"N~#~?~$429b02cc", -- [33]
				"N~#~?~$429db23f", -- [34]
				"N~#~?~$42344ac2", -- [35]
				"N~#~?~$42324b18", -- [36]
				"N~#~?~$4233ebe6", -- [37]
				"N~#~?~$425404b5", -- [38]
				"N~#~?~$4256544a", -- [39]
				"N~#~?~$425943e8", -- [40]
				"N~#~?~$42594365", -- [41]
				"N~#~?~$425c92f0", -- [42]
				"N~#~?~$42a7da23", -- [43]
				"N~#~?~$42a529d3", -- [44]
				"N~#~?~$42a0298d", -- [45]
				"N~#~?~$429a59a5", -- [46]
				"N~#~?~$4294497f", -- [47]
				"N~#~?~$428f199b", -- [48]
				"N~#~?~$42891950", -- [49]
				"N~#~?~$428448ee", -- [50]
				"N~#~?~$42744b99", -- [51]
				"N~#~?~$426e0b82", -- [52]
				"N~#~?~$4265fc6c", -- [53]
				"N~#~?~$425d9c8c", -- [54]
				"N~#~?~$4253dc9a", -- [55]
				"N~#~?~$424a7cdc", -- [56]
				"N~#~?~$42418cdc", -- [57]
				"N~#~?~$423bfca8", -- [58]
				"N~#~?~$424b5a6c", -- [59]
				"N~#~?~$42457a64", -- [60]
				"N~#~?~$4239fa89", -- [61]
				"N~#~?~$42411a99", -- [62]
				"N~#~?~$42489af3", -- [63]
				"N~#~?~$42497b39", -- [64]
				"N~#~?~$4245db9c", -- [65]
				"N~#~?~$4245dc40", -- [66]
				"N~#~?~$423b3c1b", -- [67]
				"N~#~?~$4232db6f", -- [68]
				["Name"] = "Netherstorm",
				["ID"] = 3004,
			}, -- [4]
			{
				"N~#~稀有~$4ea3392b", -- [1]
				"N~#~稀有~$4e9555d2", -- [2]
				"N~#~稀有~$4e74d493", -- [3]
				"N~#~稀有~$4e76aaf6", -- [4]
				"N~#~稀有~$4e4e287e", -- [5]
				"N~#~稀有~$4e72c1ee", -- [6]
				"N~#~稀有~$4e679672", -- [7]
				"N~#~稀有~$4e4de6a7", -- [8]
				"N~#~稀有~$4e6c0af6", -- [9]
				"N~#~稀有~$4e97f732", -- [10]
				"N~#~?~$4e97237b", -- [11]
				"N~#~?~$4e9c236e", -- [12]
				"N~#~?~$4e9ff37b", -- [13]
				"N~#~?~$4ea42382", -- [14]
				"N~#~?~$4ea8d3cb", -- [15]
				"N~#~?~$4eaea45f", -- [16]
				"N~#~?~$4eb084b1", -- [17]
				"N~#~?~$4eb5f4b1", -- [18]
				"N~#~?~$4ebd749c", -- [19]
				"N~#~?~$4e6966ba", -- [20]
				"N~#~?~$4e6c9758", -- [21]
				"N~#~?~$4e719795", -- [22]
				"N~#~?~$4e7657ec", -- [23]
				"N~#~?~$4e8d4ad1", -- [24]
				"N~#~?~$4e8fcb09", -- [25]
				"N~#~?~$4e93eb28", -- [26]
				"N~#~?~$4e98aaff", -- [27]
				"N~#~?~$4e9aea9e", -- [28]
				"N~#~?~$4e9d3a6b", -- [29]
				"N~#~?~$4ea10a00", -- [30]
				"N~#~?~$4e9deac2", -- [31]
				"N~#~?~$4ea38ad6", -- [32]
				"N~#~?~$4ea97b14", -- [33]
				"N~#~?~$4eae7ab8", -- [34]
				"N~#~?~$4eb25ab3", -- [35]
				"N~#~?~$4eb50a8f", -- [36]
				"N~#~?~$4eb95a99", -- [37]
				["Name"] = "Shadowmoon Valley",
				["ID"] = 3005,
			}, -- [5]
			{
				"N~#~?~$6045b9cc", -- [1]
				"N~#~?~$6052e9e1", -- [2]
				"N~#~?~$604ad8b3", -- [3]
				"N~#~?~$60587916", -- [4]
				"N~#~?~$605697ce", -- [5]
				"N~#~?~$6062a8c3", -- [6]
				"N~#~?~$6066c770", -- [7]
				"N~#~?~$606c28dd", -- [8]
				"N~#~?~$607687ed", -- [9]
				"N~#~?~$6073f96e", -- [10]
				"N~#~?~$6083b8ae", -- [11]
				"N~#~?~$6076fa25", -- [12]
				"N~#~?~$60881a15", -- [13]
				"N~#~?~$60842b58", -- [14]
				"N~#~?~$60789aff", -- [15]
				"N~#~?~$607fcbfe", -- [16]
				"N~#~?~$6042fa87", -- [17]
				"N~#~?~$6054fa82", -- [18]
				"N~#~?~$60640a5e", -- [19]
				"N~#~?~$60699a10", -- [20]
				"N~#~?~$6066caea", -- [21]
				"N~#~?~$605d36e3", -- [22]
				"N~#~?~$605c663c", -- [23]
				"N~#~?~$605c6583", -- [24]
				"N~#~?~$605d94e5", -- [25]
				"N~#~?~$6061e46a", -- [26]
				"N~#~?~$606753cc", -- [27]
				"N~#~?~$606bf406", -- [28]
				"N~#~?~$6072340b", -- [29]
				"N~#~?~$6079d415", -- [30]
				"N~#~?~$608263d7", -- [31]
				"N~#~?~$60891355", -- [32]
				"N~#~?~$608f1321", -- [33]
				"N~#~?~$6093f321", -- [34]
				"N~#~?~$60900548", -- [35]
				"N~#~?~$6095556d", -- [36]
				"N~#~?~$609b25b6", -- [37]
				"N~#~?~$6089dba8", -- [38]
				"N~#~?~$608a5b78", -- [39]
				"N~#~?~$608bcb3c", -- [40]
				"N~#~?~$608c2b04", -- [41]
				"N~#~?~$604e76ca", -- [42]
				"N~#~?~$608cc392", -- [43]
				"N~#~?~$608b83e6", -- [44]
				"N~#~?~$608eb3ce", -- [45]
				"N~#~?~$607f129e", -- [46]
				"N~#~?~$607d22ba", -- [47]
				"N~#~?~$607be29a", -- [48]
				"N~#~?~$60b6a845", -- [49]
				"N~#~?~$60b247ae", -- [50]
				"N~#~?~$60ada76b", -- [51]
				"N~#~?~$60a8c703", -- [52]
				"N~#~?~$60a5565c", -- [53]
				"N~#~?~$60a19609", -- [54]
				["ID"] = 3007,
				["Name"] = "Terokkar Forest",
			}, -- [6]
			{
				"N~#~?~$73d07b0e", -- [1]
				"N~#~?~$73d26b99", -- [2]
				"N~#~?~$73d5ac2a", -- [3]
				"N~#~?~$73d98c88", -- [4]
				"N~#~?~$73de0cee", -- [5]
				"N~#~?~$73de0d78", -- [6]
				"N~#~?~$73db2e18", -- [7]
				"N~#~?~$7365ea34", -- [8]
				"N~#~?~$736449b2", -- [9]
				"N~#~?~$7369c903", -- [10]
				"N~#~?~$73ba4d2a", -- [11]
				"N~#~?~$73bfcd9f", -- [12]
				"N~#~?~$73bf2d47", -- [13]
				"N~#~?~$73bf7c58", -- [14]
				"N~#~?~$732db507", -- [15]
				"N~#~?~$732b357c", -- [16]
				"N~#~?~$7327c619", -- [17]
				"N~#~?~$732186d7", -- [18]
				"N~#~?~$731a57a6", -- [19]
				"N~#~?~$731bd85e", -- [20]
				"N~#~?~$735fe66d", -- [21]
				"N~#~?~$7363e603", -- [22]
				"N~#~?~$73679598", -- [23]
				"N~#~?~$7370d529", -- [24]
				"N~#~?~$7375c4fc", -- [25]
				"N~#~?~$737d750d", -- [26]
				"N~#~?~$7386a518", -- [27]
				"N~#~?~$738aa518", -- [28]
				"N~#~?~$738f6566", -- [29]
				"N~#~?~$73bd956c", -- [30]
				"N~#~?~$73bb15dc", -- [31]
				"N~#~?~$73b9564b", -- [32]
				"N~#~?~$73bdd6e8", -- [33]
				"N~#~?~$73c2574d", -- [34]
				"N~#~?~$73c58779", -- [35]
				"N~#~?~$73c807bc", -- [36]
				"N~#~?~$73c8884e", -- [37]
				"N~#~?~$73b62731", -- [38]
				"N~#~?~$73c19816", -- [39]
				"N~#~?~$73c989c4", -- [40]
				"N~#~?~$73c8894f", -- [41]
				"N~#~?~$73c948b8", -- [42]
				"N~#~?~$73b7bbd5", -- [43]
				"N~#~?~$73b56b7d", -- [44]
				"N~#~?~$73ad5b3c", -- [45]
				"N~#~?~$73a7dbb0", -- [46]
				"N~#~?~$73a16b60", -- [47]
				"N~#~?~$73a11ac8", -- [48]
				"N~#~?~$73a1ba5b", -- [49]
				"N~#~?~$73985717", -- [50]
				"N~#~?~$739d86e4", -- [51]
				"N~#~?~$739a9661", -- [52]
				"N~#~?~$739765ed", -- [53]
				"N~#~?~$739475c9", -- [54]
				"N~#~?~$734277a8", -- [55]
				"N~#~?~$7340d734", -- [56]
				"N~#~?~$734026a3", -- [57]
				"N~#~?~$73402636", -- [58]
				"N~#~?~$734175d0", -- [59]
				"N~#~?~$73420373", -- [60]
				"N~#~?~$7337b4d7", -- [61]
				"N~#~?~$734783ee", -- [62]
				"N~#~?~$734164cf", -- [63]
				"N~#~?~$73361421", -- [64]
				"N~#~?~$7339a388", -- [65]
				"N~#~?~$737eca26", -- [66]
				"N~#~?~$7382f9a3", -- [67]
				"N~#~?~$7383492f", -- [68]
				"N~#~?~$737898fc", -- [69]
				"N~#~?~$7370d912", -- [70]
				"N~#~?~$7365392f", -- [71]
				["Name"] = "Zangarmarsh",
				["ID"] = 3008,
			}, -- [7]
			["Name"] = "Notes",
			["T"] = "F",
		}, -- [1]
		["Version"] = 0.13,
	},
	["NXVendorVVersion"] = 0.012,
	["NXInfo"] = {
		["Version"] = 0.24,
	},
}
NxCombatOpts = {
	["Version"] = 0.01,
}
NxMapOpts = {
	["Version"] = 0.26,
	["NXMaps"] = {
		{
			[0] = {
				["NXMapPosX"] = 3720.148659535086,
				["NXPlyrFollow"] = true,
				["NXScaleSave"] = 1.208801087038745,
				["NXWorldShow"] = true,
				["NXMapPosY"] = -457.5538257986569,
				["NXScale"] = 0.08038277255291008,
			},
			[9002] = {
				["NXMapPosX"] = 2114.5,
				["NXPlyrFollow"] = false,
				["NXWorldShow"] = false,
				["NXMapPosY"] = -223.6666666666667,
				["NXScale"] = 4.7259823956962,
			},
			["NXDotRaidScale"] = 1,
			["NXShowUnexplored"] = false,
			[9003] = {
				["NXMapPosX"] = 4740.758788553708,
				["NXPlyrFollow"] = false,
				["NXWorldShow"] = false,
				["NXMapPosY"] = -1174.271055293776,
				["NXScale"] = 0.2067880479552928,
			},
			["NXDotPalScale"] = 1,
			["NXUnexploredAlpha"] = 0.35,
			[9004] = {
				["NXMapPosX"] = 2226.9,
				["NXPlyrFollow"] = false,
				["NXWorldShow"] = false,
				["NXMapPosY"] = 1451.266666666667,
				["NXScale"] = 0.452214617188076,
			},
			["NXMMDockScale"] = 0.4,
			["NXBackgndAlphaFade"] = 0,
			["NXBackgndAlphaFull"] = 1,
			["NXMMDockOnAtScale"] = 0.6,
			["NXIconNavScale"] = 1,
			["NXDotZoneScale"] = 1,
			["NXMMDockAlpha"] = 1,
			["NXDotPartyScale"] = 1,
			["NXMMAlpha"] = 0.1175000925958347,
			["NXDetailAlpha"] = 1,
			["NXPOIAtScale"] = 1,
			["NXAutoScaleOn"] = false,
			["NXDetailScale"] = 2,
			["NXAutoScaleMax"] = 4,
			["NXKillShow"] = false,
			[9008] = {
				["NXWorldShow"] = false,
				["NXPlyrFollow"] = false,
			},
			["NXMMDockScaleBG"] = 0.4,
			["NXMMFull"] = true,
			[9001] = {
				["NXMapPosX"] = 2175.4,
				["NXPlyrFollow"] = false,
				["NXWorldShow"] = false,
				["NXMapPosY"] = -983.0666666666666,
				["NXScale"] = 0.8284632549562797,
			},
			["NXIconScale"] = 1,
			["NXAutoScaleMin"] = 0.01,
		}, -- [1]
	},
}

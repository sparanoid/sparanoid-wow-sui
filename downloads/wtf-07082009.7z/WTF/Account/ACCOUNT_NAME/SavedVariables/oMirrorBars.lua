
oMBDB = {
	["profileKeys"] = {
		["Dispel - 轻风之语"] = "Dispel - 轻风之语",
		["Smers - 海加尔"] = "Smers - 海加尔",
		["缠云格格 - 屠魔山谷"] = "缠云格格 - 屠魔山谷",
		["Salama - 艾萨拉"] = "Salama - 艾萨拉",
		["Frostbolt - 海加尔"] = "Frostbolt - 海加尔",
	},
	["profiles"] = {
		["Dispel - 轻风之语"] = {
		},
		["Smers - 海加尔"] = {
			["pos"] = {
				["FEIGNDEATH"] = "TOP#UIParent#TOP#0#-141.99999597669",
				["EXHAUSTION"] = "TOP#UIParent#TOP#0#-119.00000394881",
				["BREATH"] = "TOP#UIParent#TOP#0#-96.000002384186",
			},
		},
		["缠云格格 - 屠魔山谷"] = {
		},
		["Salama - 艾萨拉"] = {
		},
		["Frostbolt - 海加尔"] = {
		},
	},
}

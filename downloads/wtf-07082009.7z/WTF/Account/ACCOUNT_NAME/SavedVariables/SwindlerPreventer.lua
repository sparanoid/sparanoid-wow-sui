
SwindlerPreventerDB = {
	["profileKeys"] = {
		["Dispel - 轻风之语"] = "Dispel - 轻风之语",
		["Smers - 海加尔"] = "Smers - 海加尔",
		["缠云格格 - 屠魔山谷"] = "缠云格格 - 屠魔山谷",
		["Salama - 艾萨拉"] = "Salama - 艾萨拉",
		["Frostbolt - 海加尔"] = "Frostbolt - 海加尔",
	},
	["profiles"] = {
		["Dispel - 轻风之语"] = {
		},
		["Smers - 海加尔"] = {
			["AD"] = true,
			["Librams"] = true,
			["AQ40"] = true,
			["Darkmoon"] = true,
			["AQ20"] = true,
			["PostToRaid"] = true,
			["ShowCost"] = true,
			["ZG"] = true,
			["Recipes"] = true,
		},
		["缠云格格 - 屠魔山谷"] = {
		},
		["Salama - 艾萨拉"] = {
			["AQ20"] = true,
			["AD"] = true,
			["Recipes"] = true,
			["Librams"] = true,
			["ShowCost"] = true,
			["AQ40"] = true,
			["Darkmoon"] = true,
			["ZG"] = true,
			["PostToRaid"] = true,
		},
		["Frostbolt - 海加尔"] = {
			["AQ20"] = true,
			["AD"] = true,
			["Recipes"] = true,
			["Librams"] = true,
			["ShowCost"] = true,
			["AQ40"] = true,
			["Darkmoon"] = true,
			["ZG"] = true,
			["PostToRaid"] = true,
		},
	},
}
SP_NewItemInfo = {
	[35764] = {
		["i"] = "",
		["note"] = "",
		["b"] = 48000,
	},
	[35763] = {
		["i"] = "",
		["note"] = "",
		["b"] = 48000,
	},
	[35765] = {
		["i"] = "",
		["note"] = "",
		["b"] = 48000,
	},
	[35762] = {
		["i"] = "",
		["note"] = "",
		["b"] = 48000,
	},
}
SP_NewVendorInfo = {
	["Neutral"] = {
		[37504] = {
			"Ontuvo", -- [1]
		},
		[35238] = {
			"Ontuvo", -- [1]
		},
		[35240] = {
			"Ontuvo", -- [1]
		},
		[35242] = {
			"Ontuvo", -- [1]
		},
		[35244] = {
			"Ontuvo", -- [1]
		},
		[35246] = {
			"Ontuvo", -- [1]
		},
		[35248] = {
			"Ontuvo", -- [1]
		},
		[35250] = {
			"Ontuvo", -- [1]
		},
		[35252] = {
			"Ontuvo", -- [1]
		},
		[35254] = {
			"Ontuvo", -- [1]
		},
		[35256] = {
			"Ontuvo", -- [1]
		},
		[35762] = {
			"Indormi", -- [1]
		},
		[35260] = {
			"Ontuvo", -- [1]
		},
		[35262] = {
			"Ontuvo", -- [1]
		},
		[35768] = {
			"Ontuvo", -- [1]
		},
		[35266] = {
			"Ontuvo", -- [1]
		},
		[35268] = {
			"Ontuvo", -- [1]
		},
		[35270] = {
			"Ontuvo", -- [1]
		},
		[35239] = {
			"Ontuvo", -- [1]
		},
		[35241] = {
			"Ontuvo", -- [1]
		},
		[35243] = {
			"Ontuvo", -- [1]
		},
		[35245] = {
			"Ontuvo", -- [1]
		},
		[35247] = {
			"Ontuvo", -- [1]
		},
		[35249] = {
			"Ontuvo", -- [1]
		},
		[35251] = {
			"Ontuvo", -- [1]
		},
		[35253] = {
			"Ontuvo", -- [1]
		},
		[35255] = {
			"Ontuvo", -- [1]
		},
		[35257] = {
			"Ontuvo", -- [1]
		},
		[35259] = {
			"Ontuvo", -- [1]
		},
		[35261] = {
			"Ontuvo", -- [1]
		},
		[35767] = {
			"Ontuvo", -- [1]
		},
		[35769] = {
			"Ontuvo", -- [1]
		},
		[35267] = {
			"Ontuvo", -- [1]
		},
		[35269] = {
			"Ontuvo", -- [1]
		},
		[35271] = {
			"Ontuvo", -- [1]
		},
		[35325] = {
			"Ontuvo", -- [1]
		},
		[35323] = {
			"Ontuvo", -- [1]
		},
		[35322] = {
			"Ontuvo", -- [1]
		},
		[35265] = {
			"Ontuvo", -- [1]
		},
		[35258] = {
			"Ontuvo", -- [1]
		},
		[35766] = {
			"Ontuvo", -- [1]
		},
		[35263] = {
			"Ontuvo", -- [1]
		},
		[35264] = {
			"Ontuvo", -- [1]
		},
		[35763] = {
			"Indormi", -- [1]
		},
		[35764] = {
			"Indormi", -- [1]
		},
		[35765] = {
			"Indormi", -- [1]
		},
	},
	["Horde"] = {
		[19319] = {
			"Grunnda Wolfheart", -- [1]
		},
		[4497] = {
			"Marniel Amberlight", -- [1]
			"Tand", -- [2]
			"Eleanor Rusk", -- [3]
			"Kuruk", -- [4]
		},
		[39489] = {
			"Mertle Murkpen", -- [1]
		},
		[5439] = {
			"Zendo'jian", -- [1]
		},
		[4496] = {
			"Tand", -- [1]
			"Eleanor Rusk", -- [2]
			"Kuruk", -- [3]
			"K'waii", -- [4]
		},
		[4498] = {
			"Marniel Amberlight", -- [1]
			"Tand", -- [2]
			"Eleanor Rusk", -- [3]
			"Kuruk", -- [4]
			"K'waii", -- [5]
		},
		[19320] = {
			"Grunnda Wolfheart", -- [1]
		},
		[11362] = {
			"Zendo'jian", -- [1]
		},
	},
}
SP_NewVendorLocations = {
	["K'waii"] = "Durotar",
	["Tand"] = "Thunder Bluff",
	["Mertle Murkpen"] = "Thunder Bluff",
	["Ontuvo"] = "Shattrath City",
	["Zendo'jian"] = "Orgrimmar",
	["Marniel Amberlight"] = "Eversong Woods",
	["Kuruk"] = "Thunder Bluff",
	["Eleanor Rusk"] = "Undercity",
	["Grunnda Wolfheart"] = "Alterac Valley",
}

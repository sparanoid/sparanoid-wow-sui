
Overachiever_Tabs_Settings = {
	["SuggestionsSort"] = 0,
	["SearchSort"] = 0,
}

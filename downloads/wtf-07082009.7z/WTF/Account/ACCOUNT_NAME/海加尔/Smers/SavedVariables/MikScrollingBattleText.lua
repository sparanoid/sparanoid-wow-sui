
MSBTProfiles_SavedVarsPerChar = {
	["currentProfileName"] = "Smers",
}


DcrCharDB = nil

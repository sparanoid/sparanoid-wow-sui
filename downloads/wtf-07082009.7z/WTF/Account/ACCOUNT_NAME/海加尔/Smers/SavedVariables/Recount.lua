
RecountPerCharDB = {
	["version"] = "1.3",
	["combatants"] = {
	},
	["FightNum"] = 0,
	["CombatTimes"] = {
	},
	["FoughtWho"] = {
	},
}

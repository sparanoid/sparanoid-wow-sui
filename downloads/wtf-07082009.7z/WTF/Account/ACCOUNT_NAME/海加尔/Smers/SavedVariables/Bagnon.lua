
BagnonSets = {
	["inventory"] = {
		["strata"] = "HIGH",
		["parentScale"] = 0.6399999856948853,
		["scale"] = 1,
		["bags"] = {
			0, -- [1]
			1, -- [2]
			2, -- [3]
			3, -- [4]
			4, -- [5]
		},
		["alpha"] = 1,
		["cols"] = 10,
		["y"] = 663.3550163603571,
		["x"] = 1059.850371780241,
		["space"] = 10,
		["bg"] = {
			["a"] = 0.2700000405311585,
			["r"] = 0,
			["g"] = 0.2,
			["b"] = 0,
		},
	},
	["showBagsAtAH"] = 1,
	["showBankAtBank"] = 1,
	["replaceBags"] = 1,
	["showBagsAtVendor"] = 1,
	["version"] = "1.7.3",
	["bank"] = {
		["strata"] = "HIGH",
		["parentScale"] = 0.6399999856948853,
		["scale"] = 1,
		["bags"] = {
			-1, -- [1]
			5, -- [2]
			6, -- [3]
			7, -- [4]
			8, -- [5]
			9, -- [6]
			10, -- [7]
			11, -- [8]
		},
		["cols"] = 12,
		["y"] = 756.4844400214487,
		["x"] = 463.5004355981881,
		["space"] = 10,
		["bg"] = {
			["a"] = 0.2700000405311585,
			["r"] = 0,
			["g"] = 0,
			["b"] = 0.2,
		},
	},
	["showBagsAtMail"] = 1,
	["showBagsAtBank"] = 1,
	["showBagsAtTrade"] = 1,
	["showBorders"] = 1,
}

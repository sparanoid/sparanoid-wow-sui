
Guild2Guild_Vars = {
	["log"] = {
	},
	["ShowNewRelayMessages"] = true,
	["Active"] = true,
	["color"] = "|cff40ff40",
	["Passive"] = false,
	["Startdelay"] = 15,
	["NewAddonDefault"] = false,
	["Debug"] = false,
	["RelayAddonMessages"] = true,
	["debugStack"] = {
	},
	["GuildMemberNotify"] = "1",
	["logging"] = false,
	["logsize"] = 0,
	["Channel"] = "smers",
	["chatTypes"] = {
		["G2G"] = {
			true, -- [1]
			["b"] = 0.250980406999588,
			["g"] = 1.000000059138984,
			["r"] = 0.250980406999588,
		},
	},
	["EchoGuild"] = true,
	["EchoOfficer"] = true,
	["addons"] = {
		["Crb"] = false,
		["BWVB"] = false,
		["Thr"] = true,
		["CGP"] = false,
		["GathX"] = true,
		["BEJEWELED2"] = false,
		["AucAdvAskPrice"] = false,
		["WIM"] = true,
		["DTMR"] = false,
		["WGTime"] = false,
		["GHOSTRECON"] = false,
		["GUILDMAP"] = false,
		["LGP"] = false,
		["HealComm"] = false,
		["BWVB2"] = false,
		["CaN"] = true,
	},
}

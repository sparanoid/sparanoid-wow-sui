
AtlasOptions = {
	["AtlasScale"] = 1.100000023841858,
	["AtlasSortBy"] = 1,
	["AtlasLocked"] = false,
	["AtlasClamped"] = false,
	["AtlasAlpha"] = 1,
	["AtlasZone"] = 6,
	["AtlasAcronyms"] = true,
	["AtlasType"] = 3,
	["AtlasCoords"] = false,
	["AtlasCtrl"] = false,
	["AtlasButtonPosition"] = 356,
	["AtlasRightClick"] = false,
	["AtlasButtonRadius"] = 78,
	["AtlasAutoSelect"] = true,
	["AtlasVersion"] = "1.14.1",
	["AtlasButtonShown"] = false,
}

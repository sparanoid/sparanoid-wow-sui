
BlizzardStopwatchOptions = {
	["position"] = {
		["y"] = 345.9685846273812,
		["x"] = 86.50050988047555,
	},
}

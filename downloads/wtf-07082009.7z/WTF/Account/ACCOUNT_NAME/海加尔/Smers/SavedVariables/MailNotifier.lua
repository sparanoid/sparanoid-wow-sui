
MailNotifier_SV = {
	["senders"] = {
	},
	["unread"] = 0,
}

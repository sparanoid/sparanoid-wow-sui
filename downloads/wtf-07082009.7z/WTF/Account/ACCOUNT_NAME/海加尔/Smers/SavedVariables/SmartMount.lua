
SmartMount_PlayerConfig = {
	["PlayerConfigVersion"] = "PCV1",
	["PCV1"] = {
		["ExcludedMountsWhitelist"] = true,
		["ExcludedMiniPetsWhitelist"] = true,
		["ExcludedMounts"] = {
			[60119] = true,
			[44744] = true,
		},
		["ExcludedMiniPets"] = {
			[28871] = true,
			[27570] = true,
			[12243] = true,
			[10679] = true,
			[28738] = true,
			[40613] = true,
			[33050] = true,
			[10696] = true,
			[45082] = true,
			[10697] = true,
			[16450] = true,
			[10698] = true,
			[36034] = true,
			[15999] = true,
			[40990] = true,
			[10711] = true,
			[54187] = true,
		},
	},
}

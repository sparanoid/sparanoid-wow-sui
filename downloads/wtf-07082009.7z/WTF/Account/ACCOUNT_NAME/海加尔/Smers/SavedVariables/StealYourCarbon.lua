
StealYourCarbonDB = {
	["overstock"] = false,
	["stocklist"] = {
		[30568] = 1,
		[27860] = 20,
		[30570] = 1,
		[17029] = 20,
	},
	["upgradewater"] = false,
	["tradestocklist"] = {
	},
	["chatter"] = false,
}


EasyTrinketDB = {
	["hideminimapbutton"] = 1,
	["disableInBG"] = true,
	["scale"] = 75,
	["rows"] = 1,
	["showcd"] = true,
	["Minimap Button Angle"] = 217,
	["autowhip"] = 3,
	["position"] = {
		["y"] = 271.9375760564569,
		["x"] = 18.99999113380922,
		["point"] = "BOTTOMLEFT",
		["relativePoint"] = "BOTTOMLEFT",
	},
	["minimapbutton"] = 3,
	["Minimap Button"] = {
		["angle"] = 172,
	},
}


FluidFramesModifiedFrames = {
	["StaticPopup1"] = {
		["parent"] = "UIParent",
		["point"] = {
			{
				"TOP", -- [1]
				"UIParent", -- [2]
				"TOP", -- [3]
				0, -- [4]
				-132.9999999254942, -- [5]
			}, -- [1]
		},
		["immobilized"] = {
			["point"] = {
				"BOTTOMLEFT", -- [1]
				"UIParent", -- [2]
				"BOTTOMLEFT", -- [3]
				629.9999524652965, -- [4]
				634.3438626178523, -- [5]
			},
		},
	},
}
FluidFrames_SavedVars = nil

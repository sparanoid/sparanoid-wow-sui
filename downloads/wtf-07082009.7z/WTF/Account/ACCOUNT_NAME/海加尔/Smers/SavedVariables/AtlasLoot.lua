
AtlasLootCharDB = {
	["QuickLooks"] = {
		{
			"T456PriestShadow", -- [1]
			"", -- [2]
			"", -- [3]
			{
				"TOPLEFT", -- [1]
				"AtlasLootDefaultFrame_LootBackground", -- [2]
				"TOPLEFT", -- [3]
				"2", -- [4]
				"-2", -- [5]
			}, -- [4]
		}, -- [1]
		{
			"T0Priest", -- [1]
			"", -- [2]
			"", -- [3]
			{
				"TOPLEFT", -- [1]
				"AtlasLootDefaultFrame_LootBackground", -- [2]
				"TOPLEFT", -- [3]
				"2", -- [4]
				"-2", -- [5]
			}, -- [4]
		}, -- [2]
		{
			"SPKalecgos", -- [1]
			"AtlasLootBurningCrusade", -- [2]
			"", -- [3]
			{
				"TOPLEFT", -- [1]
				"AtlasLootDefaultFrame_LootBackground", -- [2]
				"TOPLEFT", -- [3]
				"2", -- [4]
				"-2", -- [5]
			}, -- [4]
		}, -- [3]
	},
	["WishList"] = {
	},
	["AtlasLootVersion"] = "50207",
	["LastSearchedText"] = "Desecrated",
	["AutoQuery"] = false,
	["SearchResult"] = {
		{
			2, -- [1]
			40285, -- [2]
			"", -- [3]
			"=q4=Desecrated Past", -- [4]
			"Grobbulus", -- [5]
			"", -- [6]
			"", -- [7]
			"Naxx80Grobbulus25Man|\"\"", -- [8]
		}, -- [1]
	},
}

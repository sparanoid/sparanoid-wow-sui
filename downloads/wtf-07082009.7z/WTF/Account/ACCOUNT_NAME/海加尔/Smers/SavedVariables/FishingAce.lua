
FishingBuddyDBPC = {
	["profiles"] = {
		["Default"] = {
			["autoLoot"] = false,
		},
	},
}

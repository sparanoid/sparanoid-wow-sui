
Overachiever_CharVars = {
	["Pos_AchievementWatchFrame"] = {
		["y"] = 237.1616328185554,
		["x"] = 80.69467424311229,
		["point"] = "RIGHT",
		["relativePoint"] = "RIGHT",
		["relativeTo"] = "UIParent",
	},
	["Version"] = "0.31",
	["Pos_AchievementFrame"] = {
		["y"] = -11.81232911627994,
		["x"] = -15.99985337257604,
		["point"] = "CENTER",
		["relativePoint"] = "CENTER",
		["relativeTo"] = "UIParent",
	},
}

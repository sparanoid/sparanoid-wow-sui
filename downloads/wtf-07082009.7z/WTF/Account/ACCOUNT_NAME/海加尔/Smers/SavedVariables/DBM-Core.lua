
DBM_SavedOptions = {
	["ShowWarningsInChat"] = true,
	["RangeFramePoint"] = "CENTER",
	["RaidWarningSound"] = "Sound\\Doodad\\BellTollNightElf.wav",
	["SpecialWarningSound"] = "Sound\\Spells\\PVPFlagTaken.wav",
	["AutoRespond"] = true,
	["StatusEnabled"] = true,
	["RaidWarningPosition"] = {
		["Y"] = -185,
		["X"] = 0,
		["Point"] = "TOP",
	},
	["Enabled"] = true,
	["ShowVersionUpdateAsPopup"] = true,
	["ShowBigBrotherOnCombatStart"] = false,
	["RangeFrameX"] = 278.7513119168384,
	["WarningIconLeft"] = true,
	["WarningColors"] = {
		{
			["b"] = 0.9411764705882353,
			["g"] = 0.8,
			["r"] = 0.4117647058823529,
		}, -- [1]
		{
			["b"] = 0,
			["g"] = 0.9490196078431372,
			["r"] = 0.9490196078431372,
		}, -- [2]
		{
			["b"] = 0,
			["g"] = 0.5019607843137255,
			["r"] = 1,
		}, -- [3]
		{
			["b"] = 0.1019607843137255,
			["g"] = 0.1019607843137255,
			["r"] = 1,
		}, -- [4]
	},
	["ShowFakedRaidWarnings"] = false,
	["RangeFrameY"] = 203.468739338685,
	["WarningIconRight"] = true,
	["HPFramePoint"] = "LEFT",
	["ShowMinimapButton"] = false,
	["HPFrameX"] = 301.2500336579973,
	["SpamBlockRaidWarning"] = false,
	["SpamBlockBossWhispers"] = false,
	["HPFrameY"] = 163.6719107080711,
	["HideBossEmoteFrame"] = false,
}
DBT_SavedOptions = {
	["DBM"] = {
		["EndColorG"] = 0,
		["HugeTimerY"] = -50.85939331562231,
		["HugeBarXOffset"] = 0,
		["Scale"] = 1.200000047683716,
		["IconLeft"] = true,
		["StartColorR"] = 1,
		["HugeScale"] = 1.200000047683716,
		["BarYOffset"] = 0,
		["Texture"] = "Interface\\Addons\\Gladius\\images\\Minimalist",
		["HugeBarsEnabled"] = false,
		["ExpandUpwards"] = false,
		["TimerPoint"] = "RIGHT",
		["StartColorG"] = 0.6980392156862745,
		["TimerY"] = -208.9373175958199,
		["IconRight"] = false,
		["EndColorR"] = 1,
		["Width"] = 151,
		["HugeTimerPoint"] = "CENTER",
		["HugeTimerX"] = 9.999930113555042,
		["HugeBarYOffset"] = 0,
		["HugeWidth"] = 158,
		["StartColorB"] = 0,
		["TimerX"] = -108.0013545155323,
		["BarXOffset"] = 0,
		["EndColorB"] = 0,
	},
}


TweakWoWDB = {
	["CopperGreen"] = 1,
	["CopperRed"] = 1,
	["CopperDragon"] = 0,
	["Pitchlimit"] = "ONE",
	["CopperBlue"] = 1,
	["graphic"] = {
	},
	["CopperAlpha"] = 1,
	["CharacterAmbient"] = 0,
}


Guild2Guild_Vars = {
	["EchoGuild"] = true,
	["ShowNewRelayMessages"] = true,
	["Active"] = true,
	["color"] = "|cff40ff40",
	["Passive"] = false,
	["Startdelay"] = 15,
	["NewAddonDefault"] = false,
	["Debug"] = false,
	["addons"] = {
		["Crb"] = false,
		["Thr"] = true,
		["GathX"] = true,
		["BEJEWELED2"] = false,
		["AucAdvAskPrice"] = false,
		["WIM"] = true,
		["CGP"] = false,
		["GUILDMAP"] = false,
		["GHOSTRECON"] = false,
		["CaN"] = true,
	},
	["debugStack"] = {
	},
	["RelayAddonMessages"] = true,
	["EchoOfficer"] = true,
	["logsize"] = 0,
	["Channel"] = "smers",
	["logging"] = false,
	["log"] = {
	},
	["chatTypes"] = {
		["G2G"] = {
			true, -- [1]
			["r"] = 0.250980406999588,
			["g"] = 1.000000059138984,
			["b"] = 0.250980406999588,
		},
	},
	["GuildMemberNotify"] = "1",
}


_NPCScanOptionsCharacter = {
	["Achievements"] = {
		[1312] = true,
		[2257] = true,
	},
	["NPCs"] = {
		["time-lost proto drake"] = 32491,
	},
	["Version"] = "3.0.9.2",
}

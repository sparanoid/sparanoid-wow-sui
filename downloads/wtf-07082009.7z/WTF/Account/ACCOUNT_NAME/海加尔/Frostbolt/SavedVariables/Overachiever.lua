
Overachiever_CharVars = {
	["Pos_AchievementWatchFrame"] = {
		["y"] = 223.0989422932425,
		["x"] = -60.55498032934993,
		["point"] = "RIGHT",
		["relativePoint"] = "RIGHT",
		["relativeTo"] = "UIParent",
	},
	["TrackedAch"] = 1558,
	["Version"] = "0.31",
	["Pos_AchievementFrame"] = {
		["y"] = 46.78106238274183,
		["x"] = -13.49979618937081,
		["point"] = "CENTER",
		["relativePoint"] = "CENTER",
		["relativeTo"] = "UIParent",
	},
}

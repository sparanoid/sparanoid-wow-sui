
NxCData = {
	["Version"] = 0.1,
	["Taxi"] = {
		["Crossroads"] = true,
		["Thunder Bluff"] = true,
		["Ratchet"] = true,
		["Orgrimmar"] = true,
	},
}

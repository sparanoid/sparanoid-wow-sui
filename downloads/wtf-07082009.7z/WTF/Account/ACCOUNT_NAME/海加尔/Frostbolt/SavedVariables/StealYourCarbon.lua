
StealYourCarbonDB = {
	["tradestocklist"] = {
	},
	["stocklist"] = {
	},
}

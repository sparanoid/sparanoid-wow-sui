
SmartMount_PlayerConfig = {
	["PlayerConfigVersion"] = "PCV1",
	["PCV1"] = {
		["ExcludedMounts"] = {
		},
		["ExcludedMiniPets"] = {
		},
	},
}

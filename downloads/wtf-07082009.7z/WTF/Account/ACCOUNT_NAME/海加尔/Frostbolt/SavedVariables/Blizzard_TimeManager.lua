
BlizzardStopwatchOptions = {
	["position"] = {
		["y"] = 344.7967477918156,
		["x"] = 90.25011881813229,
	},
}

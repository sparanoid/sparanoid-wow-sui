
AtlasLootCharDB = {
	["QuickLooks"] = {
	},
	["WishList"] = {
	},
	["AtlasLootVersion"] = "50303",
	["AutoQuery"] = false,
	["SearchResult"] = {
	},
}


BagnonSets = {
	["inventory"] = {
		["y"] = 654.4533441297211,
		["x"] = 1048.999770745638,
		["parentScale"] = 0.6399999856948853,
		["scale"] = 1,
		["space"] = 10,
		["bags"] = {
			0, -- [1]
			1, -- [2]
			2, -- [3]
			3, -- [4]
			4, -- [5]
		},
		["bg"] = {
			["a"] = 0.5,
			["b"] = 0,
			["g"] = 0.2,
			["r"] = 0,
		},
		["cols"] = 10,
	},
	["showBagsAtAH"] = 1,
	["showBankAtBank"] = 1,
	["replaceBags"] = 1,
	["showBagsAtVendor"] = 1,
	["version"] = "1.7.3",
	["showBorders"] = 1,
	["showBagsAtMail"] = 1,
	["showBagsAtBank"] = 1,
	["showBagsAtTrade"] = 1,
	["bank"] = {
		["y"] = 653.250417511904,
		["x"] = 454.4996956810401,
		["parentScale"] = 0.6399999856948853,
		["scale"] = 1,
		["space"] = 10,
		["bags"] = {
			-1, -- [1]
			5, -- [2]
			6, -- [3]
			7, -- [4]
			8, -- [5]
			9, -- [6]
			10, -- [7]
			11, -- [8]
		},
		["bg"] = {
			["a"] = 0.5,
			["b"] = 0.2,
			["g"] = 0,
			["r"] = 0,
		},
		["cols"] = 12,
	},
}


DBM_SavedOptions = {
	["ShowWarningsInChat"] = true,
	["RangeFramePoint"] = "CENTER",
	["RaidWarningSound"] = "Sound\\Doodad\\BellTollNightElf.wav",
	["SpecialWarningSound"] = "Sound\\Spells\\PVPFlagTaken.wav",
	["AutoRespond"] = true,
	["StatusEnabled"] = true,
	["RaidWarningPosition"] = {
		["Y"] = -185,
		["X"] = 0,
		["Point"] = "TOP",
	},
	["Enabled"] = true,
	["ShowVersionUpdateAsPopup"] = true,
	["WarningIconRight"] = true,
	["RangeFrameX"] = 50,
	["WarningIconLeft"] = true,
	["WarningColors"] = {
		{
			["b"] = 0.9411764705882353,
			["g"] = 0.8,
			["r"] = 0.4117647058823529,
		}, -- [1]
		{
			["b"] = 0,
			["g"] = 0.9490196078431372,
			["r"] = 0.9490196078431372,
		}, -- [2]
		{
			["b"] = 0,
			["g"] = 0.5019607843137255,
			["r"] = 1,
		}, -- [3]
		{
			["b"] = 0.1019607843137255,
			["g"] = 0.1019607843137255,
			["r"] = 1,
		}, -- [4]
	},
	["ShowFakedRaidWarnings"] = false,
	["HPFrameY"] = 50,
	["RangeFrameY"] = -50,
	["HPFramePoint"] = "CENTER",
	["ShowMinimapButton"] = false,
	["HPFrameX"] = -50,
	["SpamBlockRaidWarning"] = true,
	["SpamBlockBossWhispers"] = false,
	["HideBossEmoteFrame"] = false,
	["ShowBigBrotherOnCombatStart"] = false,
}
DBT_SavedOptions = {
	["DBM"] = {
	},
}

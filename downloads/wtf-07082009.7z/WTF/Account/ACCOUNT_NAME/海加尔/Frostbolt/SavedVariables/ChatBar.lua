
ChatBar_VerticalDisplay = false
ChatBar_AlternateOrientation = false
ChatBar_HideSpecialChannels = true
ChatBar_TextOnButtonDisplay = false
ChatBar_ButtonFlashing = true
ChatBar_BarBorder = false
ChatBar_ButtonText = true
ChatBar_StoredStickies = {
}
ChatBar_HiddenButtons = {
}
ChatBar_TextChannelNumbers = false
ChatBar_HideAllButtons = true
ChatBar_AltArt = 1


AtlasOptions = {
	["AtlasScale"] = 1,
	["AtlasSortBy"] = 1,
	["AtlasLocked"] = false,
	["AtlasClamped"] = true,
	["AtlasAlpha"] = 1,
	["AtlasZone"] = 1,
	["AtlasAcronyms"] = true,
	["AtlasType"] = 3,
	["AtlasCoords"] = false,
	["AtlasCtrl"] = false,
	["AtlasButtonPosition"] = 356,
	["AtlasRightClick"] = false,
	["AtlasButtonRadius"] = 78,
	["AtlasAutoSelect"] = true,
	["AtlasVersion"] = "1.14.1",
	["AtlasButtonShown"] = false,
}


EasyTrinketDB = {
	["scale"] = 85,
	["rows"] = 5,
	["showcd"] = 1,
	["autowhip"] = 3,
	["position"] = {
		["y"] = 234.5332301477607,
		["x"] = 32.63234805118519,
		["point"] = "BOTTOMLEFT",
		["relativePoint"] = "BOTTOMLEFT",
	},
	["minimapbutton"] = 3,
	["showhotkey"] = 1,
	["Minimap Button"] = {
		["angle"] = 267,
	},
}

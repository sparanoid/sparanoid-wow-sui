
MISTER_SPARKLE = nil
CHANNELPULLOUT_OPTIONS = {
	["displayActive"] = true,
	["opacity"] = 1,
	["name"] = "Channel Roster",
}
